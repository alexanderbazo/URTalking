
% student_fachkombi(Matrikelnummer, Fachkombi_ID).


student_fachkombi(11122,001).

student_fachkombi(1234321,002).
student_fachkombi(1234567,001).
student_fachkombi(1110001,007).



