% student_kurse(Matrikelnummer, Kurs_ID, Bestanden, Note, Versuche,
% Besetzte Modulposition).


%  Einf�hrung in die Informationswissenschaft
student_kurse(1234567, 'inf001', 'true', 1.3, 1, 'INF - 01.1').
%Mathematische Grundlagen mit Tutorium
student_kurse(1234567, 'inf003', 'true', 2.0, 1, 'INF -  02.1').
%Einf�hrung in die Informationslinguistik
student_kurse(1234567, 'inf005', 'true', 2.3, 1, 'INF � 02.3').
%Einf�hrung in die objektorientierte Programmierung mit C# mit Tutorium
student_kurse(1234567, 'inf006', 'true', 1.7, 1, 'INF � 03.1').
student_kurse(1234567, 'inf007', 'true', 1.7, 1, 'INF � 03.2').
%Einf�hrung in die Programmierung und Programmiersprachen (Einf�hrung in
%Java/Objektorientierte Programmierung) mit �bung)
student_kurse(1234567, 'inf006', 'true', 3.0, 1, 'INF � 03.1').
student_kurse(1234567, 'inf007', 'true', 1.0, 1, 'INF � 03.2').
%Mediengeschichte
student_kurse(1234567, 'med001', 'true', 2.0, 1, 'MED � 01.1').
%Medien-Frauen bzw. Mediengeschichte I
student_kurse(1234567, 'med002', 'true', 2.0, 1, 'INF � 01.2').
%New Hollywood bzw. Mediengeschichte II
student_kurse(1234567, 'med003', 'true', 2.7, 1, 'INF � 01.3').
% Grenze der 35 Leistungspunkte erreicht und Modul 1 in der
% Medienwissenschaft abgeschlossen
%zweites Semester
%Informationstechnische Grundlagen
student_kurse(1234567, 'inf002', 'true', 4.0, 1, 'INF � 01.2').
%Einf�hrung in die Methoden empirischer Forschung
student_kurse(1234567, 'inf004', 'true', 1.7, 1, 'INF � 02.2').
%Software Engineering Entwurfsmethoden
student_kurse(1234567, 'inf009', 'true', 3.7, 1, 'INF � 03.4').
%ADP
student_kurse(1234567, 'inf008', 'true', 1.3, 1, 'INF � 03.3').
%Grundlagen des Information Retrieval
student_kurse(1234567, 'inf010', 'true', 1.0, 1, 'INF � 04.1').
%Datenbanksysteme
student_kurse(1234567, 'inf015', 'true', 2.7, 1, 'INF � 06.1').
%Medientheorie
student_kurse(1234567, 'med004', 'true', 3.0, 1, 'MED � 02.1').
%Medienanalyse I
student_kurse(1234567, 'med005', 'true', 1.7, 1, 'MED � 02.2').

%Einf�hrung in die Informationslinguistik
student_kurse(1110001, 'inf005', 'true' , 3.0, 1, 'INF -  02.3').
%Datenbanksysteme
student_kurse(1110001, 'inf015', 'true' , 2.0, 1, 'INF -  06.1').
%Markup
student_kurse(1110001, 'inf011', 'true', 2.7, 1, 'INF � 04.2').
%Projektmanagement
student_kurse(1110001, 'inf018', 'true', 2.0, 1, 'INF � 07.1').
%Medientheorie
student_kurse(1110001, 'med004', 'true', 3.0, 1, 'MED � 02.1').
%Mathematische Grundlagen mit Tutorium
student_kurse(1110001, 'inf003', 'true', 2.0, 1, 'INF -  02.1') .
%Vertiefungssemninar Softwareergonomie
student_kurse(1110001, 'inf014', 'true', 2.0, 1, 'INF - 05.2') .
%Medienanalyse I
student_kurse(1110001, 'med005', 'true', 3.7, 1, 'MED � 02.2').
%Einf�hrung in die Informatik und Medieninformatik
student_kurse(1110001, 'mei001', 'true', 1.7, 1, 'MEI � 01.1').
%Einf�hrung in die Informationswissenschaft
student_kurse(1110001, 'inf001', 'true', 2.3, 3, 'INF -  01.1').
%Algorithmen und Datenstrukturen
student_kurse(1110001, 'inf008', 'true', 2.0, 3, 'INF � 03.3').
%Multimedia Technology
student_kurse(1110001, 'mei016', 'true', 2.7, 2, 'MEI � 07.1').
%Vertiefungsseminar Information Retrieval
student_kurse(1110001, 'inf012', 'true', 2.3, 1, 'INF -  04.3').
%Grundlagen Informationssysteme
student_kurse(1110001, 'inf016', 'true', 3.0, 1, 'INF -  06.2').
%Programmiersprache 1
student_kurse(1110001, 'inf006', 'true', 1.7, 1, 'INF -  03.1').
%Grundlagen Human Computer Interaction
student_kurse(1110001, 'mei011', 'true', 3.0, 1, 'MEI -  05.1').
%Einf�hrung in das wissenschaftliche Arbeiten
student_kurse(1110001, 'mei002', 'true', 2.0, 1, 'MEI -  01.2').
student_kurse(1110001, 'inf002', 'true', 2.3, 1, 'INF -  01.2').
%Grundlagen Information Retrieval
student_kurse(1110001, 'inf010', 'true', 3.3, 1, 'INF -  04.1').
%Medienanalyse II
student_kurse(1110001, 'med006', 'true', 3.3, 1, 'MED -  02.3').
%�bung im Webbereich
student_kurse(1110001, 'mei018', 'true', 1.3, 1, 'MEI -  07.3').
%'Einf�hrungsvorlesung Anwendungsschwerpunkt mit �bungen
student_kurse(1110001, 'mei021', 'true', 1.3, 1, 'MEI -  10.1').
