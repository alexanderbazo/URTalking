% Kurs (Kurs_ID, Kursname, Kursart, Ebene).
% Informationswissenschaften
% Einfuehrung, Grundkurs, Vertiefungsseminar

kurse('inf000', 'Wahlbereich f�r die Informationswissenschaft', 'Wahlbereich', 'E1').

kurse('inf001', 'Einf�hrung in die Informationswissenschaft', 'Einfuehrung', 'E1').
kurse('inf002', 'Informationstechnische Grundlagen', 'Einfuehrung', 'E1').
kurse('inf003', 'Mathematische Grundlagen', 'Kurs', 'E1' ).
kurse('inf004', 'Einf�hrung in die Methoden empririscher Forschung', 'Kurs', 'E1').
kurse('inf005', 'Einf�hrung in die Informationslinguistik', 'Kurs', 'E1' ).
kurse('inf006', 'Programmiersprache 1 (vorzugsweise prozedural)', 'Einfuehrung', 'E1').
kurse('inf007', 'Programmiersprache 2 (vorzugsweise objektorientiert)', 'Einfuehrung', 'E1').
kurse('inf008', 'Algorithmen und Datenstrukturen', 'Kurs', 'E1').
kurse('inf009', 'Software Engineering-Entwurfsmethoden', 'Kurs', 'E1').

kurse('inf010', 'Grundlagen des Information Retrieval', 'Grundkurs', 'E2' ).
kurse('inf011', 'Inhaltserschlie�ung/Auszeichnungssprachen', 'Kurs', 'E2' ).
kurse('inf012', 'Vertiefungsseminar Information Retrieval', 'Vertiefungsseminar', 'E2').
kurse('inf013', 'Grundlagen der Softwareergonomie', 'Grundkurs', 'E2' ).
kurse('inf014', 'Vertiefungsseminar Softwareergonomie', 'Vertiefungsseminar', 'E2').
kurse('inf015', 'Datenbanksysteme', 'Kurs', 'E2' ).
kurse('inf016', 'Grundlagen Informationssysteme', 'Grundkurs', 'E2').
kurse('inf017', 'Vertiefungsseminar Informationssysteme', 'Vertiefungsseminar', 'E2').

kurse('inf018', 'Projektmanagement', 'Kurs', 'E3' ).
kurse('inf019', 'Projektseminar', 'Kurs', 'E3').



% Kurs (Kurs_ID, Kursname, Kursart, Ebene, Turnusss, Turnusws).
% Medienwissenschaft
kurse('med000', 'Wahlbereich f�r die Medienwissenschaft', 'Wahlbereich', 'E1').

kurse('med001', 'Mediengeschichte', 'Einfuehrung', 'E1' ).
kurse('med002', 'Mediengeschichte I', 'Kurs', 'E1' ).
kurse('med003', 'Mediengeschichte II', 'Kurs', 'E1' ).
kurse('med004', 'Medientheorie', 'Einfuehrung', 'E1' ).
kurse('med005', 'Medienanalyse I', 'Kurs', 'E1' ).
kurse('med006', 'Medienanalyse II', 'Kurs', 'E1' ).
kurse('med007', 'Einf�hrung in die Informationswissenschaft', 'Einfuehrung', 'E1' ).
kurse('med008', 'Informationstechnische Grundlagen', 'Einfuehrung', 'E1').

kurse('med009', 'Medienpraxis/Mediengestaltung', 'Kurs', 'E2' ).
kurse('med010', 'Projektseminar', 'Kurs', 'E2' ).
kurse('med011', 'Medienpsychologie, Seminar 1', 'Kurs', 'E2' ).
kurse('med012', 'Medienpsychologie, Seminar 2', 'Kurs', 'E2').
kurse('med013', 'Gestaltung computerbasierter Lernumgebung', 'Kurs', 'E2' ).
kurse('med014', 'Evaluation computerbasierter Lernumgebung', 'Kurs', 'E2' ).
kurse('med015', 'Einf�hrung Recht f�r Medienwissenschaftler', 'Kurs', 'E2' ).
kurse('med016', 'Geistiges Eigentum', 'Kurs', 'E2').
kurse('med017', 'Einf�hrung Vergleichende Kulturwissenschaft', 'Einfuehrung', 'E2' ).
kurse('med018', 'Kulturanalyse I oder II', 'Kurs', 'E2' ).

kurse('med019', 'Grundkonzepte digitaler Medien', 'Kurs', 'E3').
kurse('med020', 'Theorie und Geschichte digitaler Medien', 'Kurs', 'E3' ).
kurse('med021', 'Medienkulturwissenschaft', 'Kurs', 'E3' ).



% Kurs (Kurs_ID, Kursname, Kursart, Ebene, Turnusss, Turnusws).
% Medieninformatik

kurse('mei000', 'Wahlbereich f�r die Medieninformatik', 'Wahlbereich', 'E1').

kurse('mei001', 'Einf�hrung in die Informatik und Medieninformatik ', 'Einfuehrung', 'E1' ).
kurse('mei002', 'Einf�hrung in das wissenschaftliche Arbeiten ', 'Einfuehrung', 'E1' ).
kurse('mei003', 'Mathematik f�r Medieninformatiker I', 'Kurs', 'E1').
kurse('mei004', 'Mathematik f�r Medieninformatiker II', 'Kurs', 'E1').
kurse('mei005', 'Einf�hrung inh die Programmierung und Programmiersprachen', 'Einfuehrung', 'E1' ).
kurse('mei006', 'Algorithmen und Datenstrukturen', 'Kurs', 'E1' ).
kurse('mei007', 'Einf�hrung in die Anwendungsprogrammierung mit begleitendem Softwarepraktikum', 'Kurs', 'E1').

kurse('mei008', 'Multimedia Technology', 'Kurs', 'E2' ).
kurse('mei009', 'Multimedia Informationssystem und Datenbanken', 'Kurs', 'E2' ).
kurse('mei010', 'Multimedia Engineering mit begleitendem Praktikum', 'Kurs', 'E2' ).
kurse('mei011', 'Grundlagen der Human-Computer-Interaction', 'Kurs', 'E2').
kurse('mei012', 'Usability Engineering', 'Kurs', 'E2' ).
kurse('mei013', 'Projektseminar Mediengestaltung Usability Engineering', 'Kurs', 'E2' ).
kurse('mei014', 'Einf�hrung in die Programmierung und Programmiersprache', 'Einfuehrung', 'E2' ).
kurse('mei015', '�bung zur Anwendungsprogrammierung mit begleitendem Softwareentwicklungspraktikum', 'Kurs', 'E2' ).
kurse('mei016', 'Multimedia Technology', 'Kurs', 'E2' ).
kurse('mei017', 'Grundlagen Human-Computer-Interaction', 'Kurs', 'E2').
kurse('mei018', '�bung im Bereich Webdesign', 'Kurs', 'E2' ).
kurse('mei019', 'Multimedia Technology', 'Kurs', 'E2').
kurse('mei020', 'Multimedia Informationssysteme und Datenbanken', 'Kurs', 'E2' ).

kurse('mei021', 'Einf�hrungsvorlesung Anwendungsschwerpunkt mit �bungen', 'Grundkurs', 'E3' ).
kurse('mei022', 'Vertiefungsvorlesung Anwendungsmodul mit �bungen', 'Vertiefungsseminar', 'E3' ).
kurse('mei023', 'Projektbezogenes Seminar im Anwendungsmodul', 'Kurs', 'E3' ).











