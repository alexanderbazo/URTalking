
% Fachkombi_Module(Fachkombi_ID, Modul_ID, Pflichtmodul oder Wahlmodul).
% fachkombination = 001 INF MED

fachkombi_modul(001,'infm01','pflicht').
fachkombi_modul(001,'infm02','pflicht').
fachkombi_modul(001,'infm03','pflicht').
fachkombi_modul(001,'infm04','pflicht').
fachkombi_modul(001,'infm05','pflicht').
fachkombi_modul(001,'infm06','pflicht').
fachkombi_modul(001,'infm07','pflicht').
fachkombi_modul(001,'medm01','pflicht').
fachkombi_modul(001,'medm02','pflicht').
fachkombi_modul(001,'medm04','wahl').
fachkombi_modul(001,'medm05','wahl').
fachkombi_modul(001,'medm06','wahl').
fachkombi_modul(001,'medm07','wahl').
fachkombi_modul(001,'medm08','wahl').
%% Achtung: Sie m�ssen f�r das Modul MED-M03 ein fachfremdes Ersatzmodul
%% belegen. F�r weitere Informationen, wenden Sie sich bitte an den
%% Modulkoordinator.

% fachkombination = 002 INF MEI


fachkombi_modul(002,'infm01','pflicht').
fachkombi_modul(002,'infm02','pflicht').
fachkombi_modul(002,'meim10','pflicht').
fachkombi_modul(002,'infm04','pflicht').
fachkombi_modul(002,'infm05','pflicht').
fachkombi_modul(002,'infm06','pflicht').
fachkombi_modul(002,'infm07','pflicht').
fachkombi_modul(002,'meim01','pflicht').
fachkombi_modul(002,'meim02','pflicht').
fachkombi_modul(002,'meim03','pflicht').
fachkombi_modul(002,'meim05','pflicht').
fachkombi_modul(002,'meim08','pflicht').
% Achtung: In der Kombination mit Medieninformatik als zweites Hauptfach
%ist INF-M 03 durch einen
% zus�tzlichen Anwendungsschwerpunkt aus MEI-M 10 mit Seminararbeit oder
% eine analoge fachliche Vertiefung aus dem Bereich
% Informationswissenschaft zu ersetzen.


% fachkombination = 003 MED INF

fachkombi_modul(003,'medm01','pflicht').
fachkombi_modul(003,'medm02','pflicht').
fachkombi_modul(003,'medm04','wahl').
fachkombi_modul(003,'medm05','wahl').
fachkombi_modul(003,'medm06','wahl').
fachkombi_modul(003,'medm07','wahl').
fachkombi_modul(003,'medm08','wahl').
fachkombi_modul(003,'medm09','pflicht').
fachkombi_modul(003,'medm10','pflicht').
fachkombi_modul(003,'infm01','pflicht').
fachkombi_modul(003,'infm02','pflicht').
fachkombi_modul(003,'infm03','pflicht').
fachkombi_modul(003,'infm04','wahl').
fachkombi_modul(003,'infm05','wahl').
fachkombi_modul(003,'infm06','wahl').
%% Achtung: Sie m�ssen f�r das Modul MED-M03 ein fachfremdes Ersatzmodul
%% belegen. F�r weitere Informationen, wenden Sie sich bitte an den
%% Modulkoordinator.


% fachkombination = 004 MED MEI


fachkombi_modul(004,'medm01','pflicht').
fachkombi_modul(004,'medm02','pflicht').
fachkombi_modul(004,'medm03','pflicht').
fachkombi_modul(004,'medm04','wahl').
fachkombi_modul(004,'medm05','wahl').
fachkombi_modul(004,'medm06','wahl').
fachkombi_modul(004,'medm07','wahl').
fachkombi_modul(004,'medm08','wahl').
fachkombi_modul(004,'medm09','pflicht').
fachkombi_modul(004,'medm10','pflicht').
fachkombi_modul(004,'meim01','pflicht').
fachkombi_modul(004,'meim02','pflicht').
fachkombi_modul(004,'meim03','pflicht').
fachkombi_modul(004,'meim05','pflicht').
fachkombi_modul(004,'meim08','pflicht').


% fachkombination = 005 MEI INF

fachkombi_modul(005,'meim01','pflicht').
fachkombi_modul(005,'meim02','pflicht').
fachkombi_modul(005,'meim03','pflicht').
fachkombi_modul(005,'meim04','pflicht').
fachkombi_modul(005,'meim10','pflicht').
fachkombi_modul(005,'meim09','wahl').
fachkombi_modul(005,'meim05','pflicht').
fachkombi_modul(005,'meim06','wahl').
fachkombi_modul(005,'meim07','wahl').
fachkombi_modul(005,'meim08','wahl').
fachkombi_modul(005,'infm01','pflicht').
fachkombi_modul(005,'infm02','pflicht').
fachkombi_modul(005,'infm03','pflicht').
fachkombi_modul(005,'infm04','wahl').
fachkombi_modul(005,'infm05','wahl').
fachkombi_modul(005,'infm06','wahl').
fachkombi_modul(005,'infm07','wahl').

% Achtung: Sie d�rfen die Module Inf-M03 und MEI-M06 nicht gleichzeitig
% belegen.


% fachkombination = 006 MEI MED

fachkombi_modul(006,'meim01','pflicht').
fachkombi_modul(006,'meim02','pflicht').
fachkombi_modul(006,'meim03','pflicht').
fachkombi_modul(006,'meim04','pflicht').
fachkombi_modul(006,'meim10','pflicht').
fachkombi_modul(006,'meim09','wahl').
fachkombi_modul(006,'meim05','pflicht').
fachkombi_modul(006,'meim06','wahl').
fachkombi_modul(006,'meim07','wahl').
fachkombi_modul(006,'meim08','wahl').
fachkombi_modul(006,'medm01','pflicht').
fachkombi_modul(006,'medm02','pflicht').
fachkombi_modul(006,'medm03','pflicht').
fachkombi_modul(006,'medm04','wahl').
fachkombi_modul(006,'medm05','wahl').
fachkombi_modul(006,'medm06','wahl').
fachkombi_modul(006,'medm07','wahl').
fachkombi_modul(006,'medm08','wahl').


% fachkombination = 007 INF MED MEI

fachkombi_modul(007,'infm01','pflicht').
fachkombi_modul(007,'infm02','pflicht').
fachkombi_modul(007,'infm03','pflicht').
fachkombi_modul(007,'infm04','pflicht').
fachkombi_modul(007,'infm05','pflicht').
fachkombi_modul(007,'infm06','pflicht').
fachkombi_modul(007,'infm07','pflicht').
fachkombi_modul(007,'medm01','pflicht').
fachkombi_modul(007,'medm02','pflicht').
fachkombi_modul(007,'meim01','pflicht').
fachkombi_modul(007,'meim10','pflicht').
fachkombi_modul(007,'meim07','pflicht').
% Achtung: Sie d�rfen die Positionen Mei-M07.1 und Inf-M05.1 nicht mit
% denselben Kurs belegen. W�hlen Sie einen Alternativkurs aus Modul
% INF-M05.

% fachkombination = 008 MED INF MEI

fachkombi_modul(008,'medm01','pflicht').
fachkombi_modul(008,'medm02','pflicht').
fachkombi_modul(008,'medm04','wahl').
fachkombi_modul(008,'medm05','wahl').
fachkombi_modul(008,'medm06','wahl').
fachkombi_modul(008,'medm07','wahl').
fachkombi_modul(008,'medm08','wahl').
fachkombi_modul(008,'medm09','pflicht').
fachkombi_modul(008,'medm10','pflicht').
fachkombi_modul(008,'infm01','pflicht').
fachkombi_modul(008,'infm04','wahl').
fachkombi_modul(008,'infm05','wahl').
fachkombi_modul(008,'infm06','wahl').
fachkombi_modul(008,'meim01','pflicht').
fachkombi_modul(008,'meim06','pflicht').
fachkombi_modul(008,'meim07','pflicht').
%% Achtung: Sie m�ssen f�r das Modul MED-M03 ein fachfremdes Ersatzmodul
%% belegen. F�r weitere Informationen, wenden Sie sich bitte an den
%% Modulkoordinator.


% fachkombination = 009 MEI INF MED

fachkombi_modul(009,'meim01','pflicht').
fachkombi_modul(009,'meim02','pflicht').
fachkombi_modul(009,'meim03','pflicht').
fachkombi_modul(009,'meim09','pflicht').
fachkombi_modul(009,'meim10','pflicht').
fachkombi_modul(009,'meim04','wahl').
fachkombi_modul(009,'meim05','wahl').
fachkombi_modul(009,'meim06','wahl').
fachkombi_modul(009,'meim07','wahl').
fachkombi_modul(009,'meim08','wahl').
fachkombi_modul(009,'infm01','pflicht').
fachkombi_modul(009,'infm04','wahl').
fachkombi_modul(009,'infm05','wahl').
fachkombi_modul(009,'infm06','wahl').
fachkombi_modul(009,'medm01','pflicht').
fachkombi_modul(009,'medm02','pflicht').




