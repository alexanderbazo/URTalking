
% student(Matrikelnummer, Name, Vorname, Studenbeginn).
student(1234321, 'Skywalker', 'Luke', 'WS13').
student(1234567, 'Vader', 'Darth', 'WS12').
student(1110001, 'Yoda', 'Meister', 'WS11').







