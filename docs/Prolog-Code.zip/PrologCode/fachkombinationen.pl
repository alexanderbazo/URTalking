% Fachkombination(Fachkombi_ID, BF, HF, NF, NF)


fachkombination(001, 'INF', 'MED', 'Null', 'Null').
fachkombination(002, 'INF', 'MEI', 'Null', 'Null').
fachkombination(003, 'MED', 'INF', 'Null', 'Null').
fachkombination(004, 'MED', 'MEI', 'Null', 'Null').
fachkombination(005, 'MEI', 'INF', 'Null', 'Null').
fachkombination(006, 'MEI', 'MED', 'Null', 'Null').
fachkombination(007, 'INF', 'Null', 'MED', 'MEI').
fachkombination(008, 'MED', 'Null', 'INF', 'MEI').
fachkombination(009, 'MEI', 'Null', 'INF', 'MED').

