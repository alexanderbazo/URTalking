% abhangigkeitkurse(Kurs_ID, Folgekurs_ID, Staerke).


% Informationswissenschaften

% inf001 = Einf�hrung in die Informationswissenschaft
abhangigkeitkurse('inf001', 'inf001', 0.000 ).
abhangigkeitkurse('inf001', 'inf002', 0.214 ).
abhangigkeitkurse('inf001', 'inf003', 0.107 ).
abhangigkeitkurse('inf001', 'inf004', 0.107 ).
abhangigkeitkurse('inf001', 'inf005', 0.143 ).
abhangigkeitkurse('inf001', 'inf006', 0.036 ).
abhangigkeitkurse('inf001', 'inf007', 0.036 ).
abhangigkeitkurse('inf001', 'inf008', 0.036 ).
abhangigkeitkurse('inf001', 'inf009', 0.036 ).
abhangigkeitkurse('inf001', 'inf010', 0.250 ).
abhangigkeitkurse('inf001', 'inf011', 0.036 ).
abhangigkeitkurse('inf001', 'inf012', 0.036 ).
abhangigkeitkurse('inf001', 'inf013', 0.214 ).
abhangigkeitkurse('inf001', 'inf014', 0.036 ).
abhangigkeitkurse('inf001', 'inf015', 0.036 ).
abhangigkeitkurse('inf001', 'inf016', 0.179 ).
abhangigkeitkurse('inf001', 'inf017', 0.071 ).
abhangigkeitkurse('inf001', 'inf018', 0.179 ).
abhangigkeitkurse('inf001', 'inf019', 0.036 ).

% inf002 = Informationstechnische Grundlagen
abhangigkeitkurse('inf002', 'inf001', 0.107 ).
abhangigkeitkurse('inf002', 'inf002', 0.000 ).
abhangigkeitkurse('inf002', 'inf003', 0.036 ).
abhangigkeitkurse('inf002', 'inf004', 0.036 ).
abhangigkeitkurse('inf002', 'inf005', 0.000 ).
abhangigkeitkurse('inf002', 'inf006', 0.179 ).
abhangigkeitkurse('inf002', 'inf007', 0.107 ).
abhangigkeitkurse('inf002', 'inf008', 0.179 ).
abhangigkeitkurse('inf002', 'inf009', 0.036 ).
abhangigkeitkurse('inf002', 'inf010', 0.000 ).
abhangigkeitkurse('inf002', 'inf011', 0.036 ).
abhangigkeitkurse('inf002', 'inf012', 0.000 ).
abhangigkeitkurse('inf002', 'inf013', 0.071 ).
abhangigkeitkurse('inf002', 'inf014', 0.000 ).
abhangigkeitkurse('inf002', 'inf015', 0.143 ).
abhangigkeitkurse('inf002', 'inf016', 0.000 ).
abhangigkeitkurse('inf002', 'inf017', 0.000 ).
abhangigkeitkurse('inf002', 'inf018', 0.071 ).
abhangigkeitkurse('inf002', 'inf019', 0.000 ).

% inf003 = Mathematische Grundlagen
abhangigkeitkurse('inf003', 'inf001', 0.107 ).
abhangigkeitkurse('inf003', 'inf002', 0.000 ).
abhangigkeitkurse('inf003', 'inf003', 0.000 ).
abhangigkeitkurse('inf003', 'inf004', 0.179 ).
abhangigkeitkurse('inf003', 'inf005', 0.071 ).
abhangigkeitkurse('inf003', 'inf006', 0.036 ).
abhangigkeitkurse('inf003', 'inf007', 0.036 ).
abhangigkeitkurse('inf003', 'inf008', 0.143 ).
abhangigkeitkurse('inf003', 'inf009', 0.000 ).
abhangigkeitkurse('inf003', 'inf010', 0.214 ).
abhangigkeitkurse('inf003', 'inf011', 0.000 ).
abhangigkeitkurse('inf003', 'inf012', 0.000 ).
abhangigkeitkurse('inf003', 'inf013', 0.000 ).
abhangigkeitkurse('inf003', 'inf014', 0.000 ).
abhangigkeitkurse('inf003', 'inf015', 0.000 ).
abhangigkeitkurse('inf003', 'inf016', 0.143 ).
abhangigkeitkurse('inf003', 'inf017', 0.000 ).
abhangigkeitkurse('inf003', 'inf018', 0.143 ).
abhangigkeitkurse('inf003', 'inf019', 0.000 ).


% inf004 = Einf�hrung in die Methoden empririscher Forschung
abhangigkeitkurse('inf004', 'inf001', 0.036 ).
abhangigkeitkurse('inf004', 'inf002', 0.000 ).
abhangigkeitkurse('inf004', 'inf003', 0.000 ).
abhangigkeitkurse('inf004', 'inf004', 0.000 ).
abhangigkeitkurse('inf004', 'inf005', 0.000 ).
abhangigkeitkurse('inf004', 'inf006', 0.000 ).
abhangigkeitkurse('inf004', 'inf007', 0.000 ).
abhangigkeitkurse('inf004', 'inf008', 0.000 ).
abhangigkeitkurse('inf004', 'inf009', 0.000 ).
abhangigkeitkurse('inf004', 'inf010', 0.000 ).
abhangigkeitkurse('inf004', 'inf011', 0.000 ).
abhangigkeitkurse('inf004', 'inf012', 0.143 ).
abhangigkeitkurse('inf004', 'inf013', 0.107 ).
abhangigkeitkurse('inf004', 'inf014', 0.143 ).
abhangigkeitkurse('inf004', 'inf015', 0.286 ).
abhangigkeitkurse('inf004', 'inf016', 0.000 ).
abhangigkeitkurse('inf004', 'inf017', 0.286 ).
abhangigkeitkurse('inf004', 'inf018', 0.536 ).
abhangigkeitkurse('inf004', 'inf019', 0.000 ).

% inf005 = Einf�hrung in die Inforamtionslinguistik
abhangigkeitkurse('inf005', 'inf001', 0.036 ).
abhangigkeitkurse('inf005', 'inf002', 0.000 ).
abhangigkeitkurse('inf005', 'inf003', 0.000 ).
abhangigkeitkurse('inf005', 'inf004', 0.000 ).
abhangigkeitkurse('inf005', 'inf005', 0.000 ).
abhangigkeitkurse('inf005', 'inf006', 0.000 ).
abhangigkeitkurse('inf005', 'inf007', 0.000 ).
abhangigkeitkurse('inf005', 'inf008', 0.000 ).
abhangigkeitkurse('inf005', 'inf009', 0.000 ).
abhangigkeitkurse('inf005', 'inf010', 0.179 ).
abhangigkeitkurse('inf005', 'inf011', 0.107 ).
abhangigkeitkurse('inf005', 'inf012', 0.000 ).
abhangigkeitkurse('inf005', 'inf013', 0.000).
abhangigkeitkurse('inf005', 'inf014', 0.000 ).
abhangigkeitkurse('inf005', 'inf015', 0.000 ).
abhangigkeitkurse('inf005', 'inf016', 0.036 ).
abhangigkeitkurse('inf005', 'inf017', 0.036 ).
abhangigkeitkurse('inf005', 'inf018', 0.143 ).
abhangigkeitkurse('inf005', 'inf019', 0.000 ).

% inf006 = Programmiersprache 1 (vorzugsweise prozedural)
abhangigkeitkurse('inf006', 'inf001', 0.036 ).
abhangigkeitkurse('inf006', 'inf002', 0.000 ).
abhangigkeitkurse('inf006', 'inf003', 0.000 ).
abhangigkeitkurse('inf006', 'inf004', 0.000 ).
abhangigkeitkurse('inf006', 'inf005', 0.000 ).
abhangigkeitkurse('inf006', 'inf006', 0.000 ).
abhangigkeitkurse('inf006', 'inf007', 0.036 ).
abhangigkeitkurse('inf006', 'inf008', 0.643 ).
abhangigkeitkurse('inf006', 'inf009', 0.357 ).
abhangigkeitkurse('inf006', 'inf010', 0.000 ).
abhangigkeitkurse('inf006', 'inf011', 0.000 ).
abhangigkeitkurse('inf006', 'inf012', 0.071 ).
abhangigkeitkurse('inf006', 'inf013', 0.071 ).
abhangigkeitkurse('inf006', 'inf014', 0.000 ).
abhangigkeitkurse('inf006', 'inf015', 0.071 ).
abhangigkeitkurse('inf006', 'inf016', 0.000 ).
abhangigkeitkurse('inf006', 'inf017', 0.000 ).
abhangigkeitkurse('inf006', 'inf018', 0.143 ).
abhangigkeitkurse('inf006', 'inf019', 0.000 ).


% inf007 = Programmiersprache 2 (vorzugsweise objektorientiert)
abhangigkeitkurse('inf007', 'inf001', 0.036 ).
abhangigkeitkurse('inf007', 'inf002', 0.000 ).
abhangigkeitkurse('inf007', 'inf003', 0.000).
abhangigkeitkurse('inf007', 'inf004', 0.000 ).
abhangigkeitkurse('inf007', 'inf005', 0.000 ).
abhangigkeitkurse('inf007', 'inf006', 0.000 ).
abhangigkeitkurse('inf007', 'inf007', 0.000 ).
abhangigkeitkurse('inf007', 'inf008', 0.500 ).
abhangigkeitkurse('inf007', 'inf009', 0.214 ).
abhangigkeitkurse('inf007', 'inf010', 0.000 ).
abhangigkeitkurse('inf007', 'inf011', 0.000 ).
abhangigkeitkurse('inf007', 'inf012', 0.143 ).
abhangigkeitkurse('inf007', 'inf013', 0.071 ).
abhangigkeitkurse('inf007', 'inf014', 0.071 ).
abhangigkeitkurse('inf007', 'inf015', 0.071 ).
abhangigkeitkurse('inf007', 'inf016', 0.000 ).
abhangigkeitkurse('inf007', 'inf017', 0.071 ).
abhangigkeitkurse('inf007', 'inf018', 0.143 ).
abhangigkeitkurse('inf007', 'inf019', 0.000 ).


% inf008 = Algorithmen und Datenstrukturen
abhangigkeitkurse('inf008', 'inf001', 0.036 ).
abhangigkeitkurse('inf008', 'inf002', 0.000 ).
abhangigkeitkurse('inf008', 'inf003', 0.071 ).
abhangigkeitkurse('inf008', 'inf004', 0.000 ).
abhangigkeitkurse('inf008', 'inf005', 0.000 ).
abhangigkeitkurse('inf008', 'inf006', 0.000 ).
abhangigkeitkurse('inf008', 'inf007', 0.000 ).
abhangigkeitkurse('inf008', 'inf008', 0.000 ).
abhangigkeitkurse('inf008', 'inf009', 0.321 ).
abhangigkeitkurse('inf008', 'inf010', 0.179 ).
abhangigkeitkurse('inf008', 'inf011', 0.036 ).
abhangigkeitkurse('inf008', 'inf012', 0.036 ).
abhangigkeitkurse('inf008', 'inf013', 0.000 ).
abhangigkeitkurse('inf008', 'inf014', 0.000 ).
abhangigkeitkurse('inf008', 'inf015', 0.071 ).
abhangigkeitkurse('inf008', 'inf016', 0.000 ).
abhangigkeitkurse('inf008', 'inf017', 0.036 ).
abhangigkeitkurse('inf008', 'inf018', 0.143 ).
abhangigkeitkurse('inf008', 'inf019', 0.000 ).


% inf009 = Software Engineering-Entwurfsmethoden
abhangigkeitkurse('inf009', 'inf001', 0.036 ).
abhangigkeitkurse('inf009', 'inf002', 0.000 ).
abhangigkeitkurse('inf009', 'inf003', 0.000 ).
abhangigkeitkurse('inf009', 'inf004', 0.000 ).
abhangigkeitkurse('inf009', 'inf005', 0.000 ).
abhangigkeitkurse('inf009', 'inf006', 0.000 ).
abhangigkeitkurse('inf009', 'inf007', 0.000 ).
abhangigkeitkurse('inf009', 'inf008', 0.000 ).
abhangigkeitkurse('inf009', 'inf009', 0.000 ).
abhangigkeitkurse('inf009', 'inf010', 0.000 ).
abhangigkeitkurse('inf009', 'inf011', 0.000 ).
abhangigkeitkurse('inf009', 'inf012', 0.071 ).
abhangigkeitkurse('inf009', 'inf013', 0.000 ).
abhangigkeitkurse('inf009', 'inf014', 0.036 ).
abhangigkeitkurse('inf009', 'inf015', 0.000 ).
abhangigkeitkurse('inf009', 'inf016', 0.000 ).
abhangigkeitkurse('inf009', 'inf017', 0.036 ).
abhangigkeitkurse('inf009', 'inf018', 0.250 ).
abhangigkeitkurse('inf009', 'inf019', 0.000 ).


% inf010 = Grundlagen des Information Retrieval
abhangigkeitkurse('inf010', 'inf001', 0.036 ).
abhangigkeitkurse('inf010', 'inf002', 0.000 ).
abhangigkeitkurse('inf010', 'inf003', 0.000 ).
abhangigkeitkurse('inf010', 'inf004', 0.000 ).
abhangigkeitkurse('inf010', 'inf005', 0.000 ).
abhangigkeitkurse('inf010', 'inf006', 0.000 ).
abhangigkeitkurse('inf010', 'inf007', 0.000 ).
abhangigkeitkurse('inf010', 'inf008', 0.000 ).
abhangigkeitkurse('inf010', 'inf009', 0.000 ).
abhangigkeitkurse('inf010', 'inf010', 0.000 ).
abhangigkeitkurse('inf010', 'inf011', 0.107 ).
abhangigkeitkurse('inf010', 'inf012', 0.643 ).
abhangigkeitkurse('inf010', 'inf013', 0.000 ).
abhangigkeitkurse('inf010', 'inf014', 0.000 ).
abhangigkeitkurse('inf010', 'inf015', 0.071 ).
abhangigkeitkurse('inf010', 'inf016', 0.036 ).
abhangigkeitkurse('inf010', 'inf017', 0.000 ).
abhangigkeitkurse('inf010', 'inf018', 0.071 ).
abhangigkeitkurse('inf010', 'inf019', 0.000 ).


% inf011 = Inhaltserschlie�ung/Auszeichnungssprachen
abhangigkeitkurse('inf011', 'inf001', 0.036 ).
abhangigkeitkurse('inf011', 'inf002', 0.000 ).
abhangigkeitkurse('inf011', 'inf003', 0.000 ).
abhangigkeitkurse('inf011', 'inf004', 0.000 ).
abhangigkeitkurse('inf011', 'inf005', 0.036 ).
abhangigkeitkurse('inf011', 'inf006', 0.000 ).
abhangigkeitkurse('inf011', 'inf007', 0.000 ).
abhangigkeitkurse('inf011', 'inf008', 0.000 ).
abhangigkeitkurse('inf011', 'inf009', 0.000 ).
abhangigkeitkurse('inf011', 'inf010', 0.000 ).
abhangigkeitkurse('inf011', 'inf011', 0.000 ).
abhangigkeitkurse('inf011', 'inf012', 0.107 ).
abhangigkeitkurse('inf011', 'inf013', 0.000 ).
abhangigkeitkurse('inf011', 'inf014', 0.000 ).
abhangigkeitkurse('inf011', 'inf015', 0.071 ).
abhangigkeitkurse('inf011', 'inf016', 0.000 ).
abhangigkeitkurse('inf011', 'inf017', 0.000 ).
abhangigkeitkurse('inf011', 'inf018', 0.071 ).
abhangigkeitkurse('inf011', 'inf019', 0.000 ).

% inf012 = Vertiefungsseminar Information Retrieval
abhangigkeitkurse('inf012', 'inf001', 0.036 ).
abhangigkeitkurse('inf012', 'inf002', 0.000 ).
abhangigkeitkurse('inf012', 'inf003', 0.000 ).
abhangigkeitkurse('inf012', 'inf004', 0.143 ).
abhangigkeitkurse('inf012', 'inf005', 0.000 ).
abhangigkeitkurse('inf012', 'inf006', 0.000 ).
abhangigkeitkurse('inf012', 'inf007', 0.000 ).
abhangigkeitkurse('inf012', 'inf008', 0.000 ).
abhangigkeitkurse('inf012', 'inf009', 0.000 ).
abhangigkeitkurse('inf012', 'inf010', 0.000 ).
abhangigkeitkurse('inf012', 'inf011', 0.000 ).
abhangigkeitkurse('inf012', 'inf012', 0.000 ).
abhangigkeitkurse('inf012', 'inf013', 0.000 ).
abhangigkeitkurse('inf012', 'inf014', 0.000 ).
abhangigkeitkurse('inf012', 'inf015', 0.143 ).
abhangigkeitkurse('inf012', 'inf016', 0.000 ).
abhangigkeitkurse('inf012', 'inf017', 0.000 ).
abhangigkeitkurse('inf012', 'inf018', 0.286 ).
abhangigkeitkurse('inf012', 'inf019', 0.000 ).


% inf013 = Grundlagen der Softwareergonomie
abhangigkeitkurse('inf013', 'inf001', 0.036 ).
abhangigkeitkurse('inf013', 'inf002', 0.000 ).
abhangigkeitkurse('inf013', 'inf003', 0.000 ).
abhangigkeitkurse('inf013', 'inf004', 0.000 ).
abhangigkeitkurse('inf013', 'inf005', 0.000 ).
abhangigkeitkurse('inf013', 'inf006', 0.000 ).
abhangigkeitkurse('inf013', 'inf007', 0.000 ).
abhangigkeitkurse('inf013', 'inf008', 0.000 ).
abhangigkeitkurse('inf013', 'inf009', 0.000 ).
abhangigkeitkurse('inf013', 'inf010', 0.000 ).
abhangigkeitkurse('inf013', 'inf011', 0.000 ).
abhangigkeitkurse('inf013', 'inf012', 0.000 ).
abhangigkeitkurse('inf013', 'inf013', 0.000 ).
abhangigkeitkurse('inf013', 'inf014', 1.000 ).
abhangigkeitkurse('inf013', 'inf015', 0.000 ).
abhangigkeitkurse('inf013', 'inf016', 0.000 ).
abhangigkeitkurse('inf013', 'inf017', 0.000 ).
abhangigkeitkurse('inf013', 'inf018', 0.107 ).
abhangigkeitkurse('inf013', 'inf019', 0.000 ).


% inf014 = Vertiefungsseminar Softwareergonomie
abhangigkeitkurse('inf014', 'inf001', 0.036 ).
abhangigkeitkurse('inf014', 'inf002', 0.000 ).
abhangigkeitkurse('inf014', 'inf003', 0.000 ).
abhangigkeitkurse('inf014', 'inf004', 0.143 ).
abhangigkeitkurse('inf014', 'inf005', 0.000 ).
abhangigkeitkurse('inf014', 'inf006', 0.000 ).
abhangigkeitkurse('inf014', 'inf007', 0.000 ).
abhangigkeitkurse('inf014', 'inf008', 0.000 ).
abhangigkeitkurse('inf014', 'inf009', 0.000 ).
abhangigkeitkurse('inf014', 'inf010', 0.000 ).
abhangigkeitkurse('inf014', 'inf011', 0.000 ).
abhangigkeitkurse('inf014', 'inf012', 0.000 ).
abhangigkeitkurse('inf014', 'inf013', 0.000 ).
abhangigkeitkurse('inf014', 'inf014', 0.000 ).
abhangigkeitkurse('inf014', 'inf015', 0.000 ).
abhangigkeitkurse('inf014', 'inf016', 0.000 ).
abhangigkeitkurse('inf014', 'inf017', 0.000 ).
abhangigkeitkurse('inf014', 'inf018', 0.286 ).
abhangigkeitkurse('inf014', 'inf019', 0.000 ).

% inf015 = Datenbanksysteme
abhangigkeitkurse('inf015', 'inf001', 0.036 ).
abhangigkeitkurse('inf015', 'inf002', 0.000 ).
abhangigkeitkurse('inf015', 'inf003', 0.000 ).
abhangigkeitkurse('inf015', 'inf004', 0.000 ).
abhangigkeitkurse('inf015', 'inf005', 0.000 ).
abhangigkeitkurse('inf015', 'inf006', 0.000 ).
abhangigkeitkurse('inf015', 'inf007', 0.000 ).
abhangigkeitkurse('inf015', 'inf008', 0.000 ).
abhangigkeitkurse('inf015', 'inf009', 0.071 ).
abhangigkeitkurse('inf015', 'inf010', 0.071 ).
abhangigkeitkurse('inf015', 'inf011', 0.000 ).
abhangigkeitkurse('inf015', 'inf012', 0.036 ).
abhangigkeitkurse('inf015', 'inf013', 0.000 ).
abhangigkeitkurse('inf015', 'inf014', 0.036 ).
abhangigkeitkurse('inf015', 'inf015', 0.000 ).
abhangigkeitkurse('inf015', 'inf016', 0.071 ).
abhangigkeitkurse('inf015', 'inf017', 0.036 ).
abhangigkeitkurse('inf015', 'inf018', 0.107 ).
abhangigkeitkurse('inf015', 'inf019', 0.000 ).


% inf016 = Grundlagen Informationssysteme
abhangigkeitkurse('inf016', 'inf001', 0.036 ).
abhangigkeitkurse('inf016', 'inf002', 0.000 ).
abhangigkeitkurse('inf016', 'inf003', 0.000 ).
abhangigkeitkurse('inf016', 'inf004', 0.000 ).
abhangigkeitkurse('inf016', 'inf005', 0.000 ).
abhangigkeitkurse('inf016', 'inf006', 0.000 ).
abhangigkeitkurse('inf016', 'inf007', 0.000 ).
abhangigkeitkurse('inf016', 'inf008', 0.000 ).
abhangigkeitkurse('inf016', 'inf009', 0.000 ).
abhangigkeitkurse('inf016', 'inf010', 0.000 ).
abhangigkeitkurse('inf016', 'inf011', 0.000 ).
abhangigkeitkurse('inf016', 'inf012', 0.000 ).
abhangigkeitkurse('inf016', 'inf013', 0.000 ).
abhangigkeitkurse('inf016', 'inf014', 0.000 ).
abhangigkeitkurse('inf016', 'inf015', 0.071 ).
abhangigkeitkurse('inf016', 'inf016', 0.000 ).
abhangigkeitkurse('inf016', 'inf017', 0.786 ).
abhangigkeitkurse('inf016', 'inf018', 0.071 ).
abhangigkeitkurse('inf016', 'inf019', 0.000 ).

% inf017 = Vertiefungsseminar Informationssysteme
abhangigkeitkurse('inf017', 'inf001', 0.036 ).
abhangigkeitkurse('inf017', 'inf002', 0.000 ).
abhangigkeitkurse('inf017', 'inf003', 0.000 ).
abhangigkeitkurse('inf017', 'inf004', 0.143 ).
abhangigkeitkurse('inf017', 'inf005', 0.000 ).
abhangigkeitkurse('inf017', 'inf006', 0.000 ).
abhangigkeitkurse('inf017', 'inf007', 0.000 ).
abhangigkeitkurse('inf017', 'inf008', 0.000 ).
abhangigkeitkurse('inf017', 'inf009', 0.000 ).
abhangigkeitkurse('inf017', 'inf010', 0.000 ).
abhangigkeitkurse('inf017', 'inf011', 0.000 ).
abhangigkeitkurse('inf017', 'inf012', 0.000 ).
abhangigkeitkurse('inf017', 'inf013', 0.000 ).
abhangigkeitkurse('inf017', 'inf014', 0.000 ).
abhangigkeitkurse('inf017', 'inf015', 0.000 ).
abhangigkeitkurse('inf017', 'inf016', 0.000 ).
abhangigkeitkurse('inf017', 'inf017', 0.000 ).
abhangigkeitkurse('inf017', 'inf018', 0.393 ).
abhangigkeitkurse('inf017', 'inf019', 0.000 ).


% inf018 = Projektmanagement
abhangigkeitkurse('inf018', 'inf001', 0.036 ).
abhangigkeitkurse('inf018', 'inf002', 0.000 ).
abhangigkeitkurse('inf018', 'inf003', 0.000 ).
abhangigkeitkurse('inf018', 'inf004', 0.000 ).
abhangigkeitkurse('inf018', 'inf005', 0.000 ).
abhangigkeitkurse('inf018', 'inf006', 0.000 ).
abhangigkeitkurse('inf018', 'inf007', 0.000 ).
abhangigkeitkurse('inf018', 'inf008', 0.000 ).
abhangigkeitkurse('inf018', 'inf009', 0.000 ).
abhangigkeitkurse('inf018', 'inf010', 0.000 ).
abhangigkeitkurse('inf018', 'inf011', 0.000 ).
abhangigkeitkurse('inf018', 'inf012', 0.000 ).
abhangigkeitkurse('inf018', 'inf013', 0.000 ).
abhangigkeitkurse('inf018', 'inf014', 0.000 ).
abhangigkeitkurse('inf018', 'inf015', 0.000 ).
abhangigkeitkurse('inf018', 'inf016', 0.000 ).
abhangigkeitkurse('inf018', 'inf017', 0.000 ).
abhangigkeitkurse('inf018', 'inf018', 0.321 ).
abhangigkeitkurse('inf018', 'inf019', 0.000 ).

% inf019 = Projektseminar
abhangigkeitkurse('inf019', 'inf001', 0.036 ).
abhangigkeitkurse('inf019', 'inf002', 0.000 ).
abhangigkeitkurse('inf019', 'inf003', 0.000 ).
abhangigkeitkurse('inf019', 'inf004', 0.000 ).
abhangigkeitkurse('inf019', 'inf005', 0.000 ).
abhangigkeitkurse('inf019', 'inf006', 0.000 ).
abhangigkeitkurse('inf019', 'inf007', 0.000 ).
abhangigkeitkurse('inf019', 'inf008', 0.000 ).
abhangigkeitkurse('inf019', 'inf009', 0.000 ).
abhangigkeitkurse('inf019', 'inf010', 0.000 ).
abhangigkeitkurse('inf019', 'inf011', 0.000 ).
abhangigkeitkurse('inf019', 'inf012', 0.000 ).
abhangigkeitkurse('inf019', 'inf013', 0.000 ).
abhangigkeitkurse('inf019', 'inf014', 0.000 ).
abhangigkeitkurse('inf019', 'inf015', 0.000 ).
abhangigkeitkurse('inf019', 'inf016', 0.000 ).
abhangigkeitkurse('inf019', 'inf017', 0.000 ).
abhangigkeitkurse('inf019', 'inf018', 0.000 ).
abhangigkeitkurse('inf019', 'inf019', 0.000 ).



% abhangigkeitkurse(Kurs_ID, Folgekurs_ID, Staerke).

% dummydaten f�r MED

% Medienwissenschaft
% med001 = Mediengeschichte
abhangigkeitkurse('med001', 'med001', 0.000 ).
abhangigkeitkurse('med001', 'med002', 0.107 ).
abhangigkeitkurse('med001', 'med003', 0.000 ).
abhangigkeitkurse('med001', 'med004', 0.036 ).
abhangigkeitkurse('med001', 'med005', 0.214 ).
abhangigkeitkurse('med001', 'med006', 0.000 ).
abhangigkeitkurse('med001', 'med007', 0.000 ).
abhangigkeitkurse('med001', 'med008', 0.214 ).
abhangigkeitkurse('med001', 'med009', 0.000 ).
abhangigkeitkurse('med001', 'med010', 0.000 ).
abhangigkeitkurse('med001', 'med011', 0.000 ).
abhangigkeitkurse('med001', 'med012', 0.143 ).
abhangigkeitkurse('med001', 'med013', 0.000 ).
abhangigkeitkurse('med001', 'med014', 0.179 ).
abhangigkeitkurse('med001', 'med015', 0.036 ).
abhangigkeitkurse('med001', 'med016', 0.000 ).
abhangigkeitkurse('med001', 'med017', 0.000 ).
abhangigkeitkurse('med001', 'med018', 0.071 ).
abhangigkeitkurse('med001', 'med019', 0.000 ).
abhangigkeitkurse('med001', 'med020', 0.036 ).
abhangigkeitkurse('med001', 'med021', 0.214 ).

% med002 = Mediengeschichte I
abhangigkeitkurse('med002', 'med001', 0.000 ).
abhangigkeitkurse('med002', 'med002', 0.000 ).
abhangigkeitkurse('med002', 'med003', 0.000 ).
abhangigkeitkurse('med002', 'med004', 0.036 ).
abhangigkeitkurse('med002', 'med005', 0.000 ).
abhangigkeitkurse('med002', 'med006', 0.000 ).
abhangigkeitkurse('med002', 'med007', 0.000 ).
abhangigkeitkurse('med002', 'med008', 0.143 ).
abhangigkeitkurse('med002', 'med009', 0.000 ).
abhangigkeitkurse('med002', 'med010', 0.179 ).
abhangigkeitkurse('med002', 'med011', 0.000 ).
abhangigkeitkurse('med002', 'med012', 0.000 ).
abhangigkeitkurse('med002', 'med013', 0.000 ).
abhangigkeitkurse('med002', 'med014', 0.036 ).
abhangigkeitkurse('med002', 'med015', 0.000 ).
abhangigkeitkurse('med002', 'med016', 0.036 ).
abhangigkeitkurse('med002', 'med017', 0.036 ).
abhangigkeitkurse('med002', 'med018', 0.000 ).
abhangigkeitkurse('med002', 'med019', 0.000 ).
abhangigkeitkurse('med002', 'med020', 0.179 ).
abhangigkeitkurse('med002', 'med021', 0.107 ).


% med003 = Mediengeschichte II
abhangigkeitkurse('med003', 'med001', 0.000 ).
abhangigkeitkurse('med003', 'med002', 0.000 ).
abhangigkeitkurse('med003', 'med003', 0.000 ).
abhangigkeitkurse('med003', 'med004', 0.000 ).
abhangigkeitkurse('med003', 'med005', 0.000 ).
abhangigkeitkurse('med003', 'med006', 0.000 ).
abhangigkeitkurse('med003', 'med007', 0.143 ).
abhangigkeitkurse('med003', 'med008', 0.000 ).
abhangigkeitkurse('med003', 'med009', 0.036 ).
abhangigkeitkurse('med003', 'med010', 0.036 ).
abhangigkeitkurse('med003', 'med011', 0.214 ).
abhangigkeitkurse('med003', 'med012', 0.000 ).
abhangigkeitkurse('med003', 'med013', 0.000 ).
abhangigkeitkurse('med003', 'med014', 0.000 ).
abhangigkeitkurse('med003', 'med015', 0.071 ).
abhangigkeitkurse('med003', 'med016', 0.071 ).
abhangigkeitkurse('med003', 'med017', 0.000 ).
abhangigkeitkurse('med003', 'med018', 0.143 ).
abhangigkeitkurse('med003', 'med019', 0.071 ).
abhangigkeitkurse('med003', 'med020', 0.000 ).
abhangigkeitkurse('med003', 'med021', 0.179 ).


% med004 = Medientheorie
abhangigkeitkurse('med004', 'med001', 0.214 ).
abhangigkeitkurse('med004', 'med002', 0.000 ).
abhangigkeitkurse('med004', 'med003', 0.000 ).
abhangigkeitkurse('med004', 'med004', 0.000 ).
abhangigkeitkurse('med004', 'med005', 0.143 ).
abhangigkeitkurse('med004', 'med006', 0.071 ).
abhangigkeitkurse('med004', 'med007', 0.000 ).
abhangigkeitkurse('med004', 'med008', 0.000 ).
abhangigkeitkurse('med004', 'med009', 0.036 ).
abhangigkeitkurse('med004', 'med010', 0.071 ).
abhangigkeitkurse('med004', 'med011', 0.000 ).
abhangigkeitkurse('med004', 'med012', 0.143 ).
abhangigkeitkurse('med004', 'med013', 0.000 ).
abhangigkeitkurse('med004', 'med014', 0.000 ).
abhangigkeitkurse('med004', 'med015', 0.000 ).
abhangigkeitkurse('med004', 'med016', 0.071 ).
abhangigkeitkurse('med004', 'med017', 0.036 ).
abhangigkeitkurse('med004', 'med018', 0.000 ).
abhangigkeitkurse('med004', 'med019', 0.000 ).
abhangigkeitkurse('med004', 'med020', 0.000 ).
abhangigkeitkurse('med004', 'med021', 0.000 ).



% med005 = Medienanalyse I
abhangigkeitkurse('med005', 'med001', 0.000 ).
abhangigkeitkurse('med005', 'med002', 0.000 ).
abhangigkeitkurse('med005', 'med003', 0.000 ).
abhangigkeitkurse('med005', 'med004', 0.214 ).
abhangigkeitkurse('med005', 'med005', 0.000 ).
abhangigkeitkurse('med005', 'med006', 0.000 ).
abhangigkeitkurse('med005', 'med007', 0.000 ).
abhangigkeitkurse('med005', 'med008', 0.000 ).
abhangigkeitkurse('med005', 'med009', 0.000 ).
abhangigkeitkurse('med005', 'med010', 0.107 ).
abhangigkeitkurse('med005', 'med011', 0.036 ).
abhangigkeitkurse('med005', 'med012', 0.036 ).
abhangigkeitkurse('med005', 'med013', 0.000 ).
abhangigkeitkurse('med005', 'med014', 0.036 ).
abhangigkeitkurse('med005', 'med015', 0.000 ).
abhangigkeitkurse('med005', 'med016', 0.000 ).
abhangigkeitkurse('med005', 'med017', 0.000 ).
abhangigkeitkurse('med005', 'med018', 0.000 ).
abhangigkeitkurse('med005', 'med019', 0.000 ).
abhangigkeitkurse('med005', 'med020', 0.000 ).
abhangigkeitkurse('med005', 'med021', 0.107 ).



% med006 = Medienanalyse II
abhangigkeitkurse('med006', 'med001', 0.000 ).
abhangigkeitkurse('med006', 'med002', 0.000 ).
abhangigkeitkurse('med006', 'med003', 0.000 ).
abhangigkeitkurse('med006', 'med004', 0.214 ).
abhangigkeitkurse('med006', 'med005', 0.000 ).
abhangigkeitkurse('med006', 'med006', 0.000 ).
abhangigkeitkurse('med006', 'med007', 0.000 ).
abhangigkeitkurse('med006', 'med008', 0.036 ).
abhangigkeitkurse('med006', 'med009', 0.000 ).
abhangigkeitkurse('med006', 'med010', 0.107 ).
abhangigkeitkurse('med006', 'med011', 0.000 ).
abhangigkeitkurse('med006', 'med012', 0.000 ).
abhangigkeitkurse('med006', 'med013', 0.000 ).
abhangigkeitkurse('med006', 'med014', 0.036 ).
abhangigkeitkurse('med006', 'med015', 0.143 ).
abhangigkeitkurse('med006', 'med016', 0.143 ).
abhangigkeitkurse('med006', 'med017', 0.036 ).
abhangigkeitkurse('med006', 'med018', 0.000 ).
abhangigkeitkurse('med006', 'med019', 0.000 ).
abhangigkeitkurse('med006', 'med020', 0.000 ).
abhangigkeitkurse('med006', 'med021', 0.143 ).


% med007 = Einf�hrung in die Informationswissenschaft
abhangigkeitkurse('med007', 'med001', 0.000 ).
abhangigkeitkurse('med007', 'med002', 0.000 ).
abhangigkeitkurse('med007', 'med003', 0.000 ).
abhangigkeitkurse('med007', 'med004', 0.000 ).
abhangigkeitkurse('med007', 'med005', 0.000 ).
abhangigkeitkurse('med007', 'med006', 0.000 ).
abhangigkeitkurse('med007', 'med007', 0.000 ).
abhangigkeitkurse('med007', 'med008', 0.286 ).
abhangigkeitkurse('med007', 'med009', 0.000 ).
abhangigkeitkurse('med007', 'med010', 0.000 ).
abhangigkeitkurse('med007', 'med011', 0.000 ).
abhangigkeitkurse('med007', 'med012', 0.000 ).
abhangigkeitkurse('med007', 'med013', 0.000 ).
abhangigkeitkurse('med007', 'med014', 0.000 ).
abhangigkeitkurse('med007', 'med015', 0.000 ).
abhangigkeitkurse('med007', 'med016', 0.000 ).
abhangigkeitkurse('med007', 'med017', 0.000 ).
abhangigkeitkurse('med007', 'med018', 0.000 ).
abhangigkeitkurse('med007', 'med019', 0.000 ).
abhangigkeitkurse('med007', 'med020', 0.000 ).
abhangigkeitkurse('med007', 'med021', 0.107 ).


% med008 = Informationstechnische Grundlagen
abhangigkeitkurse('med008', 'med001', 0.000 ).
abhangigkeitkurse('med008', 'med002', 0.000 ).
abhangigkeitkurse('med008', 'med003', 0.000 ).
abhangigkeitkurse('med008', 'med004', 0.000 ).
abhangigkeitkurse('med008', 'med005', 0.000 ).
abhangigkeitkurse('med008', 'med006', 0.000 ).
abhangigkeitkurse('med008', 'med007', 0.393 ).
abhangigkeitkurse('med008', 'med008', 0.000 ).
abhangigkeitkurse('med008', 'med009', 0.000 ).
abhangigkeitkurse('med008', 'med010', 0.000 ).
abhangigkeitkurse('med008', 'med011', 0.000 ).
abhangigkeitkurse('med008', 'med012', 0.000 ).
abhangigkeitkurse('med008', 'med013', 0.000 ).
abhangigkeitkurse('med008', 'med014', 0.000 ).
abhangigkeitkurse('med008', 'med015', 0.000 ).
abhangigkeitkurse('med008', 'med016', 0.000 ).
abhangigkeitkurse('med008', 'med017', 0.000 ).
abhangigkeitkurse('med008', 'med018', 0.000 ).
abhangigkeitkurse('med008', 'med019', 0.000 ).
abhangigkeitkurse('med008', 'med020', 0.000 ).
abhangigkeitkurse('med008', 'med021', 0.143 ).


% med009 = Medienpraxis/Mediengestaltung
abhangigkeitkurse('med009', 'med001', 0.107 ).
abhangigkeitkurse('med009', 'med002', 0.000 ).
abhangigkeitkurse('med009', 'med003', 0.000 ).
abhangigkeitkurse('med009', 'med004', 0.143 ).
abhangigkeitkurse('med009', 'med005', 0.000 ).
abhangigkeitkurse('med009', 'med006', 0.000 ).
abhangigkeitkurse('med009', 'med007', 0.286 ).
abhangigkeitkurse('med009', 'med008', 0.286 ).
abhangigkeitkurse('med009', 'med009', 0.000 ).
abhangigkeitkurse('med009', 'med010', 0.000 ).
abhangigkeitkurse('med009', 'med011', 0.000 ).
abhangigkeitkurse('med009', 'med012', 0.000 ).
abhangigkeitkurse('med009', 'med013', 0.000 ).
abhangigkeitkurse('med009', 'med014', 0.000 ).
abhangigkeitkurse('med009', 'med015', 0.000 ).
abhangigkeitkurse('med009', 'med016', 0.036 ).
abhangigkeitkurse('med009', 'med017', 0.000 ).
abhangigkeitkurse('med009', 'med018', 0.000 ).
abhangigkeitkurse('med009', 'med019', 0.000 ).
abhangigkeitkurse('med009', 'med020', 0.000 ).
abhangigkeitkurse('med009', 'med021', 0.107 ).



% med010 = Projektseminar
abhangigkeitkurse('med010', 'med001', 0.107 ).
abhangigkeitkurse('med010', 'med002', 0.000 ).
abhangigkeitkurse('med010', 'med003', 0.000 ).
abhangigkeitkurse('med010', 'med004', 0.107 ).
abhangigkeitkurse('med010', 'med005', 0.000 ).
abhangigkeitkurse('med010', 'med006', 0.000 ).
abhangigkeitkurse('med010', 'med007', 0.286 ).
abhangigkeitkurse('med010', 'med008', 0.286 ).
abhangigkeitkurse('med010', 'med009', 0.000 ).
abhangigkeitkurse('med010', 'med010', 0.000 ).
abhangigkeitkurse('med010', 'med011', 0.000 ).
abhangigkeitkurse('med010', 'med012', 0.000 ).
abhangigkeitkurse('med010', 'med013', 0.000 ).
abhangigkeitkurse('med010', 'med014', 0.000 ).
abhangigkeitkurse('med010', 'med015', 0.000 ).
abhangigkeitkurse('med010', 'med016', 0.036 ).
abhangigkeitkurse('med010', 'med017', 0.000 ).
abhangigkeitkurse('med010', 'med018', 0.000 ).
abhangigkeitkurse('med010', 'med019', 0.036 ).
abhangigkeitkurse('med010', 'med020', 0.000 ).
abhangigkeitkurse('med010', 'med021', 0.143 ).


% med011 = Medienpsychologie, Seminar 1
abhangigkeitkurse('med011', 'med001', 0.036 ).
abhangigkeitkurse('med011', 'med002', 0.000 ).
abhangigkeitkurse('med011', 'med003', 0.000 ).
abhangigkeitkurse('med011', 'med004', 0.107 ).
abhangigkeitkurse('med011', 'med005', 0.000 ).
abhangigkeitkurse('med011', 'med006', 0.000 ).
abhangigkeitkurse('med011', 'med007', 0.000 ).
abhangigkeitkurse('med011', 'med008', 0.000 ).
abhangigkeitkurse('med011', 'med009', 0.000 ).
abhangigkeitkurse('med011', 'med010', 0.000 ).
abhangigkeitkurse('med011', 'med011', 0.000 ).
abhangigkeitkurse('med011', 'med012', 0.000 ).
abhangigkeitkurse('med011', 'med013', 0.000 ).
abhangigkeitkurse('med011', 'med014', 0.000 ).
abhangigkeitkurse('med011', 'med015', 0.000 ).
abhangigkeitkurse('med011', 'med016', 0.000 ).
abhangigkeitkurse('med011', 'med017', 0.000 ).
abhangigkeitkurse('med011', 'med018', 0.000 ).
abhangigkeitkurse('med011', 'med019', 0.000 ).
abhangigkeitkurse('med011', 'med020', 0.000 ).
abhangigkeitkurse('med011', 'med021', 0.036 ).


% med012 = Medienpsychologie, Seminar 2
abhangigkeitkurse('med012', 'med001', 0.036 ).
abhangigkeitkurse('med012', 'med002', 0.000 ).
abhangigkeitkurse('med012', 'med003', 0.000 ).
abhangigkeitkurse('med012', 'med004', 0.143 ).
abhangigkeitkurse('med012', 'med005', 0.000 ).
abhangigkeitkurse('med012', 'med006', 0.000 ).
abhangigkeitkurse('med012', 'med007', 0.000 ).
abhangigkeitkurse('med012', 'med008', 0.000 ).
abhangigkeitkurse('med012', 'med009', 0.000 ).
abhangigkeitkurse('med012', 'med010', 0.000 ).
abhangigkeitkurse('med012', 'med011', 0.000 ).
abhangigkeitkurse('med012', 'med012', 0.000 ).
abhangigkeitkurse('med012', 'med013', 0.000 ).
abhangigkeitkurse('med012', 'med014', 0.000 ).
abhangigkeitkurse('med012', 'med015', 0.000 ).
abhangigkeitkurse('med012', 'med016', 0.000 ).
abhangigkeitkurse('med012', 'med017', 0.000 ).
abhangigkeitkurse('med012', 'med018', 0.000 ).
abhangigkeitkurse('med012', 'med019', 0.000 ).
abhangigkeitkurse('med012', 'med020', 0.000 ).
abhangigkeitkurse('med012', 'med021', 0.107 ).


% med013 = Gestaltung computerbasierter Lernumgebung
abhangigkeitkurse('med013', 'med001', 0.000 ).
abhangigkeitkurse('med013', 'med002', 0.000 ).
abhangigkeitkurse('med013', 'med003', 0.000 ).
abhangigkeitkurse('med013', 'med004', 0.000 ).
abhangigkeitkurse('med013', 'med005', 0.000 ).
abhangigkeitkurse('med013', 'med006', 0.000 ).
abhangigkeitkurse('med013', 'med007', 0.286 ).
abhangigkeitkurse('med013', 'med008', 0.393 ).
abhangigkeitkurse('med013', 'med009', 0.000 ).
abhangigkeitkurse('med013', 'med010', 0.000 ).
abhangigkeitkurse('med013', 'med011', 0.000 ).
abhangigkeitkurse('med013', 'med012', 0.000 ).
abhangigkeitkurse('med013', 'med013', 0.000 ).
abhangigkeitkurse('med013', 'med014', 0.143 ).
abhangigkeitkurse('med013', 'med015', 0.000 ).
abhangigkeitkurse('med013', 'med016', 0.000 ).
abhangigkeitkurse('med013', 'med017', 0.000 ).
abhangigkeitkurse('med013', 'med018', 0.000 ).
abhangigkeitkurse('med013', 'med019', 0.000 ).
abhangigkeitkurse('med013', 'med020', 0.000 ).
abhangigkeitkurse('med013', 'med021', 0.107 ).


% med014 = Evaluation computerbasierter Lernumgebung
abhangigkeitkurse('med014', 'med001', 0.000 ).
abhangigkeitkurse('med014', 'med002', 0.000 ).
abhangigkeitkurse('med014', 'med003', 0.000 ).
abhangigkeitkurse('med014', 'med004', 0.000 ).
abhangigkeitkurse('med014', 'med005', 0.000 ).
abhangigkeitkurse('med014', 'med006', 0.000 ).
abhangigkeitkurse('med014', 'med007', 0.357 ).
abhangigkeitkurse('med014', 'med008', 0.393 ).
abhangigkeitkurse('med014', 'med009', 0.000 ).
abhangigkeitkurse('med014', 'med010', 0.000 ).
abhangigkeitkurse('med014', 'med011', 0.000 ).
abhangigkeitkurse('med014', 'med012', 0.000 ).
abhangigkeitkurse('med014', 'med013', 0.643 ).
abhangigkeitkurse('med014', 'med014', 0.000 ).
abhangigkeitkurse('med014', 'med015', 0.000 ).
abhangigkeitkurse('med014', 'med016', 0.000 ).
abhangigkeitkurse('med014', 'med017', 0.000 ).
abhangigkeitkurse('med014', 'med018', 0.000 ).
abhangigkeitkurse('med014', 'med019', 0.000 ).
abhangigkeitkurse('med014', 'med020', 0.000 ).
abhangigkeitkurse('med014', 'med021', 0.286 ).


% med015 = Einf�hrung Recht f�r Medienwissenschaftler
abhangigkeitkurse('med015', 'med001', 0.000 ).
abhangigkeitkurse('med015', 'med002', 0.000 ).
abhangigkeitkurse('med015', 'med003', 0.000 ).
abhangigkeitkurse('med015', 'med004', 0.000 ).
abhangigkeitkurse('med015', 'med005', 0.000 ).
abhangigkeitkurse('med015', 'med006', 0.000 ).
abhangigkeitkurse('med015', 'med007', 0.000 ).
abhangigkeitkurse('med015', 'med008', 0.000 ).
abhangigkeitkurse('med015', 'med009', 0.000 ).
abhangigkeitkurse('med015', 'med010', 0.000 ).
abhangigkeitkurse('med015', 'med011', 0.000 ).
abhangigkeitkurse('med015', 'med012', 0.000 ).
abhangigkeitkurse('med015', 'med013', 0.000 ).
abhangigkeitkurse('med015', 'med014', 0.000 ).
abhangigkeitkurse('med015', 'med015', 0.000 ).
abhangigkeitkurse('med015', 'med016', 0.107 ).
abhangigkeitkurse('med015', 'med017', 0.000 ).
abhangigkeitkurse('med015', 'med018', 0.000 ).
abhangigkeitkurse('med015', 'med019', 0.000 ).
abhangigkeitkurse('med015', 'med020', 0.000 ).
abhangigkeitkurse('med015', 'med021', 0.036 ).


% med016 = Geistiges Eigentum
abhangigkeitkurse('med016', 'med001', 0.000 ).
abhangigkeitkurse('med016', 'med002', 0.000 ).
abhangigkeitkurse('med016', 'med003', 0.000 ).
abhangigkeitkurse('med016', 'med004', 0.000 ).
abhangigkeitkurse('med016', 'med005', 0.000 ).
abhangigkeitkurse('med016', 'med006', 0.000 ).
abhangigkeitkurse('med016', 'med007', 0.000 ).
abhangigkeitkurse('med016', 'med008', 0.000 ).
abhangigkeitkurse('med016', 'med009', 0.000 ).
abhangigkeitkurse('med016', 'med010', 0.000 ).
abhangigkeitkurse('med016', 'med011', 0.000 ).
abhangigkeitkurse('med016', 'med012', 0.000 ).
abhangigkeitkurse('med016', 'med013', 0.000 ).
abhangigkeitkurse('med016', 'med014', 0.000 ).
abhangigkeitkurse('med016', 'med015', 0.107 ).
abhangigkeitkurse('med016', 'med016', 0.000 ).
abhangigkeitkurse('med016', 'med017', 0.000 ).
abhangigkeitkurse('med016', 'med018', 0.000 ).
abhangigkeitkurse('med016', 'med019', 0.000 ).
abhangigkeitkurse('med016', 'med020', 0.000 ).
abhangigkeitkurse('med016', 'med021', 0.036 ).



% med017 = Einf�hrung Vergleichende Kulturwissenschaft
abhangigkeitkurse('med017', 'med001', 0.036 ).
abhangigkeitkurse('med017', 'med002', 0.000 ).
abhangigkeitkurse('med017', 'med003', 0.000 ).
abhangigkeitkurse('med017', 'med004', 0.036 ).
abhangigkeitkurse('med017', 'med005', 0.000 ).
abhangigkeitkurse('med017', 'med006', 0.000 ).
abhangigkeitkurse('med017', 'med007', 0.000 ).
abhangigkeitkurse('med017', 'med008', 0.000 ).
abhangigkeitkurse('med017', 'med009', 0.000 ).
abhangigkeitkurse('med017', 'med010', 0.000 ).
abhangigkeitkurse('med017', 'med011', 0.000 ).
abhangigkeitkurse('med017', 'med012', 0.000 ).
abhangigkeitkurse('med017', 'med013', 0.000 ).
abhangigkeitkurse('med017', 'med014', 0.000 ).
abhangigkeitkurse('med017', 'med015', 0.000 ).
abhangigkeitkurse('med017', 'med016', 0.000 ).
abhangigkeitkurse('med017', 'med017', 0.000 ).
abhangigkeitkurse('med017', 'med018', 0.000 ).
abhangigkeitkurse('med017', 'med019', 0.000 ).
abhangigkeitkurse('med017', 'med020', 0.000 ).
abhangigkeitkurse('med017', 'med021', 0.036 ).



% med018 = Kulturanalyse I oder II
abhangigkeitkurse('med018', 'med001', 0.000 ).
abhangigkeitkurse('med018', 'med002', 0.000 ).
abhangigkeitkurse('med018', 'med003', 0.000 ).
abhangigkeitkurse('med018', 'med004', 0.000 ).
abhangigkeitkurse('med018', 'med005', 0.000 ).
abhangigkeitkurse('med018', 'med006', 0.000 ).
abhangigkeitkurse('med018', 'med007', 0.000 ).
abhangigkeitkurse('med018', 'med008', 0.000 ).
abhangigkeitkurse('med018', 'med009', 0.000 ).
abhangigkeitkurse('med018', 'med010', 0.000 ).
abhangigkeitkurse('med018', 'med011', 0.000 ).
abhangigkeitkurse('med018', 'med012', 0.000 ).
abhangigkeitkurse('med018', 'med013', 0.000 ).
abhangigkeitkurse('med018', 'med014', 0.000 ).
abhangigkeitkurse('med018', 'med015', 0.000 ).
abhangigkeitkurse('med018', 'med016', 0.000 ).
abhangigkeitkurse('med018', 'med017', 0.643 ).
abhangigkeitkurse('med018', 'med018', 0.000 ).
abhangigkeitkurse('med018', 'med019', 0.000 ).
abhangigkeitkurse('med018', 'med020', 0.000 ).
abhangigkeitkurse('med018', 'med021', 0.000 ).


% med019 = Grundkonzepte digitaler Medien
abhangigkeitkurse('med019', 'med001', 0.143 ).
abhangigkeitkurse('med019', 'med002', 0.000 ).
abhangigkeitkurse('med019', 'med003', 0.000 ).
abhangigkeitkurse('med019', 'med004', 0.214 ).
abhangigkeitkurse('med019', 'med005', 0.000 ).
abhangigkeitkurse('med019', 'med006', 0.000 ).
abhangigkeitkurse('med019', 'med007', 0.500 ).
abhangigkeitkurse('med019', 'med008', 0.643 ).
abhangigkeitkurse('med019', 'med009', 0.000 ).
abhangigkeitkurse('med019', 'med010', 0.000 ).
abhangigkeitkurse('med019', 'med011', 0.000 ).
abhangigkeitkurse('med019', 'med012', 0.000 ).
abhangigkeitkurse('med019', 'med013', 0.000 ).
abhangigkeitkurse('med019', 'med014', 0.000 ).
abhangigkeitkurse('med019', 'med015', 0.000 ).
abhangigkeitkurse('med019', 'med016', 0.000 ).
abhangigkeitkurse('med019', 'med017', 0.000 ).
abhangigkeitkurse('med019', 'med018', 0.000 ).
abhangigkeitkurse('med019', 'med019', 0.000 ).
abhangigkeitkurse('med019', 'med020', 1.000 ).
abhangigkeitkurse('med019', 'med021', 0.357 ).


% med020 = Theorie und Geschichte digitaler Medien
abhangigkeitkurse('med020', 'med001', 0.357 ).
abhangigkeitkurse('med020', 'med002', 0.000 ).
abhangigkeitkurse('med020', 'med003', 0.000 ).
abhangigkeitkurse('med020', 'med004', 0.250 ).
abhangigkeitkurse('med020', 'med005', 0.000 ).
abhangigkeitkurse('med020', 'med006', 0.000 ).
abhangigkeitkurse('med020', 'med007', 0.500 ).
abhangigkeitkurse('med020', 'med008', 0.643 ).
abhangigkeitkurse('med020', 'med009', 0.000 ).
abhangigkeitkurse('med020', 'med010', 0.000 ).
abhangigkeitkurse('med020', 'med011', 0.000 ).
abhangigkeitkurse('med020', 'med012', 0.000 ).
abhangigkeitkurse('med020', 'med013', 0.000 ).
abhangigkeitkurse('med020', 'med014', 0.000 ).
abhangigkeitkurse('med020', 'med015', 0.000 ).
abhangigkeitkurse('med020', 'med016', 0.000 ).
abhangigkeitkurse('med020', 'med017', 0.000 ).
abhangigkeitkurse('med020', 'med018', 0.000 ).
abhangigkeitkurse('med020', 'med019', 0.786 ).
abhangigkeitkurse('med020', 'med020', 0.000 ).
abhangigkeitkurse('med020', 'med021', 0.357 ).



% med021 = Medienkulturwissenschaft
abhangigkeitkurse('med021', 'med001', 0.000 ).
abhangigkeitkurse('med021', 'med002', 0.000 ).
abhangigkeitkurse('med021', 'med003', 0.000 ).
abhangigkeitkurse('med021', 'med004', 0.000 ).
abhangigkeitkurse('med021', 'med005', 0.000 ).
abhangigkeitkurse('med021', 'med006', 0.000 ).
abhangigkeitkurse('med021', 'med007', 0.000 ).
abhangigkeitkurse('med021', 'med008', 0.000 ).
abhangigkeitkurse('med021', 'med009', 0.000 ).
abhangigkeitkurse('med021', 'med010', 0.000 ).
abhangigkeitkurse('med021', 'med011', 0.000 ).
abhangigkeitkurse('med021', 'med012', 0.000 ).
abhangigkeitkurse('med021', 'med013', 0.000 ).
abhangigkeitkurse('med021', 'med014', 0.000 ).
abhangigkeitkurse('med021', 'med015', 0.000 ).
abhangigkeitkurse('med021', 'med016', 0.000 ).
abhangigkeitkurse('med021', 'med017', 0.000 ).
abhangigkeitkurse('med021', 'med018', 0.000 ).
abhangigkeitkurse('med021', 'med019', 0.000 ).
abhangigkeitkurse('med021', 'med020', 0.000 ).
abhangigkeitkurse('med021', 'med021', 0.000 ).

% abhangigkeitkurse(Kurs_ID, Folgekurs_ID, Staerke).

% dummydaten f�r MEI
% NAMEN FEHLEN

% Medieninformatik
% mei001 = Einf�hrung in die Informatik und Medieninformatik
abhangigkeitkurse('mei001', 'mei001', 0.000 ).
abhangigkeitkurse('mei001', 'mei002', 0.036 ).
abhangigkeitkurse('mei001', 'mei003', 0.071 ).
abhangigkeitkurse('mei001', 'mei004', 0.000 ).
abhangigkeitkurse('mei001', 'mei005', 0.000 ).
abhangigkeitkurse('mei001', 'mei006', 0.250 ).
abhangigkeitkurse('mei001', 'mei007', 0.143 ).
abhangigkeitkurse('mei001', 'mei008', 0.107 ).
abhangigkeitkurse('mei001', 'mei009', 0.000 ).
abhangigkeitkurse('mei001', 'mei010', 0.000 ).
abhangigkeitkurse('mei001', 'mei011', 0.000 ).
abhangigkeitkurse('mei001', 'mei012', 0.000 ).
abhangigkeitkurse('mei001', 'mei013', 0.000 ).
abhangigkeitkurse('mei001', 'mei014', 0.000 ).
abhangigkeitkurse('mei001', 'mei015', 0.500 ).
abhangigkeitkurse('mei001', 'mei016', 0.036 ).
abhangigkeitkurse('mei001', 'mei017', 0.143 ).
abhangigkeitkurse('mei001', 'mei018', 0.286 ).
abhangigkeitkurse('mei001', 'mei019', 0.000 ).
abhangigkeitkurse('mei001', 'mei020', 0.000 ).
abhangigkeitkurse('mei001', 'mei021', 0.143 ).
abhangigkeitkurse('mei001', 'mei022', 0.000 ).
abhangigkeitkurse('mei001', 'mei023', 0.036 ).

% mei002 = Einf�hrung in das wissenschaftliche Arbeiten
abhangigkeitkurse('mei002', 'mei001', 0.000 ).
abhangigkeitkurse('mei002', 'mei002', 0.000 ).
abhangigkeitkurse('mei002', 'mei003', 0.036 ).
abhangigkeitkurse('mei002', 'mei004', 0.041 ).
abhangigkeitkurse('mei002', 'mei005', 0.214 ).
abhangigkeitkurse('mei002', 'mei006', 0.000 ).
abhangigkeitkurse('mei002', 'mei007', 0.214 ).
abhangigkeitkurse('mei002', 'mei008', 0.000 ).
abhangigkeitkurse('mei002', 'mei009', 0.000 ).
abhangigkeitkurse('mei002', 'mei010', 0.000 ).
abhangigkeitkurse('mei002', 'mei011', 0.000 ).
abhangigkeitkurse('mei002', 'mei012', 0.214 ).
abhangigkeitkurse('mei002', 'mei013', 0.000 ).
abhangigkeitkurse('mei002', 'mei014', 0.000 ).
abhangigkeitkurse('mei002', 'mei015', 0.214 ).
abhangigkeitkurse('mei002', 'mei016', 0.071 ).
abhangigkeitkurse('mei002', 'mei017', 0.786 ).
abhangigkeitkurse('mei002', 'mei018', 0.357 ).
abhangigkeitkurse('mei002', 'mei019', 0.107 ).
abhangigkeitkurse('mei002', 'mei020', 0.000 ).
abhangigkeitkurse('mei002', 'mei021', 0.000 ).
abhangigkeitkurse('mei002', 'mei022', 0.100 ).
abhangigkeitkurse('mei002', 'mei023', 0.036 ).

% mei003 = Mathematik f�r Medieninformatiker I
abhangigkeitkurse('mei003', 'mei001', 0.000 ).
abhangigkeitkurse('mei003', 'mei002', 0.786 ).
abhangigkeitkurse('mei003', 'mei003', 0.012 ).
abhangigkeitkurse('mei003', 'mei004', 0.000 ).
abhangigkeitkurse('mei003', 'mei005', 0.000 ).
abhangigkeitkurse('mei003', 'mei006', 0.036 ).
abhangigkeitkurse('mei003', 'mei007', 0.214 ).
abhangigkeitkurse('mei003', 'mei008', 0.143 ).
abhangigkeitkurse('mei003', 'mei009', 0.000 ).
abhangigkeitkurse('mei003', 'mei010', 0.143 ).
abhangigkeitkurse('mei003', 'mei011', 0.000 ).
abhangigkeitkurse('mei003', 'mei012', 0.000 ).
abhangigkeitkurse('mei003', 'mei013', 0.000 ).
abhangigkeitkurse('mei003', 'mei014', 0.000 ).
abhangigkeitkurse('mei003', 'mei015', 0.000 ).
abhangigkeitkurse('mei003', 'mei016', 0.000 ).
abhangigkeitkurse('mei003', 'mei017', 0.000 ).
abhangigkeitkurse('mei003', 'mei018', 0.107 ).
abhangigkeitkurse('mei003', 'mei019', 0.036 ).
abhangigkeitkurse('mei003', 'mei020', 0.071 ).
abhangigkeitkurse('mei003', 'mei021', 0.036 ).
abhangigkeitkurse('mei003', 'mei022', 0.000 ).
abhangigkeitkurse('mei003', 'mei023', 0.000 ).

% mei004 = Mathematik f�r Medieninformatiker II
abhangigkeitkurse('mei004', 'mei001', 0.000 ).
abhangigkeitkurse('mei004', 'mei002', 0.000 ).
abhangigkeitkurse('mei004', 'mei003', 0.000 ).
abhangigkeitkurse('mei004', 'mei004', 0.071 ).
abhangigkeitkurse('mei004', 'mei005', 0.107 ).
abhangigkeitkurse('mei004', 'mei006', 0.036 ).
abhangigkeitkurse('mei004', 'mei007', 0.000 ).
abhangigkeitkurse('mei004', 'mei008', 0.000 ).
abhangigkeitkurse('mei004', 'mei009', 0.000 ).
abhangigkeitkurse('mei004', 'mei010', 0.000 ).
abhangigkeitkurse('mei004', 'mei011', 0.107 ).
abhangigkeitkurse('mei004', 'mei012', 0.036 ).
abhangigkeitkurse('mei004', 'mei013', 0.000 ).
abhangigkeitkurse('mei004', 'mei014', 0.000 ).
abhangigkeitkurse('mei004', 'mei015', 0.000 ).
abhangigkeitkurse('mei004', 'mei016', 0.000 ).
abhangigkeitkurse('mei004', 'mei017', 0.214 ).
abhangigkeitkurse('mei004', 'mei018', 0.107 ).
abhangigkeitkurse('mei004', 'mei019', 0.107 ).
abhangigkeitkurse('mei004', 'mei020', 0.214 ).
abhangigkeitkurse('mei004', 'mei021', 0.179 ).
abhangigkeitkurse('mei004', 'mei022', 0.036 ).
abhangigkeitkurse('mei004', 'mei023', 0.000 ).


% mei005 = Einf�hrung inh die Programmierung und Programmiersprachen
abhangigkeitkurse('mei005', 'mei001', 0.000 ).
abhangigkeitkurse('mei005', 'mei002', 0.000 ).
abhangigkeitkurse('mei005', 'mei003', 0.000 ).
abhangigkeitkurse('mei005', 'mei004', 0.000 ).
abhangigkeitkurse('mei005', 'mei005', 0.107 ).
abhangigkeitkurse('mei005', 'mei006', 0.000 ).
abhangigkeitkurse('mei005', 'mei007', 0.000 ).
abhangigkeitkurse('mei005', 'mei008', 0.214 ).
abhangigkeitkurse('mei005', 'mei009', 0.214 ).
abhangigkeitkurse('mei005', 'mei010', 0.214 ).
abhangigkeitkurse('mei005', 'mei011', 0.000 ).
abhangigkeitkurse('mei005', 'mei012', 0.000 ).
abhangigkeitkurse('mei005', 'mei013', 0.107 ).
abhangigkeitkurse('mei005', 'mei014', 0.214 ).
abhangigkeitkurse('mei005', 'mei015', 0.107 ).
abhangigkeitkurse('mei005', 'mei016', 0.036 ).
abhangigkeitkurse('mei005', 'mei017', 0.000 ).
abhangigkeitkurse('mei005', 'mei018', 0.000 ).
abhangigkeitkurse('mei005', 'mei019', 0.000 ).
abhangigkeitkurse('mei005', 'mei020', 0.000 ).
abhangigkeitkurse('mei005', 'mei021', 0.000 ).
abhangigkeitkurse('mei005', 'mei022', 0.000 ).
abhangigkeitkurse('mei005', 'mei023', 0.000 ).

% mei006 = Algorithmen und Datenstrukturen
abhangigkeitkurse('mei006', 'mei001', 0.000 ).
abhangigkeitkurse('mei006', 'mei002', 0.000 ).
abhangigkeitkurse('mei006', 'mei003', 0.000 ).
abhangigkeitkurse('mei006', 'mei004', 0.107).
abhangigkeitkurse('mei006', 'mei005', 0.214 ).
abhangigkeitkurse('mei006', 'mei006', 0.107 ).
abhangigkeitkurse('mei006', 'mei007', 0.036 ).
abhangigkeitkurse('mei006', 'mei008', 0.107 ).
abhangigkeitkurse('mei006', 'mei009', 0.000 ).
abhangigkeitkurse('mei006', 'mei010', 0.000 ).
abhangigkeitkurse('mei006', 'mei011', 0.000 ).
abhangigkeitkurse('mei006', 'mei012', 0.000 ).
abhangigkeitkurse('mei006', 'mei013', 0.214 ).
abhangigkeitkurse('mei006', 'mei014', 0.214 ).
abhangigkeitkurse('mei006', 'mei015', 0.036 ).
abhangigkeitkurse('mei006', 'mei016', 0.179 ).
abhangigkeitkurse('mei006', 'mei017', 0.214 ).
abhangigkeitkurse('mei006', 'mei018', 0.000 ).
abhangigkeitkurse('mei006', 'mei019', 0.000 ).
abhangigkeitkurse('mei006', 'mei020', 0.000 ).
abhangigkeitkurse('mei006', 'mei021', 0.000 ).
abhangigkeitkurse('mei006', 'mei022', 0.000 ).
abhangigkeitkurse('mei006', 'mei023', 0.000 ).

% mei007 = Einf�hrung in die Anwendungsprogrammierung mit begleitendem Softwarepraktikum
abhangigkeitkurse('mei007', 'mei001', 0.000 ).
abhangigkeitkurse('mei007', 'mei002', 0.000 ).
abhangigkeitkurse('mei007', 'mei003', 0.000 ).
abhangigkeitkurse('mei007', 'mei004', 0.000 ).
abhangigkeitkurse('mei007', 'mei005', 0.000 ).
abhangigkeitkurse('mei007', 'mei006', 0.179 ).
abhangigkeitkurse('mei007', 'mei007', 0.000 ).
abhangigkeitkurse('mei007', 'mei008', 0.000 ).
abhangigkeitkurse('mei007', 'mei009', 0.000 ).
abhangigkeitkurse('mei007', 'mei010', 0.143 ).
abhangigkeitkurse('mei007', 'mei011', 0.214 ).
abhangigkeitkurse('mei007', 'mei012', 0.214 ).
abhangigkeitkurse('mei007', 'mei013', 0.036 ).
abhangigkeitkurse('mei007', 'mei014', 0.000 ).
abhangigkeitkurse('mei007', 'mei015', 0.036 ).
abhangigkeitkurse('mei007', 'mei016', 0.000 ).
abhangigkeitkurse('mei007', 'mei017', 0.000 ).
abhangigkeitkurse('mei007', 'mei018', 0.000 ).
abhangigkeitkurse('mei007', 'mei019', 0.000 ).
abhangigkeitkurse('mei007', 'mei020', 0.000 ).
abhangigkeitkurse('mei007', 'mei021', 0.107 ).
abhangigkeitkurse('mei007', 'mei022', 0.107 ).
abhangigkeitkurse('mei007', 'mei023', 0.107 ).

% mei008 = Multimedia Technology
abhangigkeitkurse('mei008', 'mei001', 0.000 ).
abhangigkeitkurse('mei008', 'mei002', 0.000 ).
abhangigkeitkurse('mei008', 'mei003', 0.000 ).
abhangigkeitkurse('mei008', 'mei004', 0.214 ).
abhangigkeitkurse('mei008', 'mei005', 0.214 ).
abhangigkeitkurse('mei008', 'mei006', 0.000 ).
abhangigkeitkurse('mei008', 'mei007', 0.179 ).
abhangigkeitkurse('mei008', 'mei008', 0.214 ).
abhangigkeitkurse('mei008', 'mei009', 0.214 ).
abhangigkeitkurse('mei008', 'mei010', 0.107 ).
abhangigkeitkurse('mei008', 'mei011', 0.000 ).
abhangigkeitkurse('mei008', 'mei012', 0.000 ).
abhangigkeitkurse('mei008', 'mei013', 0.000 ).
abhangigkeitkurse('mei008', 'mei014', 0.000 ).
abhangigkeitkurse('mei008', 'mei015', 0.000 ).
abhangigkeitkurse('mei008', 'mei016', 0.036 ).
abhangigkeitkurse('mei008', 'mei017', 0.000 ).
abhangigkeitkurse('mei008', 'mei018', 0.000 ).
abhangigkeitkurse('mei008', 'mei019', 0.000 ).
abhangigkeitkurse('mei008', 'mei020', 0.000 ).
abhangigkeitkurse('mei008', 'mei021', 0.214 ).
abhangigkeitkurse('mei008', 'mei022', 0.036 ).
abhangigkeitkurse('mei008', 'mei023', 0.719 ).


% mei009 = Multimedia Informationssystem und Datenbanken
abhangigkeitkurse('mei009', 'mei001', 0.000 ).
abhangigkeitkurse('mei009', 'mei002', 0.000 ).
abhangigkeitkurse('mei009', 'mei003', 0.214 ).
abhangigkeitkurse('mei009', 'mei004', 0.107 ).
abhangigkeitkurse('mei009', 'mei005', 0.000 ).
abhangigkeitkurse('mei009', 'mei006', 0.000 ).
abhangigkeitkurse('mei009', 'mei007', 0.000 ).
abhangigkeitkurse('mei009', 'mei008', 0.107 ).
abhangigkeitkurse('mei009', 'mei009', 0.214 ).
abhangigkeitkurse('mei009', 'mei010', 0.357 ).
abhangigkeitkurse('mei009', 'mei011', 0.357 ).
abhangigkeitkurse('mei009', 'mei012', 0.643 ).
abhangigkeitkurse('mei009', 'mei013', 0.107 ).
abhangigkeitkurse('mei009', 'mei014', 0.000 ).
abhangigkeitkurse('mei009', 'mei015', 0.000 ).
abhangigkeitkurse('mei009', 'mei016', 0.000 ).
abhangigkeitkurse('mei009', 'mei017', 0.000 ).
abhangigkeitkurse('mei009', 'mei018', 0.500 ).
abhangigkeitkurse('mei009', 'mei019', 0.000 ).
abhangigkeitkurse('mei009', 'mei020', 0.000 ).
abhangigkeitkurse('mei009', 'mei021', 0.107 ).
abhangigkeitkurse('mei009', 'mei022', 0.214 ).
abhangigkeitkurse('mei009', 'mei023', 0.643 ).




% mei010 = Multimedia Engineering mit begleitendem Praktikum
abhangigkeitkurse('mei010', 'mei001', 0.000 ).
abhangigkeitkurse('mei010', 'mei002', 0.000 ).
abhangigkeitkurse('mei010', 'mei003', 0.036 ).
abhangigkeitkurse('mei010', 'mei004', 0.214 ).
abhangigkeitkurse('mei010', 'mei005', 0.250 ).
abhangigkeitkurse('mei010', 'mei006', 0.250 ).
abhangigkeitkurse('mei010', 'mei007', 0.036 ).
abhangigkeitkurse('mei010', 'mei008', 0.000 ).
abhangigkeitkurse('mei010', 'mei009', 0.000 ).
abhangigkeitkurse('mei010', 'mei010', 0.000 ).
abhangigkeitkurse('mei010', 'mei011', 0.000 ).
abhangigkeitkurse('mei010', 'mei012', 0.000 ).
abhangigkeitkurse('mei010', 'mei013', 0.000 ).
abhangigkeitkurse('mei010', 'mei014', 0.000 ).
abhangigkeitkurse('mei010', 'mei015', 0.107 ).
abhangigkeitkurse('mei010', 'mei016', 0.036 ).
abhangigkeitkurse('mei010', 'mei017', 0.000 ).
abhangigkeitkurse('mei010', 'mei018', 0.214 ).
abhangigkeitkurse('mei010', 'mei019', 0.036 ).
abhangigkeitkurse('mei010', 'mei020', 0.000 ).
abhangigkeitkurse('mei010', 'mei021', 0.000 ).
abhangigkeitkurse('mei010', 'mei022', 0.000 ).
abhangigkeitkurse('mei010', 'mei023', 0.000 ).



% mei011 = Grundlagen der Human-Computer-Interaction
abhangigkeitkurse('mei011', 'mei001', 0.000 ).
abhangigkeitkurse('mei011', 'mei002', 0.000 ).
abhangigkeitkurse('mei011', 'mei003', 0.000 ).
abhangigkeitkurse('mei011', 'mei004', 0.000 ).
abhangigkeitkurse('mei011', 'mei005', 0.000 ).
abhangigkeitkurse('mei011', 'mei006', 0.000 ).
abhangigkeitkurse('mei011', 'mei007', 0.000 ).
abhangigkeitkurse('mei011', 'mei008', 0.000 ).
abhangigkeitkurse('mei011', 'mei009', 0.214 ).
abhangigkeitkurse('mei011', 'mei010', 0.143 ).
abhangigkeitkurse('mei011', 'mei011', 0.036 ).
abhangigkeitkurse('mei011', 'mei012', 0.143 ).
abhangigkeitkurse('mei011', 'mei013', 0.286 ).
abhangigkeitkurse('mei011', 'mei014', 0.143 ).
abhangigkeitkurse('mei011', 'mei015', 0.143 ).
abhangigkeitkurse('mei011', 'mei016', 0.179 ).
abhangigkeitkurse('mei011', 'mei017', 0.036 ).
abhangigkeitkurse('mei011', 'mei018', 0.036 ).
abhangigkeitkurse('mei011', 'mei019', 0.036 ).
abhangigkeitkurse('mei011', 'mei020', 0.000 ).
abhangigkeitkurse('mei011', 'mei021', 0.000 ).
abhangigkeitkurse('mei011', 'mei022', 0.000 ).
abhangigkeitkurse('mei011', 'mei023', 0.036 ).


% mei012 = Usability Engineering
abhangigkeitkurse('mei012', 'mei001', 0.000 ).
abhangigkeitkurse('mei012', 'mei002', 0.000 ).
abhangigkeitkurse('mei012', 'mei003', 0.000 ).
abhangigkeitkurse('mei012', 'mei004', 0.000 ).
abhangigkeitkurse('mei012', 'mei005', 0.000 ).
abhangigkeitkurse('mei012', 'mei006', 0.000 ).
abhangigkeitkurse('mei012', 'mei007', 0.107 ).
abhangigkeitkurse('mei012', 'mei008', 0.000 ).
abhangigkeitkurse('mei012', 'mei009', 0.000 ).
abhangigkeitkurse('mei012', 'mei010', 0.000 ).
abhangigkeitkurse('mei012', 'mei011', 0.000 ).
abhangigkeitkurse('mei012', 'mei012', 0.000 ).
abhangigkeitkurse('mei012', 'mei013', 0.000 ).
abhangigkeitkurse('mei012', 'mei014', 0.036 ).
abhangigkeitkurse('mei012', 'mei015', 0.036 ).
abhangigkeitkurse('mei012', 'mei016', 0.036 ).
abhangigkeitkurse('mei012', 'mei017', 0.000 ).
abhangigkeitkurse('mei012', 'mei018', 0.000 ).
abhangigkeitkurse('mei012', 'mei019', 0.000 ).
abhangigkeitkurse('mei012', 'mei020', 0.036 ).
abhangigkeitkurse('mei012', 'mei021', 0.036 ).
abhangigkeitkurse('mei012', 'mei022', 0.107 ).
abhangigkeitkurse('mei012', 'mei023', 0.107 ).




% mei013 = Projektseminar Mediengestaltung Usability Engineering
abhangigkeitkurse('mei013', 'mei001', 0.000 ).
abhangigkeitkurse('mei013', 'mei002', 0.000 ).
abhangigkeitkurse('mei013', 'mei003', 0.107 ).
abhangigkeitkurse('mei013', 'mei004', 0.000 ).
abhangigkeitkurse('mei013', 'mei005', 0.036 ).
abhangigkeitkurse('mei013', 'mei006', 0.036 ).
abhangigkeitkurse('mei013', 'mei007', 0.000 ).
abhangigkeitkurse('mei013', 'mei008', 0.000 ).
abhangigkeitkurse('mei013', 'mei009', 0.000 ).
abhangigkeitkurse('mei013', 'mei010', 0.107 ).
abhangigkeitkurse('mei013', 'mei011', 0.000 ).
abhangigkeitkurse('mei013', 'mei012', 0.000 ).
abhangigkeitkurse('mei013', 'mei013', 0.000 ).
abhangigkeitkurse('mei013', 'mei014', 0.214 ).
abhangigkeitkurse('mei013', 'mei015', 0.107 ).
abhangigkeitkurse('mei013', 'mei016', 0.000 ).
abhangigkeitkurse('mei013', 'mei017', 0.000 ).
abhangigkeitkurse('mei013', 'mei018', 0.214 ).
abhangigkeitkurse('mei013', 'mei019', 0.107 ).
abhangigkeitkurse('mei013', 'mei020', 0.000 ).
abhangigkeitkurse('mei013', 'mei021', 0.000 ).
abhangigkeitkurse('mei013', 'mei022', 0.000 ).
abhangigkeitkurse('mei013', 'mei023', 0.000 ).


% mei014 = Einf�hrung in die Programmierung und Programmiersprache
abhangigkeitkurse('mei014', 'mei001', 0.000 ).
abhangigkeitkurse('mei014', 'mei002', 0.000 ).
abhangigkeitkurse('mei014', 'mei003', 0.107 ).
abhangigkeitkurse('mei014', 'mei004', 0.000 ).
abhangigkeitkurse('mei014', 'mei005', 0.000 ).
abhangigkeitkurse('mei014', 'mei006', 0.000 ).
abhangigkeitkurse('mei014', 'mei007', 0.000 ).
abhangigkeitkurse('mei014', 'mei008', 0.107 ).
abhangigkeitkurse('mei014', 'mei009', 0.036 ).
abhangigkeitkurse('mei014', 'mei010', 0.036 ).
abhangigkeitkurse('mei014', 'mei011', 0.000 ).
abhangigkeitkurse('mei014', 'mei012', 0.000 ).
abhangigkeitkurse('mei014', 'mei013', 0.000 ).
abhangigkeitkurse('mei014', 'mei014', 0.036 ).
abhangigkeitkurse('mei014', 'mei015', 0.214 ).
abhangigkeitkurse('mei014', 'mei016', 0.000 ).
abhangigkeitkurse('mei014', 'mei017', 0.000 ).
abhangigkeitkurse('mei014', 'mei018', 0.000 ).
abhangigkeitkurse('mei014', 'mei019', 0.250 ).
abhangigkeitkurse('mei014', 'mei020', 0.250 ).
abhangigkeitkurse('mei014', 'mei021', 0.000 ).
abhangigkeitkurse('mei014', 'mei022', 0.000 ).
abhangigkeitkurse('mei014', 'mei023', 0.000 ).


% mei015 = �bung zur Anwendungsprogrammierung mit begleitendem Softwareentwicklungspraktikum
abhangigkeitkurse('mei015', 'mei001', 0.000 ).
abhangigkeitkurse('mei015', 'mei002', 0.036 ).
abhangigkeitkurse('mei015', 'mei003', 0.036 ).
abhangigkeitkurse('mei015', 'mei004', 0.214 ).
abhangigkeitkurse('mei015', 'mei005', 0.214 ).
abhangigkeitkurse('mei015', 'mei006', 0.107 ).
abhangigkeitkurse('mei015', 'mei007', 0.107 ).
abhangigkeitkurse('mei015', 'mei008', 0.107 ).
abhangigkeitkurse('mei015', 'mei009', 0.000 ).
abhangigkeitkurse('mei015', 'mei010', 0.000 ).
abhangigkeitkurse('mei015', 'mei011', 0.000 ).
abhangigkeitkurse('mei015', 'mei012', 0.000 ).
abhangigkeitkurse('mei015', 'mei013', 0.036 ).
abhangigkeitkurse('mei015', 'mei014', 0.036 ).
abhangigkeitkurse('mei015', 'mei015', 0.000 ).
abhangigkeitkurse('mei015', 'mei016', 0.000 ).
abhangigkeitkurse('mei015', 'mei017', 0.000 ).
abhangigkeitkurse('mei015', 'mei018', 0.000 ).
abhangigkeitkurse('mei015', 'mei019', 0.036 ).
abhangigkeitkurse('mei015', 'mei020', 0.000 ).
abhangigkeitkurse('mei015', 'mei021', 0.000 ).
abhangigkeitkurse('mei015', 'mei022', 0.000 ).
abhangigkeitkurse('mei015', 'mei023', 0.107 ).

% mei016 = Multimedia Technology
abhangigkeitkurse('mei016', 'mei001', 0.000 ).
abhangigkeitkurse('mei016', 'mei002', 0.000 ).
abhangigkeitkurse('mei016', 'mei003', 0.000 ).
abhangigkeitkurse('mei016', 'mei004', 0.000 ).
abhangigkeitkurse('mei016', 'mei005', 0.000 ).
abhangigkeitkurse('mei016', 'mei006', 0.000 ).
abhangigkeitkurse('mei016', 'mei007', 0.000 ).
abhangigkeitkurse('mei016', 'mei008', 0.000 ).
abhangigkeitkurse('mei016', 'mei009', 0.000 ).
abhangigkeitkurse('mei016', 'mei010', 0.000 ).
abhangigkeitkurse('mei016', 'mei011', 0.000 ).
abhangigkeitkurse('mei016', 'mei012', 0.000 ).
abhangigkeitkurse('mei016', 'mei013', 0.000 ).
abhangigkeitkurse('mei016', 'mei014', 0.000 ).
abhangigkeitkurse('mei016', 'mei015', 0.000 ).
abhangigkeitkurse('mei016', 'mei016', 0.000 ).
abhangigkeitkurse('mei016', 'mei017', 0.000 ).
abhangigkeitkurse('mei016', 'mei018', 0.000 ).
abhangigkeitkurse('mei016', 'mei019', 0.000 ).
abhangigkeitkurse('mei016', 'mei020', 0.000 ).
abhangigkeitkurse('mei016', 'mei021', 0.000 ).
abhangigkeitkurse('mei016', 'mei022', 0.000 ).
abhangigkeitkurse('mei016', 'mei023', 0.000 ).

% mei017 = Grundlagen Human-Computer-Interaction
abhangigkeitkurse('mei017', 'mei001', 0.000 ).
abhangigkeitkurse('mei017', 'mei002', 0.000 ).
abhangigkeitkurse('mei017', 'mei003', 0.107 ).
abhangigkeitkurse('mei017', 'mei004', 0.036 ).
abhangigkeitkurse('mei017', 'mei005', 0.000 ).
abhangigkeitkurse('mei017', 'mei006', 0.000 ).
abhangigkeitkurse('mei017', 'mei007', 0.000 ).
abhangigkeitkurse('mei017', 'mei008', 0.000 ).
abhangigkeitkurse('mei017', 'mei009', 0.107 ).
abhangigkeitkurse('mei017', 'mei010', 0.214 ).
abhangigkeitkurse('mei017', 'mei011', 0.000 ).
abhangigkeitkurse('mei017', 'mei012', 0.000 ).
abhangigkeitkurse('mei017', 'mei013', 0.000 ).
abhangigkeitkurse('mei017', 'mei014', 0.107 ).
abhangigkeitkurse('mei017', 'mei015', 0.000 ).
abhangigkeitkurse('mei017', 'mei016', 0.000 ).
abhangigkeitkurse('mei017', 'mei017', 0.000 ).
abhangigkeitkurse('mei017', 'mei018', 0.107 ).
abhangigkeitkurse('mei017', 'mei019', 0.214 ).
abhangigkeitkurse('mei017', 'mei020', 0.000 ).
abhangigkeitkurse('mei017', 'mei021', 0.000 ).
abhangigkeitkurse('mei017', 'mei022', 0.000 ).
abhangigkeitkurse('mei017', 'mei023', 0.036 ).


% mei018 = �bung im Bereich Webdesign
abhangigkeitkurse('mei018', 'mei001', 0.000 ).
abhangigkeitkurse('mei018', 'mei002', 0.000 ).
abhangigkeitkurse('mei018', 'mei003', 0.036 ).
abhangigkeitkurse('mei018', 'mei004', 0.107 ).
abhangigkeitkurse('mei018', 'mei005', 0.000 ).
abhangigkeitkurse('mei018', 'mei006', 0.000 ).
abhangigkeitkurse('mei018', 'mei007', 0.214 ).
abhangigkeitkurse('mei018', 'mei008', 0.000 ).
abhangigkeitkurse('mei018', 'mei009', 0.000 ).
abhangigkeitkurse('mei018', 'mei010', 0.000 ).
abhangigkeitkurse('mei018', 'mei011', 0.036 ).
abhangigkeitkurse('mei018', 'mei012', 0.107 ).
abhangigkeitkurse('mei018', 'mei013', 0.000 ).
abhangigkeitkurse('mei018', 'mei014', 0.000 ).
abhangigkeitkurse('mei018', 'mei015', 0.000 ).
abhangigkeitkurse('mei018', 'mei016', 0.036 ).
abhangigkeitkurse('mei018', 'mei017', 0.000 ).
abhangigkeitkurse('mei018', 'mei018', 0.000 ).
abhangigkeitkurse('mei018', 'mei019', 0.000 ).
abhangigkeitkurse('mei018', 'mei020', 0.000 ).
abhangigkeitkurse('mei018', 'mei021', 0.107 ).
abhangigkeitkurse('mei018', 'mei022', 0.107 ).
abhangigkeitkurse('mei018', 'mei023', 0.000 ).


% mei019 = Multimedia Technology
abhangigkeitkurse('mei019', 'mei001', 0.000 ).
abhangigkeitkurse('mei019', 'mei002', 0.000 ).
abhangigkeitkurse('mei019', 'mei003', 0.000 ).
abhangigkeitkurse('mei019', 'mei004', 0.000 ).
abhangigkeitkurse('mei019', 'mei005', 0.107 ).
abhangigkeitkurse('mei019', 'mei006', 0.036 ).
abhangigkeitkurse('mei019', 'mei007', 0.214 ).
abhangigkeitkurse('mei019', 'mei008', 0.000 ).
abhangigkeitkurse('mei019', 'mei009', 0.000 ).
abhangigkeitkurse('mei019', 'mei010', 0.107 ).
abhangigkeitkurse('mei019', 'mei011', 0.000 ).
abhangigkeitkurse('mei019', 'mei012', 0.000 ).
abhangigkeitkurse('mei019', 'mei013', 0.000 ).
abhangigkeitkurse('mei019', 'mei014', 0.000 ).
abhangigkeitkurse('mei019', 'mei015', 0.000 ).
abhangigkeitkurse('mei019', 'mei016', 0.107 ).
abhangigkeitkurse('mei019', 'mei017', 0.107 ).
abhangigkeitkurse('mei019', 'mei018', 0.036 ).
abhangigkeitkurse('mei019', 'mei019', 0.000 ).
abhangigkeitkurse('mei019', 'mei020', 0.000 ).
abhangigkeitkurse('mei019', 'mei021', 0.000 ).
abhangigkeitkurse('mei019', 'mei022', 0.036 ).
abhangigkeitkurse('mei019', 'mei023', 0.000 ).


% mei020 = Multimedia Informationssysteme und Datenbanken
abhangigkeitkurse('mei020', 'mei001', 0.000 ).
abhangigkeitkurse('mei020', 'mei002', 0.000 ).
abhangigkeitkurse('mei020', 'mei003', 0.107 ).
abhangigkeitkurse('mei020', 'mei004', 0.107 ).
abhangigkeitkurse('mei020', 'mei005', 0.036 ).
abhangigkeitkurse('mei020', 'mei006', 0.036 ).
abhangigkeitkurse('mei020', 'mei007', 0.036 ).
abhangigkeitkurse('mei020', 'mei008', 0.000 ).
abhangigkeitkurse('mei020', 'mei009', 0.000 ).
abhangigkeitkurse('mei020', 'mei010', 0.000 ).
abhangigkeitkurse('mei020', 'mei011', 0.000 ).
abhangigkeitkurse('mei020', 'mei012', 0.036 ).
abhangigkeitkurse('mei020', 'mei013', 0.107 ).
abhangigkeitkurse('mei020', 'mei014', 0.107 ).
abhangigkeitkurse('mei020', 'mei015', 0.214 ).
abhangigkeitkurse('mei020', 'mei016', 0.000 ).
abhangigkeitkurse('mei020', 'mei017', 0.000 ).
abhangigkeitkurse('mei020', 'mei018', 0.000 ).
abhangigkeitkurse('mei020', 'mei019', 0.000 ).
abhangigkeitkurse('mei020', 'mei020', 0.000 ).
abhangigkeitkurse('mei020', 'mei021', 0.000 ).
abhangigkeitkurse('mei020', 'mei022', 0.000 ).
abhangigkeitkurse('mei020', 'mei023', 0.000 ).

% mei021 = Einf�hrungsvorlesung Anwendungsschwerpunkt mit �bungen
abhangigkeitkurse('mei021', 'mei001', 0.000 ).
abhangigkeitkurse('mei021', 'mei002', 0.000 ).
abhangigkeitkurse('mei021', 'mei003', 0.000 ).
abhangigkeitkurse('mei021', 'mei004', 0.000 ).
abhangigkeitkurse('mei021', 'mei005', 0.000 ).
abhangigkeitkurse('mei021', 'mei006', 0.000 ).
abhangigkeitkurse('mei021', 'mei007', 0.000 ).
abhangigkeitkurse('mei021', 'mei008', 0.000 ).
abhangigkeitkurse('mei021', 'mei009', 0.000 ).
abhangigkeitkurse('mei021', 'mei010', 0.000 ).
abhangigkeitkurse('mei021', 'mei011', 0.000 ).
abhangigkeitkurse('mei021', 'mei012', 0.000 ).
abhangigkeitkurse('mei021', 'mei013', 0.000 ).
abhangigkeitkurse('mei021', 'mei014', 0.000 ).
abhangigkeitkurse('mei021', 'mei015', 0.000 ).
abhangigkeitkurse('mei021', 'mei016', 0.000 ).
abhangigkeitkurse('mei021', 'mei017', 0.000 ).
abhangigkeitkurse('mei021', 'mei018', 0.000 ).
abhangigkeitkurse('mei021', 'mei019', 0.000 ).
abhangigkeitkurse('mei021', 'mei020', 0.000 ).
abhangigkeitkurse('mei021', 'mei021', 0.000 ).
abhangigkeitkurse('mei021', 'mei022', 0.000 ).
abhangigkeitkurse('mei021', 'mei023', 0.000 ).

% mei022 = Vertiefungsvorlesung Anwendungsmodul mit �bungen
abhangigkeitkurse('mei022', 'mei001', 0.000 ).
abhangigkeitkurse('mei022', 'mei002', 0.107 ).
abhangigkeitkurse('mei022', 'mei003', 0.036 ).
abhangigkeitkurse('mei022', 'mei004', 0.000 ).
abhangigkeitkurse('mei022', 'mei005', 0.107 ).
abhangigkeitkurse('mei022', 'mei006', 0.143 ).
abhangigkeitkurse('mei022', 'mei007', 0.000 ).
abhangigkeitkurse('mei022', 'mei008', 0.000 ).
abhangigkeitkurse('mei022', 'mei009', 0.000 ).
abhangigkeitkurse('mei022', 'mei010', 0.000 ).
abhangigkeitkurse('mei022', 'mei011', 0.036 ).
abhangigkeitkurse('mei022', 'mei012', 0.036 ).
abhangigkeitkurse('mei022', 'mei013', 0.000 ).
abhangigkeitkurse('mei022', 'mei014', 0.107 ).
abhangigkeitkurse('mei022', 'mei015', 0.000 ).
abhangigkeitkurse('mei022', 'mei016', 0.000 ).
abhangigkeitkurse('mei022', 'mei017', 0.000 ).
abhangigkeitkurse('mei022', 'mei018', 0.000 ).
abhangigkeitkurse('mei022', 'mei019', 0.143 ).
abhangigkeitkurse('mei022', 'mei020', 0.036 ).
abhangigkeitkurse('mei022', 'mei021', 0.107 ).
abhangigkeitkurse('mei022', 'mei022', 0.000 ).
abhangigkeitkurse('mei022', 'mei023', 0.000 ).

% mei023 = Projektbezogenes Seminar im Anwendungsmodul
abhangigkeitkurse('mei023', 'mei001', 0.000 ).
abhangigkeitkurse('mei023', 'mei002', 0.000 ).
abhangigkeitkurse('mei023', 'mei003', 0.000 ).
abhangigkeitkurse('mei023', 'mei004', 0.000 ).
abhangigkeitkurse('mei023', 'mei005', 0.000 ).
abhangigkeitkurse('mei023', 'mei006', 0.000 ).
abhangigkeitkurse('mei023', 'mei007', 0.000 ).
abhangigkeitkurse('mei023', 'mei008', 0.000 ).
abhangigkeitkurse('mei023', 'mei009', 0.000 ).
abhangigkeitkurse('mei023', 'mei010', 0.000 ).
abhangigkeitkurse('mei023', 'mei011', 0.000 ).
abhangigkeitkurse('mei023', 'mei012', 0.000 ).
abhangigkeitkurse('mei023', 'mei013', 0.107 ).
abhangigkeitkurse('mei023', 'mei014', 0.143 ).
abhangigkeitkurse('mei023', 'mei015', 0.000 ).
abhangigkeitkurse('mei023', 'mei016', 0.036 ).
abhangigkeitkurse('mei023', 'mei017', 0.000 ).
abhangigkeitkurse('mei023', 'mei018', 0.000 ).
abhangigkeitkurse('mei023', 'mei019', 0.107 ).
abhangigkeitkurse('mei023', 'mei020', 0.241 ).
abhangigkeitkurse('mei023', 'mei021', 0.000 ).
abhangigkeitkurse('mei023', 'mei022', 0.000 ).
abhangigkeitkurse('mei023', 'mei023', 0.000 ).

































