%%Regelabfragen f�r die Abh�ngigkeiten der Kurse und Modul

:-consult('vorlesungsverzeichnis.pl').
:-consult('Modul.pl').
:-consult('fachkombinationen.pl').
:-consult('fachkombi_modul.pl').
:-consult('Student_Fachkombi.pl').
:-consult('Modul_Kurse.pl').
:-consult('Student.pl').
:-consult('kurse_vorlesungsverzeichnis.pl').
:-consult('kurse.pl').
:-consult('abhaengigekurse.pl').
:-consult('Student_Kurse.pl').
:-consult('fachkombinationkurse.pl').




%%%%%  Startpunkt der Anwendung
%% Eingabeaufforderung der Matrikelnummer an den Benutzer und Einlesen
%% dieser. �ber berechneTurnus(Matr)wird die Abfragekette gestartet.
start:- clrsc,
	write('Bitte gib deine Matrikelnummer ein.'),
	read(Matr),
	berechneTurnus(Matr),
	!.

%Der Ausgabenbildschirm wird geleert und die Abfrage erscheint ganz oben
clrsc:-Escape_sequenz=[27,91,50,74],name(Ausgabe,Escape_sequenz),write(Ausgabe).

%%    Der Turnus wird aus der aktuellen Systemzeit berechnet- Das aktuelle Monat und das aktuelle Jahr werden extrahiert
berechneTurnus(Matr):-get_time(XM),stamp_date_time(XM,YM,local),date_time_value(month,YM,Monat),get_time(X),stamp_date_time(X,Y,local),date_time_value(year,Y,J),sub_string(J,2,2,0,Ja),string_to_atom(Ja,HV),atom_number(HV,Jahr),abfrageMonate(Jahr,Monat,Matr).


%% Abfrage des aktuellen Turnus nach Monaten -> Die Semester beginnen
%% hier jeweils um einen Monat fr�her und enden auch einen Monat fr�her.
%% Der Grund hierf�r ist, dass das Vorlesungsverzeichnis auch bereits
%%fr�her verf�gbar ist und nur dadurch eine richtige und zeitige Stundenplanung
%%gegeben ist.
abfrageMonate(Jahr,Monat,Matr):-(Monat >= 3,Monat =<8),Turnus = 'SS',berechneSemAnzahl(Jahr,Turnus,Matr).
abfrageMonate(Jahr,Monat,Matr):-(Monat >= 9,Monat =<12),Turnus ='WS',berechneSemAnzahl(Jahr,Turnus,Matr).
%% Bei den Monaten Januar bis Februar wird die Jahreszahl um eins
%% erniedrigt --> das Wintersemester wird immer mit der ersten
%% Jahreszahl verrechnet , z.B WS 12/13 ist dann WS 12
abfrageMonate(Jahr,Monat,Matr):-(Monat >= 1,Monat =<2),Turnus = 'WS',NewJahr = Jahr-1,berechneSemAnzahl(NewJahr,Turnus,Matr).


%%%%%%%	Berechung der Semesteranzahl
% Berechnung: Bei selben Turnus bei Beginn des Studiums und des aktuellen
% Turnus
berechneSemAnzahl(Jahr,Turnus,Matr):-student(Matr,_,_,SB),sub_string(SB,0,2,2,Se),string_to_atom(Se,Sem),nl,student(Matr,_,_,S),sub_string(S,2,2,0,Semjahr),string_to_atom(Semjahr,HV),atom_number(HV,SeJahr),nl,Sem=Turnus,AktuSem is ((Jahr-SeJahr)*2+1),kursaufruf(AktuSem,Matr).
%%	Berechnungen bei unterschiedlichem Turnus
berechneSemAnzahl(Jahr,Turnus,Matr):-!,student(Matr,_,_,SB),sub_string(SB,0,2,2,Se),string_to_atom(Se,Sem),nl,student(Matr,_,_,S),sub_string(S,2,2,0,Semjahr),string_to_atom(Semjahr,HV),atom_number(HV,SeJahr),nl,Turnus=='SS',Sem=='WS',AktuSem is ((Jahr-SeJahr)*2),kursaufruf(AktuSem,Matr).
berechneSemAnzahl(Jahr,Turnus,Matr):-!,student(Matr,_,_,SB),sub_string(SB,0,2,2,Se),string_to_atom(Se,Sem),nl,student(Matr,_,_,S),sub_string(S,2,2,0,Semjahr),string_to_atom(Semjahr,HV),atom_number(HV,SeJahr),nl,Turnus=='WS',Sem=='SS',AktuSem is((Jahr-SeJahr)*2+2),kursaufruf(AktuSem,Matr).


%%%%%%%	Festlegung der Ebenen nach dem jeweiligen Semester und
%	gleichzeitige Ausgabe von Warnungen und Informationen zu den
%	Grundlagen- und Orientierungspr�fungen und dem
%	Fachkomabinationen.
kursaufruf(1,Matr):-kombi(Matr,1);student(Matr,Nname,Vname,_),student_fachkombi(Matr,Kombinr),fachkombination(Kombinr,_,_,_,_),write('Hallo '),write(Vname),write(' '),write(Nname),write(', '),nl,ausnahmen(Kombinr),nl,fachinfo(Kombinr),nl,gesamtLP(Matr);!.

%%	Ab 2ten Semester werden die Ebenen 1 und 2 durchlaufen.
kursaufruf(AktuSem,Matr):-AktuSem ==2,Ebene='E1',kombi(Matr,AktuSem,Ebene).
kursaufruf(AktuSem,Matr):-AktuSem ==2,Ebene='E2',kombi(Matr,AktuSem,Ebene).
kursaufruf(AktuSem,Matr):-AktuSem ==2,student(Matr,Nname,Vname,_),student_fachkombi(Matr,Kombinr),fachkombination(Kombinr,_,_,_,_),write('Hallo'),write(Vname),write(' '),write(Nname),write(', '),nl,ausnahmen(Kombinr),nl,fachinfo(Kombinr),nl,gesamtLP(Matr).
% %	Ab dem dritten Semester werden die Ebenen 1 bis 3 durchlaufen.
kursaufruf(AktuSem,Matr):-AktuSem >=3,Ebene='E1',kombi(Matr,AktuSem,Ebene).
kursaufruf(AktuSem,Matr):-AktuSem >=3,Ebene='E2',kombi(Matr,AktuSem,Ebene).
kursaufruf(AktuSem,Matr):-AktuSem >=3,Ebene='E3',kombi(Matr,AktuSem,Ebene);student(Matr,Nname,Vname,_),student_fachkombi(Matr,Kombinr),fachkombination(Kombinr,_,_,_,_),write('Hallo '),write(Vname),write(', '),write(Nname),write(' '),nl,ausnahmen(Kombinr),nl,fachinfo(Kombinr),nl,gesamtLP(Matr).


%Kombi f�r Erstsemester.
kombi(Matr,1):-student_fachkombi(Matr,Kombinr),fachkombination(Kombinr,_,_,_,_),!,kurswahlersti(Kombinr,Matr,0).

% Kombi f�r fortgeschrittenen Student
kombi(Matr,AktuSem,Ebene):-student_fachkombi(Matr,Kombinr),fachkombination(Kombinr,_,_,_,_),!,kurswahlfort(Kombinr,Matr,AktuSem,0,Ebene).




%%%%%%%%%%%Kriterien�berpr�fung Erstsemester:


%%	 Kursauswahl des Erstsemesters mit gleichzeitigen Abgleich des aktuellen
%%	 Vorlesungsverzeichnisses und nur Kurse der Ebene 1 werden ber�cksicht..
kurswahlersti(Fach,Matr,N):-!,student_fachkombi(Matr,Fach),fachkombi_modul(Fach,X,_),modul_kurse(X,Kursid,_,_),kurse(Kursid,_,_,'E1'),kurse_vorlesungsverzeichnis(VL,Kursid,_,_),vorlesungaktuell(VL,_,VLName),nl,anfangskurse(Kursid,N,Matr,Fach,VLName),nl,fail.


%Einf�hrungskurse werden h�her bewertet, da diese sehr wichtig sind.
anfangskurse(Kursid,N,Matr,Fach,VLName):-kurse(Kursid,_,'Einfuehrung',_),X is N+1,nl,leistungersti(Kursid,X,Matr,Fach,VLName),!;X is N,leistungersti(Kursid,X,Matr,Fach,VLName).

%%  Leistungspunkte des aktuellen Kurses geteilt durch die gesamten LPs
%%  der aktuellen Ebene mal die Anzahl aller Kurse der ersten Ebene.
leistungersti(Kursid,N,Matr,Fach,VLName):-findall((LP),(kurse(KID,_,_,'E1'),modul_kurse(ID,KID,_,LP),fachkombi_modul(Fach,ID,_)),Liste),summe(Liste,A),anzahl(Liste,Anzahl),kurse(Kursid,_,_,'E1'),modul_kurse(_,Kursid,_,LP),X is N+((LP/A)*Anzahl),orientierungspruefungersti(Kursid,X,Fach,VLName);!.

%%	�berpr�fen ob der Kurs Teil der Grundlagen- und
%	Orientierungspr�fung ist --> Bei Erf�llung h�hergewichtung der
%	Priorit�t um 1.
orientierungspruefungersti(Kursid,N,Fach,VLName):-fachkombination_kurse(Fach,_,Kursid),kurse(Kursid,_,_,_),X is N +1,dbwriteersti(Kursid,X,VLName),!;dbwriteersti(Kursid,N,VLName).



%Schreiben der Kursdaten in die Datenbank.--> X bzw. Y bezeichnet die Priorit�t des Kurses --> wird hier nach der dritten %Position nach dem Koma abgeschnitten--die Daten werden dynamisch in die Datei Modul.pl geschrieben
dbwriteersti(Kursid,X,VLName):-nl,format(atom(Y),'~3f',X),kurse(Kursid,Kursname,_,_),modul_kurse(_,Kursid,Position,LP),asserta(ausgabe(Y-''-Kursname-''-VLName-''-LP-'LP'-''-Position)).







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Kriterien�berpr�fung f�r fortgeschrittenen Student
%
%%
%%	Kursauswahl mit gleichzeitigem Abgleich des
%	Vorlesungsverzeichnisses.
kurswahlfort(Fach,Matr,AktuSem,N,Ebene):-!,student_fachkombi(Matr,Fach),fachkombi_modul(Fach,X,_),modul(X,_),modul_kurse(X,Kursid,_,_),kurse(Kursid,_,_,Ebene),kurse_vorlesungsverzeichnis(VL,Kursid,_,_),sub_string(Kursid,3,3,0,KID),string_to_atom(KID,KuID),KuID \='000',vorlesungaktuell(VL,_,VLName),nl,orientierungspruefung(Kursid,N,Matr,AktuSem,Ebene,Fach,VLName),nl,fail.

%%	�berpr�fen ob der Kurs Teil der Grundlagen- und
%	Orientierungspr�fung ist --> Zuerst wird �berpr�ft ob der
%	Student das 3. Semester bereits erreicht hat. Bei bereits
%	belegten Kurs aus demselben Modul wird die Prorit�t um eins
%	erh�ht. Gibt es keinen bereits belegten Kurs ab dem dritten
%	Semester erfolgt wiederum eine Erh�hung der Priorit�t um eins.
orientierungspruefung(Kursid,N,Matr,AktuSem,Ebene,Fach,VLName):-AktuSem>=3,fachkombination_kurse(Fach,Modulid,ID),student_kurse(Matr,ID,'true',_,_,_),fachkombi_modul(Fach,Modulid,_),kurse(Kursid,_,_,_),modul_kurse(Modulid,Kursid,_,_), X is N +1,dritteEbene(Kursid,X,Matr,AktuSem,Ebene,Fach,VLName),!;
AktuSem>=3,fachkombination_kurse(Fach,_,Kursid),kurse(Kursid,_,_,_), X is N + 1,dritteEbene(Kursid,X,Matr,AktuSem,Ebene,Fach,VLName),!;
AktuSem>=2,fachkombination_kurse(Fach,Modulid,ID),student_kurse(Matr,ID,'true',_,_,_),fachkombi_modul(Fach,Modulid,_),kurse(Kursid,_,_,_),modul_kurse(Modulid,Kursid,_,_), X is N +1,dritteEbene(Kursid,X,Matr,AktuSem,Ebene,Fach,VLName),!;
AktuSem>=2,fachkombination_kurse(Fach,_,Kursid),kurse(Kursid,_,_,_), X is N +1,dritteEbene(Kursid,X,Matr,AktuSem,Ebene,Fach,VLName),!;dritteEbene(Kursid,N,Matr,AktuSem,Ebene,Fach,VLName).

% Kurse der dritten Ebene werden ab dem dritten Semester geringer
% Priorit�t versehen.
dritteEbene(Kursid,N,Matr,AktuSem,Ebene,Fach,VLName):-AktuSem >=3,kurse(Kursid,_,_,'E3'),X= N+0.1,zweiteEbene(Kursid,X,Matr,AktuSem,Ebene,Fach,VLName),!;
X is N,zweiteEbene(Kursid,X,Matr,AktuSem,Ebene,Fach,VLName).

% Kurse der zweiten Ebene werden ab dem dritten Semester geringer
% Priorit�t versehen.
zweiteEbene(Kursid,N,Matr,AktuSem,Ebene,Fach,VLName):-AktuSem >=3,kurse(Kursid,_,_,'E2'),modul_kurse(Modul_ID,Kursid,_,_),modul(Modul_ID,_),fachkombi_modul(_,Modul_ID,'pflicht'),X= N+0.5,ersteEbene(Kursid,X,Matr,AktuSem,Ebene,Fach,VLName),!;
X is N,ersteEbene(Kursid,X,Matr,AktuSem,Ebene,Fach,VLName).

%Ab dritten Semester werden die Kurse der Ebene 1 h�her bewertet.
ersteEbene(Kursid,N,Matr,AktuSem,Ebene,Fach,VLName):-AktuSem >=3,kurse(Kursid,_,_,'E1'),X= N +3,belegterKurs(Kursid,X,Matr,Ebene,Fach,VLName),!;
X is N,belegterKurs(Kursid,X,Matr,Ebene,Fach,VLName).

% Kein Kriterium, sondern einer �berpr�fung ob der Kurs bereits
% belegt wurde.Nicht Weitergabe der Kursid, welche bereits erfolgreich
% belegt wurde.
belegterKurs(Kurs,N,Matr,Ebene,Fach,VLName):-student_kurse(Matr,Kurs,'true',_,_,_),methodfort(Kurs,0),!;
leistungfort(Kurs,N,Matr,Ebene,Fach,VLName).

%%  Leistungspunkte des aktuellen Kurses geteilt durch die gesamten LPs
%%  der aktuellen Ebene mal die Anzahl aller Kurse der aktuellen Ebene.
leistungfort(Kursid,N,Matr,Ebene,Fach,VLName):-findall((LP),(kurse(KID,_,_,Ebene),modul_kurse(ID,KID,_,LP),fachkombi_modul(Fach,ID,_)),Liste),summe(Liste,A),anzahl(Liste,Anzahl),kurse(Kursid,_,_,Ebene),modul_kurse(_,Kursid,_,LP),X is N+((LP/A)*Anzahl),drittVersuch(Kursid,X,Matr,Fach,VLName);!.


% Abfrage ob der aktuelle Kurs ein Drittversuch ist und h�here Bewertung bei Erf�llung
% dessen.
drittVersuch(Kursid,N,Matr,Fach,VLName):-student(Matr,_,_,_),student_kurse(Matr,Kursid,'false',_,2,_),kurse(Kursid,_,_,_),nl,X is N+3,abhaengigfort(Kursid,X,Matr,Fach,VLName),!;
X is N,abhaengigfort(Kursid,X,Matr,Fach,VLName).

% Falls ein zugrundeliegender Kurs bereits erfolgreich belegt wurde,
% wird der abh�ngige Kurs h�her bewertet--> alle Kombinationen werden
% hierbei durchlaufen und die Summe aller St�rken zur Gewichtung hinzu
% addiert.
abhaengigfort(Kursid,N,Matr,Fach,VLName):-findall(Staerke,(abhangigkeitkurse(ID,Kursid,Staerke),student_kurse(Matr,ID,'true',_,_,_)),Liste),summe(Liste,Staerkegesamt),X is N+Staerkegesamt,vorwissen(Kursid,X,Matr,Fach,VLName),nl,!;
X is N,vorwissen(Kursid,X,Matr,Fach,VLName).

% Das Vorwissen f�r das jeweilige Fach wird gewichtet --> die LPs bereits
% bestandene Kurse aus diesem Fach aufsummiert und dann geteilt durch
% die GesamtLPs der Kurse in diesem Fach --> Das Ergebnis wird zur
% Gewichtung hinzuaddiert.
vorwissen(Kurs,N,Matr,Fach,VLName):-findall(LP,(student_kurse(Matr,ID,'true',_,_,_),modul_kurse(_,ID,_,LP),student_fachkombi(Matr,Fach),kurse(Kurs,_,_,_),modul_kurse(Modulid, Kurs,_, _),fachkombi_modul(Fach,Modulid,_)),Liste),summe(Liste,B),fachkombination(Fach,Kombi1,_,_,_),Kombi1 \='Null',Erg= B/90, X= N+Erg,nl,wahlmodul(Kurs,X,Matr,VLName),!;
findall(LP,(student_kurse(Matr,ID,'true',_,_,_),modul_kurse(_,ID,_,LP),student_fachkombi(Matr,Fach),kurse(Kurs,_,_,_),modul_kurse(Modulid, Kurs,_, _),fachkombi_modul(Fach,Modulid,_)),Liste),summe(Liste,B),fachkombination(Fach,_,Kombi2,_,_),Kombi2 \='Null',Erg= B/60, X= N+Erg,nl,wahlmodul(Kurs,X,Matr,VLName),!;
findall(LP,(student_kurse(Matr,ID,'true',_,_,_),modul_kurse(_,ID,_,LP),student_fachkombi(Matr,Fach),kurse(Kurs,_,_,_),modul_kurse(Modulid, Kurs,_, _),fachkombi_modul(Fach,Modulid,_)),Liste),summe(Liste,B),fachkombination(Fach,_,_,Kombi3,_),Kombi3 \='Null',Erg= B/30, X= N+Erg,wahlmodul(Kurs,X,Matr,VLName),nl,!;
findall(LP,(student_kurse(Matr,ID,'true',_,_,_),modul_kurse(_,ID,_,LP),student_fachkombi(Matr,Fach),kurse(Kurs,_,_,_),modul_kurse(Modulid, Kurs,_, _),fachkombi_modul(Fach,Modulid,_)),Liste),summe(Liste,B),fachkombination(Fach,_,_,_,Kombi4),Kombi4 \='Null',Erg= B/30, X= N+Erg,wahlmodul(Kurs,X,Matr,VLName),nl,!;
X is N,wahlmodul(Kurs,X,Matr,VLName).

% �berpr�fen ob das Wahlmodul bereits belegt ist. Abgleich der
% Modulpositionen. Kurse welche das Modul
% vervollst�ndigen werden h�her bewertet.
% Bei keinem bereits belegten Wahlmodul nur Weitergabe diesen Kurses
% ohne H�herpriorisierung.
wahlmodul(Kurs,N,Matr,VLName):-student_kurse(Matr,ID,'true',_,_,_),kurse(ID,_,_,_),modul_kurse(ModulID,ID,Position1,_),modul(ModulID,_),fachkombi_modul(_,ModulID,'wahl'),kurse(Kurs,_,_,_),modul_kurse(ModulID,Kurs,Position2,_),modul(ModulID,_),fachkombi_modul(_,ModulID,'wahl'),Position1 \= Position2,nl,X is N+0.05,abhGrundVertief(Kurs,X,Matr,VLName),!;
student_kurse(Matr,ID,'true',_,_,_),kurse(ID,_,_,_),modul_kurse(ModulID,ID,Position1,_),modul(ModulID,_),fachkombi_modul(_,ModulID,'wahl'),kurse(Kurs,_,_,_),modul_kurse(Modul_ID,Kurs,Position2,_),modul(Modul_ID,_),fachkombi_modul(_,Modul_ID,'wahl'),Position1 \= Position2,nl,X is N,abhGrundVertief(Kurs,X,Matr,VLName),!;
student_kurse(Matr,ID,'true',_,_,_),kurse(ID,_,_,_),modul_kurse(ModulID,ID,Position1,_),modul(ModulID,_),fachkombi_modul(_,ModulID,'wahl'),kurse(Kurs,_,_,_),modul_kurse(ModulID,Kurs,Position2,_),modul(ModulID,_),fachkombi_modul(_,ModulID,'wahl'),Position1 == Position2,methodfort(Kurs,0),!;
kurse(Kurs,_,_,_),modul_kurse(Modul_ID,Kurs,_,_),fachkombi_modul(_,Modul_ID,'pflicht'),abhGrundVertief(Kurs,N,Matr,VLName).


%Bei Kursen welche bereits bestanden sind, wird �berpr�ft, ob dieser
%% Kurs ein Grundkurs ist und ob der aktuelle Kurs ein
%% Vertiefungsseminar aus demselben Mdoul ist. Trifft dies zu, dann wird die Priorit�t des Vertieffungseminars
%% um eins erh�ht.
%% Ist der aktuelle Kurs ein Grundkurs, dann wird er nach der jeweiligen Ebene bewertet.
abhGrundVertief(Kurs,N,Matr,VLName):-student_kurse(Matr,ID,'true',_,_,_),kurse(ID,_,'Grundkurs',_),modul_kurse(Modulid,ID,_,_),kurse(Kurs,_,'Vertiefungsseminar',_),modul_kurse(Modul,Kurs,_,_),Modulid = Modul, X is N+1,modulbeleg(Kurs,X,Matr,VLName),!;
kurse(Kurs,_,'Grundkurs','E1'),X is N +3,modulbeleg(Kurs,X,Matr,VLName),!;
kurse(Kurs,_,'Grundkurs','E2'),X is N +2,modulbeleg(Kurs,X,Matr,VLName),!;
kurse(Kurs,_,'Grundkurs','E3'),X is N +0.5,modulbeleg(Kurs,X,Matr,VLName),!;
X is N,modulbeleg(Kurs,X,Matr,VLName).


%% Stellt kein Kriterium im eigentlichen Sinn dar.
% �berpr�fen ob die Modulposition des aktuellen Kurses bereits belegt
% ist, falls nicht, dann wird der Kurs weitergegeben. Falls die Position
% bereits belegt ist, dann wird der Kurs verworfen.
modulbeleg(Kurs,N,Matr,VLName):-student_kurse(Matr,ID,'true',_,_,_),kurse(ID,_,_,_),modul_kurse(ModulID,ID,Position1,_),modul(ModulID,_),fachkombi_modul(_,ModulID,'pflicht'),kurse(Kurs,_,_,_),modul_kurse(Modul_ID,Kurs,Position2,_),modul(Modul_ID,_),fachkombi_modul(_,Modul_ID,'pflicht'),Position1 \= Position2,nl,methodfort(Kurs,N,VLName),!;
student_kurse(Matr,ID,'true',_,_,_),kurse(ID,_,_,_),modul_kurse(ModulID,ID,Position1,_),modul(ModulID,_),fachkombi_modul(_,ModulID,'pflicht'),kurse(Kurs,_,_,_),modul_kurse(Modul_ID,Kurs,Position2,_),modul(Modul_ID,_),fachkombi_modul(_,Modul_ID,'pflicht'),Position1 == Position2,methodfort(Kurs,0),!;
methodfort(Kurs,N,VLName).

%%%%%%%%% Ende der Kriterien fortgeschrittener Student %%%%%


%Schreiben der Kursdaten in die Datenbank ----die Daten werden dynamisch in die Datei Modul.pl geschrieben
methodfort(Kursid,N,VLName):-N\=0,nl,format(atom(Y),'~3f',N),kurse(Kursid,Kursname,_,_),modul_kurse(_,Kursid,Position,LP),asserta(ausgabe(Y-''-Kursname-''-VLName-''-LP-'LP'-''-Position)).
%% Regel zum "Rauswurf" des aktuellen Kurses-> der Kurs wird nicht in
%% die Datenbank geschrieben.
methodfort(Kursid,0).





%%%%%%%	Wichtige Abschlussregel!!!!
%%%%%%%	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%	Aufruf dieser Methode gibt, die in der Datenbank, gespeicherten
%%%%%%%	zu absolvierenden Kurse aus und Ausgabe der m�glichen
%	Wahlbereichskurse.
abschluss:-findall(X,(ausgabe(X)),Liste),keysort(Liste,L),reverse(L,L1),displayList(L1),retractall(ausgabe(_)),ausgabeWBkurse,!;write('').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%






%Berechnung der bisher erreichten gesamten LP.
gesamtLP(Matr):-findall(LP,(student_kurse(Matr,ID,'true',_,_,_),modul_kurse(_,ID,_, LP)),LPListe),summe(LPListe,GesamtLP),anmeldBAarbeit(GesamtLP);nl,fail.

% Ausgabe aller Kurse des Wahlbereichs, welche im aktuellen Semester
% angeboten werden.
ausgabeWBkurse:-findall((WBname),(kurse_vorlesungsverzeichnis(VL, Kursid,_,_),sub_string(Kursid,3,3,0,KID),string_to_atom(KID,KuID),KuID=='000',vorlesungaktuell(VL,_,WBname)),Liste),write('Der Wahlbereich hat den Umfang von 20 LP. M�gliche Kurse f�r den Wahlbereich (alphabetisch sortiert):'),nl,nl,displayList(Liste).

% Falls die bisher erreichte Gesamtpunktzahl 150 LP erreicht hat, dann
% erfolgt eine Info- Ausgabe.
anmeldBAarbeit(150):-write('Sie k�nnen sich nun f�r Ihre Bachelorarbeit anmelden!'),!.
anmeldBAarbeit(X).

%%	Info f�r die Grundlagen- und Orientierungspr�fung.
fachinfo(001):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semesters jeweils ein Kurs aus den Modulen INF-M01,INF-M02,INF-M04, MED-M01 und MED-M02 erfolgreich belegt sein muss.').
fachinfo(002):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semesters jeweils ein Kurs aus den Module INF-M01,INF-M02 und INF-M04 und die Module MEI-M01 und MEI-M03 erfolgreich belegt sein m�ssen.').
fachinfo(003):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semesters jeweils ein Kurs aus den Module INF-M01,INF-M02,MED-M01 und MED-M02 erfolgreich belegt sein muss.').
fachinfo(004):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semesters jeweils ein Kurs aus den Modulen MED-M01 und MED-M02 und die Module MEI-M01 und MEI-M03 erfolgreich belegt sein m�ssen.').
fachinfo(005):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semesters die Module MEI-M01 und MEI-M03 und jweils ein Kurs aus INF-M01 und INF-M02 erfolgreich belegt sein m�ssem.').
fachinfo(006):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semesters die Module MEI-M01 und MEI-M03 und jeweils ein Kurs aus den Modulen MED-M01 und MED-M02 erfolgreich belegt sein m�ssen.').
fachinfo(007):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semesters jeweils ein Kurs aus den Modulen INF-M01,Inf-M02,INF-M04,MED-M01 und MED-M02 und das gesamte Modul MEI-M01 erfolgreich belegt sein m�ssen.').
fachinfo(008):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semester jeweils ein Kurs aus den Modulen INF-M01,MED-M01 und MED-M02 und das gesamte Modul MEI-M01 erfolgreich belegt sein m�ssem.').
fachinfo(009):-write('Bitte beachte, dass f�r die Grundlagen- und Orientierungspr�fung bis zum Ende des 2.ten Semester die Module MEI-M01 und MEI-M03 und ein Kurs jeweils aus den Moduleb INF-M01,MED-M01 und MED-M02 erfolgreich belegt sein m�ssem.').


%%	Information f�r die Ausnahmeregelegungen
ausnahmen(001):-write('Achtung: Du musst f�r das Modul MED-M03 ein fachfremdes Ersatzmodulbelegen. F�r weitere Informationen, wende Dich bitte an den Modulkoordinator.').
ausnahmen(002):-write('Achtung: In der Kombination mit Medieninformatik als zweites Hauptfach muss INF-M 03 durch einen zus�tzlichen Anwendungsschwerpunkt aus MEI-M 10 mit Seminararbeit oder eine analoge fachliche Vertiefung aus dem Bereich Informationswissenschaft ersetzt werden.').
ausnahmen(003):-write('Achtung: Du musst f�r das Modul MED-M 03 ein fachfremdes Ersatzmodulbelegen. F�r weitere Informationen, wende Dich bitte an den Modulkoordinator.').
ausnahmen(005):-write('Achtung: Du darfst die Module INF-M03 und MEI-M06 nicht gleichzeitig belegen.').
ausnahmen(007):-nl,write('Achtung: Du darfst f�r die Modulpositionen MEI-M07.2 und INF-M05.1 nicht mit
demselben Kurs belegen. W�hle einen Alternativkurs aus Modul INF-M05.').
ausnahmen(008):-write('Achtung: Du musst f�r das Modul MED-M03 ein fachfremdes Ersatzmodulbelegen. F�r weitere Informationen, wende Dich bitte an den Modulkoordinator.').
ausnahmen(X).




%Hilfsregeln

% Folgende Regel 'displaylist'
% stammt aus: http://www.learnprolognow.org/lpnpage.php?pagetype=html&pageid=lpn-htmlse52
%Gibt die Elemente einer Liste nacheinander aus (ohne die eckigen Klammern aus)
displayList([]):-nl.
displayList([X|L]):-write(X),tab(1),nl,displayList(L).


%Berechnet die L�nge einer Liste.
anzahl([],0).
anzahl([H|R],X):-anzahl(R,Y),X is Y + 1.


%Summiert die Elemente einer Liste auf.
summe([],0).
summe([H|R],X):-summe(R,Y),X is H + Y.


%% Regel 'laenge' abge�ndert nach:
%% http://eisenholz.bplaced.net/prolog-listen
%% Berechnet die Gesamtl�nge einer Liste
laenge([ ],0).
laenge([_| R],X):-laenge(R,Y),X is Y + 1.
