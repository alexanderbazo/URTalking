%fachkombination_kurse(Fachkombination,ModulID,KursID).

% fachkombination = 001 INF MED
fachkombination_kurse(001,'infm01','inf001').
fachkombination_kurse(001,'infm01','inf002').
fachkombination_kurse(001,'infm02','inf003').
fachkombination_kurse(001,'infm02','inf004').
fachkombination_kurse(001,'infm02','inf005').
fachkombination_kurse(001,'infm04','inf010').
fachkombination_kurse(001,'infm04','inf011').
fachkombination_kurse(001,'infm04','inf012').
fachkombination_kurse(001,'medm01','med001').
fachkombination_kurse(001,'medm01','med002').
fachkombination_kurse(001,'medm01','med003').
fachkombination_kurse(001,'medm02','med004').
fachkombination_kurse(001,'medm02','med005').
fachkombination_kurse(001,'medm02','med006').


% fachkombination = 002 INF MEI

fachkombination_kurse(002,'infm01','inf001').
fachkombination_kurse(002,'infm01','inf002').
fachkombination_kurse(002,'infm02','inf003').
fachkombination_kurse(002,'infm02','inf004').
fachkombination_kurse(002,'infm02','inf005').
fachkombination_kurse(002,'infm04','inf010').
fachkombination_kurse(002,'infm04','inf011').
fachkombination_kurse(002,'infm04','inf012').
fachkombination_kurse(002,'meim01','mei001').
fachkombination_kurse(002,'meim01','mei002').
fachkombination_kurse(002,'meim03','mei005').
fachkombination_kurse(002,'meim03','mei006').
fachkombination_kurse(002,'meim03','mei007').


% fachkombination = 003 MED INF


fachkombination_kurse(003,'infm01','inf001').
fachkombination_kurse(003,'infm01','inf002').
fachkombination_kurse(003,'infm02','inf003').
fachkombination_kurse(003,'infm02','inf004').
fachkombination_kurse(003,'infm02','inf005').
fachkombination_kurse(003,'medm01','med001').
fachkombination_kurse(003,'medm01','med002').
fachkombination_kurse(003,'medm01','med003').
fachkombination_kurse(003,'medm02','med004').
fachkombination_kurse(003,'medm02','med005').
fachkombination_kurse(003,'medm02','med006').


% fachkombination = 004 MED MEI


fachkombination_kurse(004,'meim01','mei001').
fachkombination_kurse(004,'meim01','mei002').
fachkombination_kurse(004,'meim03','mei005').
fachkombination_kurse(004,'meim03','mei006').
fachkombination_kurse(004,'meim03','mei007').
fachkombination_kurse(004,'medm01','med001').
fachkombination_kurse(004,'medm01','med002').
fachkombination_kurse(004,'medm01','med003').
fachkombination_kurse(004,'medm02','med004').
fachkombination_kurse(004,'medm02','med005').
fachkombination_kurse(004,'medm02','med006').

% fachkombination = 005 MEI INF

fachkombination_kurse(005,'infm01','inf001').
fachkombination_kurse(005,'infm01','inf002').
fachkombination_kurse(005,'infm02','inf003').
fachkombination_kurse(005,'infm02','inf004').
fachkombination_kurse(005,'infm02','inf005').
fachkombination_kurse(005,'meim01','mei001').
fachkombination_kurse(005,'meim01','mei002').
fachkombination_kurse(005,'meim03','mei005').
fachkombination_kurse(005,'meim03','mei006').
fachkombination_kurse(005,'meim03','mei007').


% fachkombination = 006 MEI MED

fachkombination_kurse(006,'meim01','mei001').
fachkombination_kurse(006,'meim01','mei002').
fachkombination_kurse(006,'meim03','mei005').
fachkombination_kurse(006,'meim03','mei006').
fachkombination_kurse(006,'meim03','mei007').
fachkombination_kurse(006,'medm01','med001').
fachkombination_kurse(006,'medm01','med002').
fachkombination_kurse(006,'medm01','med003').
fachkombination_kurse(006,'medm02','med004').
fachkombination_kurse(006,'medm02','med005').
fachkombination_kurse(006,'medm02','med006').

% fachkombination = 007 INF MED MEI

fachkombination_kurse(007,'infm01','inf001').
fachkombination_kurse(007,'infm01','inf002').
fachkombination_kurse(007,'infm02','inf003').
fachkombination_kurse(007,'infm02','inf004').
fachkombination_kurse(007,'infm02','inf005').
fachkombination_kurse(007,'infm04','inf010').
fachkombination_kurse(007,'infm04','inf011').
fachkombination_kurse(007,'infm04','inf012').
fachkombination_kurse(007,'meim01','mei001').
fachkombination_kurse(007,'meim01','mei002').
fachkombination_kurse(007,'medm01','med001').
fachkombination_kurse(007,'medm01','med002').
fachkombination_kurse(007,'medm01','med003').
fachkombination_kurse(007,'medm02','med004').
fachkombination_kurse(007,'medm02','med005').
fachkombination_kurse(007,'medm02','med006').

% fachkombination = 008 MED INF MEI

fachkombination_kurse(008,'infm01','inf001').
fachkombination_kurse(008,'infm01','inf002').
fachkombination_kurse(008,'medm01','med001').
fachkombination_kurse(008,'medm01','med002').
fachkombination_kurse(008,'medm01','med003').
fachkombination_kurse(008,'medm02','med004').
fachkombination_kurse(008,'medm02','med005').
fachkombination_kurse(008,'medm02','med006').
fachkombination_kurse(008,'meim01','mei001').
fachkombination_kurse(008,'meim01','mei002').


% fachkombination = 009 MEI INF MED

fachkombination_kurse(009,'infm01','inf001').
fachkombination_kurse(009,'infm01','inf002').
fachkombination_kurse(009,'meim01','mei001').
fachkombination_kurse(009,'meim01','mei002').
fachkombination_kurse(009,'meim03','mei005').
fachkombination_kurse(009,'meim03','mei006').
fachkombination_kurse(009,'meim03','mei007').
fachkombination_kurse(009,'medm01','med001').
fachkombination_kurse(009,'medm01','med002').
fachkombination_kurse(009,'medm01','med003').
fachkombination_kurse(009,'medm02','med004').
fachkombination_kurse(009,'medm02','med005').
fachkombination_kurse(009,'medm02','med006').

