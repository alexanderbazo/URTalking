%% vorlesungaktuell(Vorlesungsid,Kursnummer,Kursname,Kursleiter)
%%Informationswissenschaften aktuelles Vorlesungsverzeichnis WS13/14

vorlesungaktuell('infv001', 36650, 'Einfuehrung in die Informationswissenschaft mit Tutorium�, �Dr. Ludwig Hitzenberger').
vorlesungaktuell('infv002', 36653, 'Mathematische Grundlagen mit Tutorium�, 'Prof. Dr. Bernd Ludwig').
vorlesungaktuell('infv003', 35018, 'Einfuehrung in die Informationslinguistik�, 'PD. Dr. J�rgen Reischer').
vorlesungaktuell('infv004', 36656, 'Methoden informationswissenschaftlicher Datenanalyse. Ein Praxiskurs�, 'Markus Kattenbeck M.A.').
vorlesungaktuell('infv005', 35020, 'Textlinguistik�, � 'PD. Dr. J�rgen Reischer').
vorlesungaktuell('infv006', 60131, 'Einfuehrung in die statische Datenanalyse mit SPSS�, 'Dipl.-Psych. Frank Dodoo-Schittko').
vorlesungaktuell('infv007', 60132, 'Statische Datenanalyse mit SPSS f�r Fortgeschrittene (Blockkurs)�, 'Dipl.-Psych. Frank Dodoo-Schittko' ).
vorlesungaktuell('infv008', 36658, 'Einfuehrung in die objektorientierte Programmierung mit C# mit Tutorium�, 'PD. Dr. J�rgen Reischer').
vorlesungaktuell('infv009', 36603, 'Einfuehrung in die Programmierung und Programmiersprachen (Einf�hrung in Java/Objektorientierte Programmierung mit �bung)�, 'Prof. Dr. Christian Wolff, Manuel Burghardt M.A., Dipl.-Medieninf Raphael Wimmer, Martin Brockelmann M.A.�).
vorlesungaktuell('infv010', 36659, 'Algorithmen, Datenstrukturen und Programmierung mit �bung�, 'PD. Dr. J�rgen Reischer').
vorlesungaktuell('infv011', 60311, 'Einfuehrung in die Programmiersprache C � 'Dipl.-Math. Frank Braun').
vorlesungaktuell('infv012', 60331, 'Programmierung von Parallelrechner-MPI und OpenMP�, 'Null').
vorlesungaktuell('infv013', 60333, 'Nichtnumerische Algorithmen�, 'Dipl.-Math. Frank Braun').
vorlesungaktuell('infv014', 60531, 'Agile Softwareentwicklung�, 'Null').
vorlesungaktuell('infv015', 36662, 'Grundlagen des Information Retrieval�, 'Florian Meier M.A.').
vorlesungaktuell('infv016', 36663, 'Markup-Sprachen mit �bung�, 'Manuel Burghardt M.A.').
vorlesungaktuell('infv017', 36612, 'Grundlagen Human Computer Interaction�, 'Victoria B�hm M.A.').
vorlesungaktuell('infv018', 36667, 'Vertiefungsseminar Softwareergonomie�, 'Dipl.-Inf. Stefan Bienk').
vorlesungaktuell('infv019', 36668, 'Empirische Rezeptionsforschung�, �Dr. Ludwig Hitzenberger,Josef Mittlmeier').
vorlesungaktuell('infv020', 36622, '3D-Vertiefungskurs mit �bung�, �Martin Brockelmann M.A.�).
vorlesungaktuell('infv021', 36615, 'Projektseminar Mediengestaltung � Gestaltung innovativer UI f�r Alltagsger�te�, 'Victoria B�hm M.A.').
vorlesungaktuell('infv022', 60211, 'Grundlagen des Webdesign. Design for Interaction�, 'Florian Greiner').
vorlesungaktuell('infv023', 36671, 'Situative Relevanz im Information Retrieval�, 'Hanna Knaeusel M.A.').
vorlesungaktuell('infv024', 60213, 'Typografie. Lesbarkeit und Design im digitalen Kontext�, 'Florian Greiner, Christoph Pfeiffer').
vorlesungaktuell('infv025', 60214, 'Content Strategy. Inhaltserschlie�ung und �optimierung fuers Web�, 'Florian Greiner').
vorlesungaktuell('infv026', 60218, 'Content-Management-Systeme. Instalation, Anpassung und Templating�, 'Christoph Pfeiffer').
vorlesungaktuell('infv027', 60511, 'Social Software. Kommunikation und Zusammenarbeit im akademischen Alltag�, 'Christoph Pfeiffer').
vorlesungaktuell('infv028', 60521, 'Digitale Welten: Von Webtechnologien, Memen und sozialen Auswirkungen�, 'Florian Greiner').
vorlesungaktuell('infv029', 36673, 'Einfuehrung in das Projektmanagement�, 'Dipl.-Inf. Stefan Bienk').
vorlesungaktuell('infv030', 36674, 'UR Walking', 'Prof. Dr. Bernd Ludwig').
vorlesungaktuell('infv031', 36690, 'Neuere Entwicklungen in der Informationswissenschaft � Vorstellung von Bachelor-, Magister- und Masterarbeiten�, 'Prof. Dr. Rainer Hammwoehner, Prof. Dr. Bernd Ludwig').

% vorlesungaktuell(Vorlesungsid,Kursnummer,Kursname,Kursleiter)
%Medienwissenschaft aktuelles Vorlesungsverzeichnis WS13/14

vorlesungaktuell('medv001', 36900, 'Mediengeschichte�, 'Prof. Dr. Bernhard Dotzler').
vorlesungaktuell('medv002', 36901, 'Medien-Frauen�, 'Dr. Silke Roesler-Keilholz').
vorlesungaktuell('medv003', 36902, 'Anime und japanisches Kino�, 'Dr. Herbert Schwaab').
vorlesungaktuell('medv004', 36903, 'Fernsehgeschichte: Die erste Aera des Fernsehens � Scarcity (1950-1980)�, 'Dr. Herbert Schwaab').
vorlesungaktuell('medv005', 36904, 'Das gesprochene Wort�, 'Dr. Astrid Freudenstein').
vorlesungaktuell('medv006', 36905, 'New Hollywood�, 'Adina Lauenburger').
vorlesungaktuell('medv007', 36906, 'Geschichte des Farbfilms�, 'Adina Lauenburger').
vorlesungaktuell('medv008', 36908, 'Geschichte und Aesthetik des Musikvideos�, 'Michael Flieg M.A.').
vorlesungaktuell('medv009', 36909, 'Naehe und Ferne�, 'Ulrike Riederer M.A.').
vorlesungaktuell('medv010', 36910, 'Die Evolution des Melodrams im Film (Block)�, 'Dr. Thomas Brandlmeier').
vorlesungaktuell('medv011', 36911, 'Kino im Kino. Beispiele aus der Geschichte der Selbstreflexion eines Mediums. Von Tziga Vertov bis Quentin Tarantino�, 'Dr. Medard Kammermeier').
vorlesungaktuell('medv012', 36912, 'Hoerspielgeschichte. Von der Nachkriegszeit bis zur Gegenwart�, 'Dr. Dieter Lohr�).
vorlesungaktuell('medv013', 36913, 'Medienaesthetik�, 'Prof. Dr. Henning Schmidgen').
vorlesungaktuell('medv014', 36914, 'Tiere in Film und Fernsehen�, 'Dr. Herbert Schwaab').
vorlesungaktuell('medv015', 36915, 'Grundlagentexte der Medientheorie�, 'Adina Lauenburger').
vorlesungaktuell('medv016', 36916, 'Medientheorien der Sexualitaet�, 'Adina Lauenburger').
vorlesungaktuell('medv017', 36917, 'Melancholie�, 'Adina Lauenburger').
vorlesungaktuell('medv018', 36918, 'Realismus im Film�, 'Adina Lauenburger').
vorlesungaktuell('medv019', 36919, 'Giuseppe Tornatore: Von Nuovo Cinema Paradiso bis Nuovo Cinema Italiano (mit Filmreihe)�, ' Tatyana Yakovleva').
vorlesungaktuell('medv020', 36920, 'Politikvermittlung und mediale Inszenierung').
vorlesungaktuell('medv021', 36921, 'Medienanalyse: Filmkritik�, 'Dr. Astrid Freudenstein').
vorlesungaktuell('medv022', 36922, 'Hoerspiel-Analyse�, 'Dr. Astrid Freudenstein').
vorlesungaktuell('medv023', 36923, 'Bildsprache der Fotografie (Block)�, 'Katharina Kaiser').
vorlesungaktuell('medv024', 60521, 'Digitale Welten: Von Webtechnologien, Memen und sozialen Auswirkungen�, 'Florian Greiner').
vorlesungaktuell('medv025', 36650, 'Einfuehrung in die Informationswissenschaft (Medienwiss., Vergl. Kulturwiss.) mit Tutorium�,�Dr. Ludwig Hitzenberger').
vorlesungaktuell('medv026', 36924, 'Radiojournalismus�, 'Dr. Astrid Freudenstein').
vorlesungaktuell('medv027', 36925, 'Printjournalismus (Block)�, 'Dr. Rudolph Neumaier').
vorlesungaktuell('medv028', 36926, 'Einfuehrung in die TV-Produktion�, 'Constantin Weber').
vorlesungaktuell('medv029', 36927, 'Projektseminar: RVW-Vortragsreihe �Risiko�, 'Dr. Astrid Freudenstein').
vorlesungaktuell('medv030', 36928, 'Internationale Kurzfilmwoche Regensburg�, 'Michael Fleig M.A.').
vorlesungaktuell('medv031', 36940, 'Journalistische Arbeit mit der Kamera und Kamerafuehrung�, 'Peter Schroeder').
vorlesungaktuell('medv032', 60414, 'Fotografie und Bildbearbeitung�, 'Florian Greiner').
vorlesungaktuell('medv033', 32049, 'Medienwelten von Kinder und Jugendlichen�, 'Dr. Michaela Ingrisch').
vorlesungaktuell('medv034', 32309, 'Vertiefung erziehungswissenschaftlicher Theorien: Medien und Bildung�, 'Dr. Klaus Stiller').
vorlesungaktuell('medv035', 36700, 'Einfuehrung in die Vergleichende Kulturwissenschaft�, 'Prof. Dr. Daniel Drascek').
vorlesungaktuell('medv036', 36717, 'Populaere Musik und Lebensstil. Grundlagen der kulturwissenschaftlichen Populaermusikforschung�, 'Dr. Manuel Tr�mmer').
vorlesungaktuell('medv037', 36719, 'Der Eintritt in den Ruhestand: Erfahrungen zwischen Sinnkrise und Aufbruch�, 'Dr. Esther Gajek').
vorlesungaktuell('medv038', 36929, 'Grundkonzepte digitaler Medien�, 'Dr. Herbert Schwaab').
vorlesungaktuell('medv039', 36931, 'Das Zeitalter der intelligenten Maschinen�, 'Prof. Dr. Henning Schmidgen').
vorlesungaktuell('medv040', 36932, 'Theorie und Geschichte mobiler Medien�, 'Dr. Herbert Schwaab').
vorlesungaktuell('medv041', 36933, 'Virtuelle Topographien�, 'Dr. Silke Roesler-Keilholz').
vorlesungaktuell('medv042', 36907, 'Archive und ihre Medien�, 'Adina Lauenburger').
vorlesungaktuell('medv043', 36934, 'Der Middle East-Film als Politische Form�, 'Prof. Dr. Bernhard Dotzler').
vorlesungaktuell('medv044', 36935, 'Die Werbung und das Aufgebot der Medien�, 'Prof. Dr. Bernhard Dotzler').


% vorlesungaktuell(Vorlesungsid,Kursnummer,Kursname,Kursleiter)

% Medieninformatik aktuelles Vorlesungsverzeichnis WS13/14

vorlesungaktuell('meiv001', 36600, 'Einfuehrung in die Informatik und Medieninformatik mit Uebung�,'Dipl.-Medieninf Raphael Wimmer, Tim Schneidermeier M.A., Victoria Boehm M.A.').
vorlesungaktuell('meiv002', 51420, 'Vorkurs: Grundwissen Mathematik fuer Biochemiker, Chemiker, Medieninformatiker�, 'Dr. Ankam Popa, Dr. Daniela Schiefeneder, Dr. Antonella Perucca').
vorlesungaktuell('meiv003', 51421, 'Grundwissenpruefung Mathematik fuer Biochemiker, Chemiker, Medieninformatiker�, 'Dr. Daniela Schiefeneder').
vorlesungaktuell('meiv004', 51480, 'Mathematik fuer Medieninformatik I�, 'Dr. Daniela Schiefeneder').
vorlesungaktuell('meiv005', 51481, �Uebung zu Mathematik fuer Medieninformatik I�, 'Dr. Daniela Schiefeneder').
vorlesungaktuell('meiv006', 36603, 'Einfuehrung in die Programmierung und Programmiersprachen (Einfuehrung in Java/Objektorientierte Programmierung) mit Uebung�, 'Prof. Dr. Christian Wolff, Manuel Burghardt M.A., Dipl.-Medieninf Raphael Wimmer, Martin Brockelmann M.A.�).
vorlesungaktuell('meiv007', 36659, 'Algorithmen und Datenstrukturen mit Ubung�, 'PD. Dr. J�rgen Reischer').
vorlesungaktuell('meiv008', 36658, 'Einfuehrung in die objektorientiere Programmierung mit C# mit Tutorium�, 'PD. Dr. J�rgen Reischer').
vorlesungaktuell('meiv009', 36607, 'Multimedia Technology (Medientechnologie) mit Uebung�, 'Prof. Dr. Florian Echtler, Martin Brockelmann M.A').
vorlesungaktuell('meiv010', 36609, 'Multimedia Engineering mit Praktikum�, 'Felix Raab M.Sc.').
vorlesungaktuell('meiv011', 36663, 'Markup-Sprachen mit Uebung�, 'Manuel Burghardt M.A.').
vorlesungaktuell('meiv012', 36612, 'Grundlagen Human Computer Interaction�, 'Victoria B�hm M.A.').
vorlesungaktuell('meiv013', 36613, 'Usability Engineering�, 'Tim Schneidermeier M.A.').
vorlesungaktuell('meiv014', 36614, 'User Experience Methoden (Blockveranstaltung)�, 'Tim Schneidermeier M.A.').
vorlesungaktuell('meiv015', 36615, 'Projektseminar Mediengestaltung-Gestaltung innovativer UI fuer Alltagsgeraete�, 'Patricia Boehm M.A.').
vorlesungaktuell('meiv016', 60211, 'Grundlagen des Webdesign. Design for Interaction�, 'Florian Greiner').
vorlesungaktuell('meiv017', 60213, 'Typografie. Lesbarkeit und Design im digitalen Kontext�, 'Florian Greiner, Christoph Pfeiffer').
vorlesungaktuell('meiv018', 60217, 'HTML und CSS. Markup is for Meaning�, 'Christoph Pfeiffer').
vorlesungaktuell('meiv019', 36620, 'Einfuehrungsvorlesung Anwendungsschwerpunkt mit Uebung�, 'Prof. Dr. Florian Echtler, Dipl.-Medieninf. Raphael Wimmer').
vorlesungaktuell('meiv020', 60214, 'Content Strategy.Inhaltserstellung und- optimierung fuers Web�, 'Florian Greiner').
vorlesungaktuell('meiv021', 36622, '3D-Vertiefungskurs mit Uebung�, �Martin Brockelmann M.A.�).
vorlesungaktuell('meiv022', 36624, 'Gender and Community Informatics�, 'Prof. Dr. Christian Wolff').
vorlesungaktuell('meiv023', 36625, 'Sketching with Hardware�, 'Prof. Dr. Florian Echtler, Dipl.-Medieninf. Raphael Wimmer').
vorlesungaktuell('meiv024', 36629, 'Oberseminar�, 'Prof. Dr. Christian Wolff').
vorlesungaktuell('meiv025', 36662, 'Grundlagen Information Retrieval�, 'Florian Meier M.A.').
vorlesungaktuell('meiv026', 36673, 'Einfuehrung in das Projektmanagement, �'Dipl.-Inf. Stefan Bienk').
vorlesungaktuell('meiv027', 36674, 'UR Walking�, 'Prof. Dr. Bernd Ludwig').
