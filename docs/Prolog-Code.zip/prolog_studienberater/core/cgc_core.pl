%###########################################%
% Collection of core clauses and predicates %
%###########################################%

not_member(ITEM, LIST):-
	\+ member(ITEM, LIST).