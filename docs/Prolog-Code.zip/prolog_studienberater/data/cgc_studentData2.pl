%###########################################%
%###  Fake input data for some student   ###%
%###########################################%

%studentsMatriculationNumber
matriculationNumber('1497523').

%studentsFirstMajor(MATRICULATIONNUMBER, FACH).
studentsFirstMajor('1497523', 'Informationswissenschaft').

%studentsFirstMinor(MATRICULATIONNUMBER, FACH).
studentsFirstMinor('1497523', 'Medieninformatik').

%studentsSecondMinor(MATRICULATIONNUMBER, FACH).
studentsSecondMinor('1497523', 'Medienwissenschaft').

%studentsThesis(MATRICULATIONNUMBER, TITEL, STATUS).
studentsThesis('1409575', 'Prolog', 'bestanden').

%studentsModuleForFirstMajor(MATRICULATIONNUMBER, MODULE).
								
studentsModuleForFirstMajor('1409575', module('INF-M 01', [modulePosition('1', 1), modulePosition('2', 1)], 1)).
studentsModuleForFirstMajor('1409575', module('INF-M 02', [modulePosition('1', 1), modulePosition('2', 3), modulePosition('3', 2)], 2)).
studentsModuleForFirstMajor('1409575', module('INF-M 03', [modulePosition('1', 2), modulePosition('2', 1), modulePosition('3', 1), modulePosition('4', 1)], 1.3)).
studentsModuleForFirstMajor('1409575', module('INF-M 04', [modulePosition('1', 1), modulePosition('2', 3), modulePosition('3', 2)], 2)).
studentsModuleForFirstMajor('1409575', module('INF-M 05', [modulePosition('1', -1), modulePosition('2', -1)], -1)).
studentsModuleForFirstMajor('1409575', module('INF-M 06', [modulePosition('1', 1), modulePosition('2', 3), modulePosition('3', 2)], 1.7)).
studentsModuleForFirstMajor('1409575', module('INF-M 07', [modulePosition('1', 1), modulePosition('2', -1)], -1)).

studentsModuleForFirstMinor('1409575', module('MED-M 02',[modulePosition('1', 2), modulePosition('2', 1), modulePosition('3', 1), modulePosition('4', 1), modulePosition('5', 1)], 1)).


studentsModuleForSecondMinor('1409575', module('MEI-BA-M 03',[modulePosition('1', 2), modulePosition('2', 1), modulePosition('3', 1), modulePosition('4', 1), modulePosition('5', 1)], 1)).



studentsCoursesForFirstMajor('1409575', []).
studentsCoursesForFirstMinor('1409575', []).
studentsCoursesForSecondMinor('1409575', []).
studentsCoursesForWahlbereich('1409575', []).