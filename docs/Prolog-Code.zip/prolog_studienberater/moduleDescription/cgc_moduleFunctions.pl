%###########################################%
%##   Module Functions for all subjects   ##%
%###########################################%

generateUnfinishedModuleListForFirstMajor([]):-
	\+ current_predicate(studentsModuleForFirstMajor/2),!.

generateUnfinishedModuleListForFirstMajor(LIST):-
	findall(X, studentsModuleForFirstMajor(_, module(X,_,-1)), LIST).
	
generateFinishedModuleListForFirstMajor([]):-
	\+ current_predicate(studentsModuleForFirstMajor/2),!.
	
generateFinishedModuleListForFirstMajor(LIST):-
	findall(X, studentsModuleForFirstMajor(_, module(X,_,_)), ALL_MODULES),
	generateUnfinishedModuleList(UNFINISHED_MODULES),
	subtract(ALL_MODULES, UNFINISHED_MODULES, LIST).
	
generateStartedModuleListForFirstMajor([]):-
	\+ current_predicate(studentsModuleForFirstMajor/2),!.	

generateStartedModuleListForFirstMajor(LIST):-
	findall(X, studentsModuleForFirstMajor(_, module(X,_,_)), LIST).
	
generateUnfinishedModuleListForSecondMajor([]):-
	\+ current_predicate(studentsModuleForSecondMajor/2),!.
	
generateUnfinishedModuleListForSecondMajor(LIST):-
	findall(X, studentsModuleForSecondMajor(_, module(X,_,-1)), LIST).
	
generateFinishedModuleListForSecondMajor([]):-
	\+ current_predicate(studentsModuleForSecondMajor/2),!.
	
generateFinishedModuleListForSecondMajor(LIST):-
	findall(X, studentsModuleForSecondMajor(_, module(X,_,_)), ALL_MODULES),
	generateUnfinishedModuleList(UNFINISHED_MODULES),
	subtract(ALL_MODULES, UNFINISHED_MODULES, LIST).
	
generateStartedModuleListForSecondMajor([]):-
	\+ current_predicate(studentsModuleForSecondMajor/2),!.
	
generateStartedModuleListForSecondMajor(LIST):-
	findall(X, studentsModuleForSecondMajor(_, module(X,_,_)), LIST).
	
generateUnfinishedModuleListForFirstMinor([]):-
	\+ current_predicate(studentsModuleForFirstMinor/2),!.

generateUnfinishedModuleListForFirstMinor(LIST):-
	findall(X, studentsModuleForFirstMinor(_, module(X,_,-1)), LIST).
	
generateFinishedModuleListForFirstMinor([]):-
	\+ current_predicate(studentsModuleForFirstMinor/2),!.
	
generateFinishedModuleListForFirstMinor(LIST):-
	findall(X, studentsModuleForFirstMinor(_, module(X,_,_)), ALL_MODULES),
	generateUnfinishedModuleList(UNFINISHED_MODULES),
	subtract(ALL_MODULES, UNFINISHED_MODULES, LIST).
	
generateStartedModuleListForFirstMinor([]):-
	\+ current_predicate(studentsModuleForFirstMinor/2),!.
	
generateStartedModuleListForFirstMinor(LIST):-
	findall(X, studentsModuleForFirstMinor(_, module(X,_,_)), LIST).
	
generateUnfinishedModuleListForSecondMinor([]):-
	\+ current_predicate(studentsModuleForSecondMinor/2),!.
	
generateUnfinishedModuleListForSecondMinor(LIST):-
	findall(X, studentsModuleForSecondMinor(_, module(X,_,-1)), LIST).

generateFinishedModuleListForSecondMinor([]):-
	\+ current_predicate(studentsModuleForSecondMinor/2),!.
	
generateFinishedModuleListForSecondMinor(LIST):-
	findall(X, studentsModuleForSecondMinor(_, module(X,_,_)), ALL_MODULES),
	generateUnfinishedModuleList(UNFINISHED_MODULES),
	subtract(ALL_MODULES, UNFINISHED_MODULES, LIST).
	
generateStartedModuleListForSecondMinor([]):-
	\+ current_predicate(studentsModuleForSecondMinor/2),!.
	
generateStartedModuleListForSecondMinor(LIST):-
	findall(X, studentsModuleForSecondMinor(_, module(X,_,_)), LIST).

generateSubjectListForPossibleFirstMajor(LIST):-
	findall(S, subject(S), LIST).

generateSubjectListForPossibleSecondMajor(LIST):-
	findall(S, subject(S), LIST_SUBJECTMAJOR),
	findall(S1, subjectOnlyForSecondMajor(S1), LIST_SUBJECTSECONDMAJOR),
	append(LIST_SUBJECTMAJOR, LIST_SUBJECTSECONDMAJOR, LIST).
	
generateSubjectListForPossibleMinor(LIST):-
	findall(S, subject(S), LIST_SUBJECTMAJOR),
	findall(S2, subjectOnlyForMinor(S2), LIST_SUBJECTMINOR),
	append(LIST_SUBJECTMAJOR, LIST_SUBJECTMINOR, LIST).

findAdditionalSubjectForFirstMajor(FIRSTMAJOR, VALIDSUBJECTS):-
	generateSubjectListForPossibleSecondMajor(SUBJECTLIST),
	removeInvalidSubjectForFirstMajor(FIRSTMAJOR, SUBJECTLIST, VALIDSUBJECTS),!.

removeInvalidSubjectForFirstMajor(FIRSTMAJOR, [SUBJECT|[]], [SUBJECT]):-
	bachelor(FIRSTMAJOR, SUBJECT).

removeInvalidSubjectForFirstMajor(_, [_|[]], []).

removeInvalidSubjectForFirstMajor(FIRSTMAJOR, [SUBJECT|SUBJECTLIST], [SUBJECT|VALIDSUBJECTS]):-
	bachelor(FIRSTMAJOR, SUBJECT),
	removeInvalidSubjectForFirstMajor(FIRSTMAJOR, SUBJECTLIST, VALIDSUBJECTS).
	
removeInvalidSubjectForFirstMajor(FIRSTMAJOR, [_|SUBJECTLIST], VALIDSUBJECTS):-
	removeInvalidSubjectForFirstMajor(FIRSTMAJOR, SUBJECTLIST, VALIDSUBJECTS).
	
findAdditionalSubjectForSecondMajor(SECONDMAJOR, VALIDSUBJECTS):-
	generateSubjectListForPossibleFirstMajor(SUBJECTLIST),
	removeInvalidSubjectForSecondMajor(SECONDMAJOR, SUBJECTLIST, VALIDSUBJECTS),!.

removeInvalidSubjectForSecondMajor(SECONDMAJOR, [SUBJECT|[]], [SUBJECT]):-
	bachelor(SUBJECT, SECONDMAJOR).

removeInvalidSubjectForSecondMajor(_, [_|[]], []).

removeInvalidSubjectForSecondMajor(SECONDMAJOR, [SUBJECT|SUBJECTLIST], [SUBJECT|VALIDSUBJECTS]):-
	bachelor(SUBJECT, SECONDMAJOR),
	removeInvalidSubjectForSecondMajor(SECONDMAJOR, SUBJECTLIST, VALIDSUBJECTS).
	
removeInvalidSubjectForSecondMajor(SECONDMAJOR, [_|SUBJECTLIST], VALIDSUBJECTS):-
	removeInvalidSubjectForSecondMajor(SECONDMAJOR, SUBJECTLIST, VALIDSUBJECTS).
	
findAdditionalSubjectForMinor(FIRSTMAJOR, MINOR, VALIDSUBJECTS):-
	generateSubjectListForPossibleMinor(SUBJECTLIST),
	removeInvalidSubjectForMinor(FIRSTMAJOR, MINOR, SUBJECTLIST, VALIDSUBJECTS),!.

removeInvalidSubjectForMinor(FIRSTMAJOR, MINOR, [SUBJECT|[]], [SUBJECT]):-
	bachelor(FIRSTMAJOR,MINOR, SUBJECT).

removeInvalidSubjectForMinor(_,_, [_|[]], []).

removeInvalidSubjectForMinor(FIRSTMAJOR, MINOR, [SUBJECT|SUBJECTLIST], [SUBJECT|VALIDSUBJECTS]):-
	bachelor(FIRSTMAJOR,MINOR, SUBJECT),
	removeInvalidSubjectForMinor(FIRSTMAJOR,MINOR, SUBJECTLIST, VALIDSUBJECTS).
	
removeInvalidSubjectForMinor(FIRSTMAJOR, MINOR, [_|SUBJECTLIST], VALIDSUBJECTS):-
	removeInvalidSubjectForMinor(FIRSTMAJOR, MINOR, SUBJECTLIST, VALIDSUBJECTS).

listEmptyModulPositionForMajor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS):-
		extractEmptyModulPositionsForMajor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS1),
		write(EMPTYMODULPOSITIONS1),nl,
		extractUnfinishedModuleWithModulPositions(STARTEDMODULES, EMPTYMODULPOSITIONS2),
		write(EMPTYMODULPOSITIONS2),nl,
		append(EMPTYMODULPOSITIONS1, EMPTYMODULPOSITIONS2, EMPTYMODULPOSITIONS),!.
		
listEmptyModulPositionForSecondMajor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS):-
		extractEmptyModulPositionsForSecondMajor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS1),
		extractUnfinishedModuleWithModulPositions(STARTEDMODULES, EMPTYMODULPOSITIONS2),
		append(EMPTYMODULPOSITIONS1, EMPTYMODULPOSITIONS2, EMPTYMODULPOSITIONS),!.
		
listEmptyModulPositionForMinor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS):-
		extractEmptyModulPositionsForMinor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS1),
		extractUnfinishedModuleWithModulPositions(STARTEDMODULES, EMPTYMODULPOSITIONS2),
		append(EMPTYMODULPOSITIONS1, EMPTYMODULPOSITIONS2, EMPTYMODULPOSITIONS),!.
		
extractUnfinishedModuleWithModulPositions([STARTEDMODUL|[]], EMPTYMODULPOSITIONS):-
	extractEmptyModulePositionsFromUnfinishedModules(STARTEDMODUL, EMPTYMODULPOSITIONS),!.
		
extractUnfinishedModuleWithModulPositions([STARTEDMODUL|STARTEDMODULS], NEW_EMPTYMODULPOSITIONS):-
	extractUnfinishedModuleWithModulPositions(STARTEDMODULS, EMPTYMODULPOSITIONS),
	extractEmptyModulePositionsFromUnfinishedModules(STARTEDMODUL, NEWMODUL_EMPTYMODULPOSITIONS),
	append(NEWMODUL_EMPTYMODULPOSITIONS, EMPTYMODULPOSITIONS , NEW_EMPTYMODULPOSITIONS).
	
extractEmptyModulePositionsFromUnfinishedModules(module(NAME, [modulePosition(POS, GRADE)|[]], _), [uncompletedModulePosition(NAME, POS)]):-
	GRADE < 1,!.
	
extractEmptyModulePositionsFromUnfinishedModules(module(_, [_|[]], _), []).

extractEmptyModulePositionsFromUnfinishedModules(module(NAME, [modulePosition(POS, GRADE)|MODULPOSITIONS], _), [uncompletedModulePosition(NAME, POS)|EMPTYMODULPOSITIONS]):-
	GRADE < 1,
	extractEmptyModulePositionsFromUnfinishedModules(module(NAME, MODULPOSITIONS, _), EMPTYMODULPOSITIONS),!.
	
extractEmptyModulePositionsFromUnfinishedModules(module(NAME, [modulePosition(_,_)|MODULPOSITIONS], _), EMPTYMODULPOSITIONS):-
	extractEmptyModulePositionsFromUnfinishedModules(module(NAME, MODULPOSITIONS, _), EMPTYMODULPOSITIONS),!.


extractModulesForSubject(SUBJECT, [MODUL|[]], [MODUL], []):-
	isModuleFor(SUBJECT, MODUL),!.
	
extractModulesForSubject(_, [MODUL|[]], [], [MODUL]):-!.
	
extractModulesForSubject(SUBJECT, [MODUL|STARTEDMODULES], [MODUL|MODULESFORMAJOR], EXTRAMODULES):-
	isModuleFor(SUBJECT, MODUL),
	extractModulesForSubject(SUBJECT, STARTEDMODULES, MODULESFORMAJOR, EXTRAMODULES), !.
	
extractModulesForSubject(SUBJECT, [MODUL|STARTEDMODULES], MODULESFORMAJOR, [MODUL|EXTRAMODULES]):-
	extractModulesForSubject(SUBJECT, STARTEDMODULES, MODULESFORMAJOR, EXTRAMODULES), !.

getMaxGrade(NAME, MODULELIST, 4):-
	member(module(NAME, _, -1), MODULELIST),!.

getMaxGrade(NAME, MODULELIST, GRADE):-
	member(module(NAME, _, GRADE), MODULELIST),!.
	
getMaxGrade(_, _, 4):-!.

getMinGrade(NAME, MODULELIST, 1):-
	member(module(NAME, _, -1), MODULELIST),!.

getMinGrade(NAME, MODULELIST, GRADE):-
	member(module(NAME, _, GRADE), MODULELIST),!.
	
getMinGrade(_,_,1):-!.

extractEmptyModulPositionsForMajor(_, _, []).
	
extractEmptyModulPositionsForSecondMajor(_, _, []).
	
extractEmptyModulPositionsForMinor(_, _, []).
	
calculateSubjectMinGradeForMajor(_, _, 1).

calculateSubjectMaxGradeForMajor(_, _, 4).

calculateSubjectMinGradeForSecondMajor(_, _, 1).
	
calculateSubjectMaxGradeForSecondMajor(_, _, 4).

calculateSubjectMinGradeForMinor(_, _, 1).

calculateSubjectMaxGradeForMinor(_, _, 4).
	
	
	
