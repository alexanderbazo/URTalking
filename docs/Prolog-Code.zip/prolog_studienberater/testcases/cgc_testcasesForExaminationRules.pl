%###########################################%
%##    Testcases for examination Rules    ##%
%###########################################%

%remove all previous predicates
:- abolish(run/1).


showTestcases('Examination Rules'):-
	nl,
	write('Available testcases: '),nl,
	write('1: extract modules for Medienwissenschaft'),nl,
	write('2: extract all unfinished module positions from list'),nl,
	write('3: extract all unfinished module positions from list for Medienwissenschaft major'),nl,
	write('4: calculate max and min possible grade with all modules'),nl,
	write('5: calculate max and min possible grade with module missing'),nl,
	write('6: calculate max and min possible grade with another module missing'),nl,
	write('7: generate valide subject list for first major'),nl,
	write('8: generate valide subject list for second major'),nl,
	write('9: generate valide subject list for minor'),nl,
	write('10: generate started modules for first major from userdata'),nl,
	write('11: generate started modules for second major from userdata'),nl,
	write('12: generate started modules for first minor from userdata (no data)'),nl,
	write('13: generate started modules for second minor from userdata (no data)'),nl,
	write('use "run(TESTCASE_NUMBER)" to run specific testcase'),nl,
	write('use "runall." to execute all testcases'),
	nl,nl.
	
runall:-
	write('Running all testcases ... '),nl,
	write('************************************************'),nl,nl,
	run(1),nl,
	run(2),nl,
	run(3),nl,
	run(4),nl,
	run(5),nl,
	run(6),nl,
	run(7),nl,
	run(8),nl,
	run(9),nl,
	run(10),nl,
	run(11),nl,
	run(12),nl,
	run(13),nl,
	write('************************************************'),nl,
	write('Finished executing all testcases.'),nl.
	
run(X):-
	var(X),
	write('Using variables here will cause dead kitties!'),!.

run(X):-
	compound(X),
	write('Using strings here will cause more dead kitties!'),!.

run(X):-
	X < 0,printRunError(X),!.

run(X):-
	X > 13,printRunError(X),!.
	
run(1):-
	write('1: '),nl,
	write('extractModulesForSubject("Medienwissenschaft", [module("MED-M 01", [], 2), module("MED-M 02", [], 2), module("MED-M 03", [], 2), module("EVTH-BA-M 01", [], 2), module("MED-M 04", [], 2)], MODULESFORSUBJECT, EXTRAMODULES)'), nl, nl,
	extractModulesForSubject('Medienwissenschaft', [module('MED-M 01', [], 2), module('MED-M 02', [], 2), module('MED-M 03', [], 2), module('EVTH-BA-M 01', [], 2), module('MED-M04', [] , 2)], MODULESFORSUBJECT, EXTRAMODULES),
	nl,nl,
	write(MODULESFORSUBJECT),
	nl,nl,
	write(EXTRAMODULES),nl.
	
run(2):-
	write('2: '),nl,
	write('extractUnfinishedModuleWithModulPositions([module("INF-M 01", [modulePosition("1", 2), modulePosition("2", -1)], 2), ...], X)'),
	extractUnfinishedModuleWithModulPositions([module('INF-M 01', [modulePosition('1', 2), modulePosition('2', -1)], -1), module('INF-M 02', [modulePosition('1', -1), modulePosition('2', 2), modulePosition('3', -1)], -1), module('INF-M 03', [modulePosition('1', -1), modulePosition('2', -1)], -1)], UNFINISHEDMODULES),
	nl,nl,
	write(UNFINISHEDMODULES),nl.
	
run(3):-
	write('3: '),nl,
	write('listEmptyModulPositionForMajor("Medienwissenschaft", [module("MED-M 01", [modulePosition("1", 2), modulePosition("2", -1)], 2), ...], X)'),
	listEmptyModulPositionForMajor('Medienwissenschaft', [module('MED-M 01', [modulePosition('1', 2), modulePosition('2', 3)], 2.5), module('MED-M 03', [modulePosition('1', -1), modulePosition('2', 3), modulePosition('3', 3)], -1), module('MED-M 04', [modulePosition('1', 2), modulePosition('2', -1), modulePosition('3', -1), modulePosition('4', 2)], -1), module('MED-M 05', [modulePosition('1', 2), modulePosition('2', 3), modulePosition('3', -1)], 2.5)], UNFINISHEDMODULES),
	nl,nl,
	write(UNFINISHEDMODULES),nl.
	
run(4):-
	write('4: '),nl,
	write('calculateSubjectMinGradeForMajor("Medienwissenschaft", MODULES, MINGRADE) and calculateSubjectMaxGradeForMajor("Medienwissenschaft", MODULES, MAXGRADE)'),nl,
	MODULES = [module('MED-M 01', [modulePosition('1', 2), modulePosition('2', 3)], 2.5), module('MED-M 02', [modulePosition('1', -1), modulePosition('2', 3), modulePosition('3', 3)], -1), module('MED-M 03', [modulePosition('1', 2), modulePosition('2', -1), modulePosition('3', -1), modulePosition('4', 2)], -1), module('MED-M 09', [modulePosition('1', 2), modulePosition('2', 3), modulePosition('3', -1)], 2.5), module('MED-M 10', [modulePosition('1', -1), modulePosition('2', 3), modulePosition('3', -1)], -1)],
	testMinMax('Medienwissenschaft', MODULES, MAXGRADE, MINGRADE),
	nl,nl,
	write('Min Grade: '), write(MINGRADE),nl,
	write('Max Grade: '), write(MAXGRADE),nl.

run(5):-
	write('5: '),nl,
	write('calculateSubjectMinGradeForMajor("Medienwissenschaft", MODULES, MINGRADE) and calculateSubjectMaxGradeForMajor("Medienwissenschaft", MODULES, MAXGRADE)'),nl,
	MODULES = [module('MED-M 01', [modulePosition('1', 2), modulePosition('2', 3)], 2.5), module('MED-M 03', [modulePosition('1', 2), modulePosition('2', -1), modulePosition('3', -1), modulePosition('4', 2)], -1), module('MED-M 09', [modulePosition('1', 2), modulePosition('2', 3), modulePosition('3', -1)], 2.5), module('MED-M 10', [modulePosition('1', -1), modulePosition('2', 3), modulePosition('3', -1)], -1)],
	testMinMax('Medienwissenschaft', MODULES,MAXGRADE, MINGRADE),
	nl,nl,
	write('Min Grade: '), write(MINGRADE),nl,
	write('Max Grade: '), write(MAXGRADE),nl.
	
	
run(6):-
	write('6: '),nl,
	write('calculateSubjectMinGradeForMajor("Medienwissenschaft", MODULES, MINGRADE) and calculateSubjectMaxGradeForMajor("Medienwissenschaft", MODULES, MAXGRADE)'),nl,
	MODULES = [module('MED-M 02', [modulePosition('1', -1), modulePosition('2', 3), modulePosition('3', 3)], -1), module('MED-M 03', [modulePosition('1', 2), modulePosition('2', -1), modulePosition('3', -1), modulePosition('4', 2)], -1), module('MED-M 09', [modulePosition('1', 2), modulePosition('2', 3), modulePosition('3', -1)], 2.5), module('MED-M 10', [modulePosition('1', -1), modulePosition('2', 3), modulePosition('3', -1)], -1)],
	testMinMax('Medienwissenschaft', MODULES,MAXGRADE, MINGRADE),
	nl,nl,
	write('Min Grade: '), write(MINGRADE),nl,
	write('Max Grade: '), write(MAXGRADE),nl.

run(7):-
	write('7: '),nl,
	write('findAdditionalSubjectForFirstMajor("Englische Sprachwissenschaft", LIST)'),
	findAdditionalSubjectForFirstMajor('Englische Sprachwissenschaft', LIST),
	nl,nl,
	write(LIST),nl.

run(8):-
	write('8: '),nl,
	write('findAdditionalSubjectForSecondMajor("Englische Sprachwissenschaft", LIST)'),
	findAdditionalSubjectForSecondMajor('Englische Sprachwissenschaft', LIST),
	nl,nl,
	write(LIST),nl.
	
run(9):-
	write('9: '),nl,
	write('findAdditionalSubjectForMinor("Informationswissenschaft", "Englische Sprachwissenschaft", LIST)'),
	findAdditionalSubjectForMinor('Informationswissenschaft', 'Englische Sprachwissenschaft', LIST),
	nl,nl,
	write(LIST),nl.
	
run(10):-
	write('10: '),nl,
	write('generateStartedModuleListForFirstMajor(LIST)'),
	generateStartedModuleListForFirstMajor(LIST),
	nl,nl,
	write(LIST),nl.
	
run(11):-
	write('11: '),nl,
	write('generateStartedModuleListForSecondMajor(LIST)'),
	generateStartedModuleListForSecondMajor(LIST),
	nl,nl,
	write(LIST),nl.
	
run(12):-
	write('12: '),nl,
	write('generateStartedModuleListForFirstMinor(LIST)'),
	generateStartedModuleListForFirstMinor(LIST),
	nl,nl,
	write(LIST),nl.
	
run(13):-
	write('13: '),nl,
	write('generateStartedModuleListForSecondMinor(LIST)'),
	generateStartedModuleListForSecondMinor(LIST),
	nl,nl,
	write(LIST),nl.

testMinMax(NAME, MODULES, MAX, MIN):-
	calculateSubjectMinGradeForMajor(NAME, MODULES, MIN),
	calculateSubjectMaxGradeForMajor(NAME, MODULES, MAX).
	
	
printRunError(INVALID):-
	write('Error: Testcase '),
	write(INVALID),
	write(' not found! Please try a number between 1 and 13'), nl, nl.
	
