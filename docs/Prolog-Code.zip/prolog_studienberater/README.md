Ein Studienberater in PROLOG
=====================
Dieses Projekt forciert die Umsetzung eines PROLOG basierten Studienberaters für die Universität Regensburg.

FAQ
* There is no default .gitignore for Prolog ;( 
