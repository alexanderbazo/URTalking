%###########################################%
%     Examination Rules Medieninformatik    %
%################PO.1-2-3###################%
%#################PO.2.40###################%

% Given two minor subjects students are not allowed to choose 'Informationswissenschaft' AND 'Medieninformatik'
bachelor(FIRSTMAJOR,'Medieninformatik',SECONDMINOR):-
	FIRSTMAJOR\='Medieninformatik',
	FIRSTMAJOR\=SECONDMINOR,
	SECONDMINOR\='Medieninformatik',
	SECONDMINOR\='Informationswissenschaft',
	firstMajor(FIRSTMAJOR),
	minor('Medieninformatik'),
	minor(SECONDMINOR).	
	
% grades

calculateSubjectMinGradeForMajor('Medieninformatik', FINISHEDMODULES, GRADE):-
	!,getMinGrade('MEI-M 03', FINISHEDMODULES, GRADE_03),
	getMinGrade('MEI-M 04', FINISHEDMODULES, GRADE_04),
	getMinGrade('MEI-M 05', FINISHEDMODULES, GRADE_05),
	getMinGrade('MEI-M 10', FINISHEDMODULES, GRADE_10),
	GRADE is ((GRADE_03 + GRADE_04 + GRADE_05  + GRADE_10)/ 4).

calculateSubjectMaxGradeForMajor('Medieninformatik', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('MEI-M 03', FINISHEDMODULES, GRADE_03),
	getMaxGrade('MEI-M 04', FINISHEDMODULES, GRADE_04),
	getMaxGrade('MEI-M 05', FINISHEDMODULES, GRADE_05),
	getMaxGrade('MEI-M 10', FINISHEDMODULES, GRADE_10),
	GRADE is ((GRADE_03 + GRADE_04 + GRADE_05  + GRADE_10)/ 4).


calculateSubjectMinGradeForSecondMajor('Medieninformatik', FINISHEDMODULES, GRADE):-
	!,getMinGrade('MEI-M 01', FINISHEDMODULES, GRADE_01),
	getMinGrade('MEI-M 02', FINISHEDMODULES, GRADE_02),
	getMinGrade('MEI-M 03', FINISHEDMODULES, GRADE_03),
	getMinGrade('MEI-M 05', FINISHEDMODULES, GRADE_05),
	getMinGrade('MEI-M 08', FINISHEDMODULES, GRADE_08),
	GRADE is ((GRADE_01 + GRADE_02 + GRADE_03+ GRADE_05 + GRADE_08)/ 5).

calculateSubjectMaxGradeForSecondMajor('Medieninformatik', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('MEI-M 01', FINISHEDMODULES, GRADE_01),
	getMaxGrade('MEI-M 02', FINISHEDMODULES, GRADE_02),
	getMaxGrade('MEI-M 03', FINISHEDMODULES, GRADE_03),
	getMaxGrade('MEI-M 05', FINISHEDMODULES, GRADE_05),
	getMaxGrade('MEI-M 08', FINISHEDMODULES, GRADE_08),
	GRADE is ((GRADE_01 + GRADE_02 + GRADE_03+ GRADE_05 + GRADE_08)/ 5).
	
calculateSubjectMinGradeForMinor('Medieninformatik', FINISHEDMODULES, GRADE):-
	!,getMinGrade('MEI-M 01', FINISHEDMODULES, GRADE_01),
	getMinGrade('MEI-M 06', FINISHEDMODULES, GRADE_06),
	getMinGrade('MEI-M 07', FINISHEDMODULES, GRADE_07),
	GRADE is ((GRADE_01 + GRADE_06 + GRADE_07)/ 3).

calculateSubjectMaxGradeForMinor('Medieninformatik', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('MEI-M 01', FINISHEDMODULES, GRADE_01),
	getMaxGrade('MEI-M 06', FINISHEDMODULES, GRADE_06),
	getMaxGrade('MEI-M 07', FINISHEDMODULES, GRADE_07),
	GRADE is ((GRADE_01 + GRADE_06 + GRADE_07)/ 3).
	
	
