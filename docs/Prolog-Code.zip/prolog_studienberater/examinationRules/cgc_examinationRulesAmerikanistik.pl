%###########################################%
%##### Examination Rules Amerikanistik #####%
%################PO.1-2-3###################%

% Students are only allowed to study one of these subjects 'Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft'

bachelor(FIRSTMAJOR,SECONDMAJOR):-
	firstMajor(FIRSTMAJOR),
	secondMajor(SECONDMAJOR),
	member(FIRSTMAJOR, ['Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft']),!,
	not_member(SECONDMAJOR, ['Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft']),
	FIRSTMAJOR\=SECONDMAJOR.	

bachelor(FIRSTMAJOR,FIRSTMINOR,SECONDMINOR):-
	firstMajor(FIRSTMAJOR),
	minor(FIRSTMINOR),
	minor(SECONDMINOR),
	member(FIRSTMAJOR, ['Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft']),!,
	not_member(FIRSTMINOR, ['Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft']),
	not_member(SECONDMINOR, ['Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft']),
	FIRSTMINOR\=SECONDMINOR,
	FIRSTMINOR\=FIRSTMAJOR,
	SECONDMINOR\=FIRSTMAJOR.
	
bachelor(FIRSTMAJOR,FIRSTMINOR,SECONDMINOR):-
	firstMajor(FIRSTMAJOR),
	minor(FIRSTMINOR),
	minor(SECONDMINOR),
	not_member(FIRSTMAJOR, ['Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft']),!,
	member(FIRSTMINOR, ['Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft']),
	not_member(SECONDMINOR, ['Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft']),
	FIRSTMINOR\=SECONDMINOR,
	FIRSTMINOR\=FIRSTMAJOR,
	SECONDMINOR\=FIRSTMAJOR.