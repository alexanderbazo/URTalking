Examination Rules
=====================


## subject/1
subject(NAME) describes a subject that is available as major, second major or minor.

## subjectOnlyForSecondMajor/1
subjectOnlyForSecondMajor(NAME) describes a subject that is only available for use as a second major.

## subjectOnlyForMinor/1
subjectOnlyForMinor(NAME) describes a subject that is only available as a minor.

## firstMajor/1
firstMajor(NAME) describes a student's first major subject.

## secondMajor/1
secondMajor(NAME) describes a students second major subject.

## minor/1
minor(NAME) describes a minor subject.