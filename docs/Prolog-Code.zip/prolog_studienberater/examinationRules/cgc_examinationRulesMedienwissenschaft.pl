%###########################################%
%### Examination Rules Medienwissenschaft ##%
%################PO.2.50####################%

modulesForMajor('Medienwissenschaft', FINISHEDMODULES):-
	studentsSecondMajor('Informationswissenschaft');
	studentsFirstMinor('Informationswissenschaft');
	studentsSecondMinor('Informationswissenschaft'),
	extractModulesForSubject('Medienwissenschaft', FINISHEDMODULES, MODULESFORMAJOR, EXTRAMODULES),
	length(EXTRAMODULES, NUMBEROFEXTRAMODULES),
	NUMBEROFEXTRAMODULES >= 1,!,
	sort(MODULESFORMAJOR, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 09', _, _), module('MED-M 10', _, _), module('MED-M 04', _, _)]);!;
	sort(MODULESFORMAJOR, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 09', _, _), module('MED-M 10', _, _), module('MED-M 05', _, _)]);!;
	sort(MODULESFORMAJOR, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 09', _, _), module('MED-M 10', _, _), module('MED-M 06', _, _)]);!;
	sort(MODULESFORMAJOR, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 09', _, _), module('MED-M 10', _, _), module('MED-M 08', _, _)]).

modulesForMajor('Medienwissenschaft', FINISHEDMODULES):-
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 03', _, _), module('MED-M 09', _, _), module('MED-M 10', _, _), module('MED-M 04', _, _)]);!;
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 03', _, _), module('MED-M 09', _, _), module('MED-M 10', _, _), module('MED-M 05', _, _)]);!;
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 03', _, _), module('MED-M 09', _, _), module('MED-M 10', _, _), module('MED-M 06', _, _)]);!;
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 03', _, _), module('MED-M 09', _, _), module('MED-M 10', _, _), module('MED-M 08', _, _)]).
	
% THINGS TO THINK ABOUT
modulesForSecondMajor('Medienwissenschaft', FINISHEDMODULES):-
	studentFirstMajor('Informationswissenschaft'),
	extractModulesForSubject('Medienwissenschaft', FINISHEDMODULES, MODULESFORMAJOR, EXTRAMODULES),
	length(EXTRAMODULES, NUMBEROFEXTRAMODULES),
	NUMBEROFEXTRAMODULES >= 1,!,
	sort(MODULESFORMAJOR, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 04', _, _)]);!;
	sort(MODULESFORMAJOR, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 05', _, _)]);!;
	sort(MODULESFORMAJOR, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 06', _, _)]);!;
	sort(MODULESFORMAJOR, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 08', _, _)]).

modulesForSecondMajor('Medienwissenschaft', FINISHEDMODULES):-
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 03', _, _), module('MED-M 04', _, _)]);!;
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 03', _, _), module('MED-M 05', _, _)]);!;
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 03', _, _), module('MED-M 06', _, _)]);!;
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _), module('MED-M 03', _, _), module('MED-M 08', _, _)]).
	
	
modulesForMinor('Medienwissenschaft', FINISHEDMODULES):-
	sort(FINISHEDMODULES, [module('MED-M 01', _, _), module('MED-M 02', _, _)]).
	
% grades

calculateSubjectMinGradeForMajor('Medienwissenschaft', FINISHEDMODULES, GRADE):-
	!,getMinGrade('MED-M 01', FINISHEDMODULES, GRADE_01),
	getMinGrade('MED-M 02', FINISHEDMODULES, GRADE_02),
	getMinGrade('MED-M 03', FINISHEDMODULES, GRADE_03),
	getMinGrade('MED-M 09', FINISHEDMODULES, GRADE_09),
	getMinGrade('MED-M 10', FINISHEDMODULES, GRADE_10),
	GRADE is ((GRADE_01 + GRADE_02 + GRADE_03 + GRADE_09 + GRADE_10)/ 5).

calculateSubjectMaxGradeForMajor('Medienwissenschaft', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('MED-M 01', FINISHEDMODULES, GRADE_01),
	getMaxGrade('MED-M 02', FINISHEDMODULES, GRADE_02),
	getMaxGrade('MED-M 03', FINISHEDMODULES, GRADE_03),
	getMaxGrade('MED-M 09', FINISHEDMODULES, GRADE_09),
	getMaxGrade('MED-M 10', FINISHEDMODULES, GRADE_10),
	GRADE is ((GRADE_01 + GRADE_02 + GRADE_03 + GRADE_09 + GRADE_10)/ 5).


calculateSubjectMinGradeForSecondMajor('Medienwissenschaft', FINISHEDMODULES, GRADE):-
	getMinGrade('MED-M 01', FINISHEDMODULES, GRADE_01),
	getMinGrade('MED-M 02', FINISHEDMODULES, GRADE_02),
	getMinGrade('MED-M 03', FINISHEDMODULES, GRADE_03),
	GRADE is ((GRADE_01 + GRADE_02 + GRADE_03)/ 3).

calculateSubjectMaxGradeForSecondMajor('Medienwissenschaft', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('MED-M 01', FINISHEDMODULES, GRADE_01),
	getMaxGrade('MED-M 02', FINISHEDMODULES, GRADE_02),
	getMaxGrade('MED-M 03', FINISHEDMODULES, GRADE_03),
	GRADE is ((GRADE_01 + GRADE_02 + GRADE_03)/ 3).
	
calculateSubjectMinGradeForMinor('Medienwissenschaft', FINISHEDMODULES, GRADE):-
	!,getMinGrade('MED-M 01', FINISHEDMODULES, GRADE_01),
	getMinGrade('MED-M 02', FINISHEDMODULES, GRADE_02),
	GRADE is ((GRADE_01 + GRADE_02)/ 2).

calculateSubjectMaxGradeForMinor('Medienwissenschaft', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('MED-M 01', FINISHEDMODULES, GRADE_01),
	getMaxGrade('MED-M 02', FINISHEDMODULES, GRADE_02),
	GRADE is ((GRADE_01 + GRADE_02)/ 2).

isModuleFor('Medienwissenschaft', module(NAME, _ ,_)):-
	sub_atom(NAME, 0, 5, _ , PREFIX),
	PREFIX = 'MED-M'.

extractEmptyModulPositionsForMajor('Medienwissenschaft', STARTEDMODULS, EMPTYMODULPOSITIONS):-
	fail,
	MODULES is [], 
	subtract(MODULES, STARTEDMODULS, NOTLISTED_MODULS),
	extractUnfinishedModuleWithModulPositions(NOTLISTED_MODULS, EMPTYMODULPOSITIONS),!.
	
extractEmptyModulPositionsForSecondMajor('Medienwissenschaft', STARTEDMODULS, EMPTYMODULPOSITIONS):-
	fail,
	MODULES is [], 
	subtract(MODULES, STARTEDMODULS, NOTLISTED_MODULS),
	extractUnfinishedModuleWithModulPositions(NOTLISTED_MODULS, EMPTYMODULPOSITIONS),!.
	
extractEmptyModulPositionsForMinor('Medienwissenschaft', STARTEDMODULS, EMPTYMODULPOSITIONS):-
	fail,
	MODULES is [],
	subtract(MODULES, STARTEDMODULS, NOTLISTED_MODULS),
	extractUnfinishedModuleWithModulPositions(NOTLISTED_MODULS, EMPTYMODULPOSITIONS),!.
	
	
 