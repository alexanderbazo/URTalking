%###########################################%
%###### Possible Subject Combinations ######%
%################PO.1-2-1###################%

% Generally: 'Frei Kombinierbares Nebenfach' herein is used as a standard minor subject and it's special case is not yet modeled 

bachelor(FIRSTMAJOR, SECONDMAJOR):-
	!,firstMajor(FIRSTMAJOR),
	secondMajor(SECONDMAJOR),
	FIRSTMAJOR\=SECONDMAJOR.
		
bachelor(FIRSTMAJOR,FIRSTMINOR,SECONDMINOR):-
	!,firstMajor(FIRSTMAJOR),
	minor(FIRSTMINOR),
	minor(SECONDMINOR),
	FIRSTMAJOR\=FIRSTMINOR,
	FIRSTMAJOR\=SECONDMINOR,
	FIRSTMINOR\=SECONDMINOR.