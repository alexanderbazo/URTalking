%###########################################%
% Examination Rules Informationwissenschaft %
%################PO.1-2-3###################%
%#################PO.2.40###################%

modulesForMajor('Informationswissenschaft', FINISHEDMODULES):-
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 02', _, _), module('INF-M 03', _, _), module('INF-M 04', _, _), module('INF-M 05', _, _), module('INF-M 06', _, _), module('INF-M 07', _, _)]).
	
% What if a student finished more modules than necessary? This can be ignored as for the major/minor subject only a certain amount of modules are implemented in flexnow, etc. and any
% courses/modules in addition to that have to be listed in the Freier Wahlbereich. We suggest to comply with this pattern.

% THINGS TO THINK ABOUT
modulesForSecondMajor('Informationswissenschaft', FINISHEDMODULES):-
	studentsFirstMajor('Medieninformatik'),
	% INSERT SPECIAL COURSE FOR MEDIA INFORMATICS AS SECOND MAJOR
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 02', _, _), module('INF-M 04', _, _), module('INF-M 05', _, _)]);!;
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 02', _, _), module('INF-M 05', _, _), module('INF-M 06', _, _)]);!;
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 02', _, _), module('INF-M 04', _, _), module('INF-M 06', _, _)]).	

modulesForSecondMajor('Informationswissenschaft', FINISHEDMODULES):-
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 02', _, _), module('INF-M 03', _, _), module('INF-M 04', _, _), module('INF-M 05', _, _)]);!;
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 02', _, _), module('INF-M 03', _, _), module('INF-M 05', _, _), module('INF-M 06', _, _)]);!;
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 02', _, _), module('INF-M 03', _, _), module('INF-M 04', _, _), module('INF-M 06', _, _)]).	

modulesForMinor('Informationswissenschaft', FINISHEDMODULES):-
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 04', _, _)]);!;
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 05', _, _)]);!;
	sort(FINISHEDMODULES, [module('INF-M 01', _, _), module('INF-M 06', _, _)]).
	
	
% Given two minor subjects students are not allowed to choose 'Informationswissenschaft' AND 'Medieninformatik'
bachelor(FIRSTMAJOR,'Informationswissenschaft',SECONDMINOR):-
	FIRSTMAJOR\='Informationswissenschaft',
	FIRSTMAJOR\=SECONDMINOR,
	SECONDMINOR\='Informationswissenschaft',
	SECONDMINOR\='Medieninformatik',
	firstMajor(FIRSTMAJOR),
	minor('Informationswissenschaft'),
	minor(SECONDMINOR).	
	
	
% grades

calculateSubjectMinGradeForMajor('Informationswissenschaft', FINISHEDMODULES, GRADE):-
	!,getMinGrade('INF-M 01', FINISHEDMODULES, GRADE_01),
	getMinGrade('INF-M 02', FINISHEDMODULES, GRADE_02),
	getMinGrade('INF-M 03', FINISHEDMODULES, GRADE_03),
	getMinGrade('INF-M 04', FINISHEDMODULES, GRADE_04),
	getMinGrade('INF-M 05', FINISHEDMODULES, GRADE_05),
	getMinGrade('INF-M 06', FINISHEDMODULES, GRADE_06),
	getMinGrade('INF-M 07', FINISHEDMODULES, GRADE_07),
	GRADE is ((GRADE_01*0.1 + GRADE_02*0.1 + GRADE_03*0.1 + GRADE_04*0.15 + GRADE_05*0.15 + GRADE_06 * 0.15 + GRADE_07 * 0.25)).

calculateSubjectMaxGradeForMajor('Informationswissenschaft', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('INF-M 01', FINISHEDMODULES, GRADE_01),
	getMaxGrade('INF-M 02', FINISHEDMODULES, GRADE_02),
	getMaxGrade('INF-M 03', FINISHEDMODULES, GRADE_03),
	getMaxGrade('INF-M 04', FINISHEDMODULES, GRADE_04),
	getMaxGrade('INF-M 05', FINISHEDMODULES, GRADE_05),
	getMaxGrade('INF-M 06', FINISHEDMODULES, GRADE_06),
	getMaxGrade('INF-M 07', FINISHEDMODULES, GRADE_07),
	GRADE is ((GRADE_01*0.1 + GRADE_02*0.1 + GRADE_03*0.1 + GRADE_04*0.15 + GRADE_05*0.15 + GRADE_06 * 0.15 + GRADE_07 * 0.25)).

calculateSubjectMinGradeForSecondMajor('Informationswissenschaft', FINISHEDMODULES, GRADE):-
	!,getMinGrade('INF-M 01', FINISHEDMODULES, GRADE_01),
	getMinGrade('INF-M 02', FINISHEDMODULES, GRADE_02),
	getMinGrade('INF-M 03', FINISHEDMODULES, GRADE_03),
	subtract(FINISHEDMODULES, [module('INF-M 01',_,_), module('INF-M 02', _,_),module('INF-M 03',_,_)], [module(FIRSTMODUL,_,_),module(SECONDMODUL,_,_)|[]]),
	getMinGrade(FIRSTMODUL, FINISHEDMODULES, GRADE_0X),
	getMinGrade(SECONDMODUL, FINISHEDMODULES, GRADE_0Y),
	GRADE is ((GRADE_01*0.15 + GRADE_02*0.15 + GRADE_03*0.15 + GRADE_0X * 0.275 + GRADE_0Y * 0.275)).
	
% calculateSubjectMaxGradeForSecondMajor('Informationswissenschaft', [module('KUNST-BA-M 01', [], 2), module('INF-M 01', [], 3), module('INF-M 02', [], 3),module('INF-M 03', [], 3), module('Kunst-BA-M 02', [], 3)], GRADE)

calculateSubjectMaxGradeForSecondMajor('Informationswissenschaft', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('INF-M 01', FINISHEDMODULES, GRADE_01),
	getMaxGrade('INF-M 02', FINISHEDMODULES, GRADE_02),
	getMaxGrade('INF-M 03', FINISHEDMODULES, GRADE_03),
	subtract(FINISHEDMODULES, [module('INF-M 01',_,_), module('INF-M 02', _,_),module('INF-M 03',_,_)], [module(FIRSTMODUL,_,_),module(SECONDMODUL,_,_)|[]]),
	getMaxGrade(FIRSTMODUL, FINISHEDMODULES, GRADE_0X),
	getMaxGrade(SECONDMODUL, FINISHEDMODULES, GRADE_0Y),
	GRADE is ((GRADE_01*0.15 + GRADE_02*0.15 + GRADE_03*0.15 + GRADE_0X * 0.275 + GRADE_0Y * 0.275)).
	
calculateSubjectMinGradeForMinor('Informationswissenschaft', FINISHEDMODULES, GRADE):-
	!,getMinGrade('INF-M 01', FINISHEDMODULES, GRADE_01),
	subtract(FINISHEDMODULES, [module('INF-M 01',_,_)], [module(MODUL,_,_)|[]]),
	getMinGrade(MODUL, FINISHEDMODULES, GRADE_02),
	GRADE is ((GRADE_01 + GRADE_02)/ 2).

calculateSubjectMaxGradeForMinor('Informationswissenschaft', FINISHEDMODULES, GRADE):-
	!,getMaxGrade('INF-M 01', FINISHEDMODULES, GRADE_01),
	subtract(FINISHEDMODULES, [module('INF-M 01',_,_)], [module(MODUL,_,_)|[]]),
	getMaxGrade(MODUL, FINISHEDMODULES, GRADE_02),
	GRADE is ((GRADE_01 + GRADE_02)/ 2).
	
