%###########################################%
%###  Examination Rules for PhilFak III  ###%
%#######    Bachelor of Arts only!    ######%
%################PO.1-2-1/2#################%

%LP for major,minor and thesis

% Declaring possible subjects for major and minor
firstMajor(NAME):-subject(NAME).
secondMajor(NAME):-subject(NAME).
secondMajor(NAME):-subjectOnlyForSecondMajor(NAME).
minor(NAME):-subject(NAME).
minor(NAME):-subjectOnlyForMinor(NAME).

% Available subjects (for major and special cases for subjects only available in major or minor)
subject('Allgemeine und Vergleichende Sprachwissenschaft').
subject('Amerikanistik (American Studies)').
subject('Angewandte Bewegungswissenschaften'). 
subject('Anglistik (British Studies)').
subject('Bildende Kunst und Aesthetische Erziehung').
subject('Deutsche Philologie').
subject('Englische Sprachwissenschaft').
subject('Evangelische Theologie').
subject('Franzoesische Philologie').
subject('Geschichte').
subject('Griechische Philologie').
subject('Informationswissenschaft').
subject('Italienische Philologie').
subject('Klassische Archaeologie').
subject('Kunstgeschichte').
subject('Lateinische Philologie').
subject('Medieninformatik').
subject('Medienwissenschaft').
subject('Musikwissenschaft').
subject('Philosophie').
subject('Politikwissenschaft').
subject('Polnische Philologie').
subject('Russische Philologie').
subject('Spanische Philologie').
subject('Suedosteuropastudien').
subject('Tschechische Philologie').
subject('Vergleichende Kulturwissenschaft').
subject('Vor- und Fruehgeschichte').
subjectOnlyForSecondMajor('Suedslavische Philologie').
subjectOnlyForMinor('Suedslavische Philologie').
subjectOnlyForMinor('Frei Kombinierbares Nebenfach').
subjectOnlyForMinor('Wissenschaftsgeschichte').