%################################################%
% Examination Rules Englische Sprachwissenschaft %
%################PO.1-2-3########################%

% Students are only allowed to study on of these subjects 'Amerikanistik (American Studies)', 'Anglistik (British Studies)', 'Englische Sprachwissenschaft'
% See cgc_examinationRulesAmerikanistik.pl