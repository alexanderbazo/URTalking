# Dokumentation

## Technische Prädikate
### not member/2
**not_member(ITEM, LIST)**  

Ist Falsch, wenn ITEM nicht in LIST vorhanden ist.


### init/0
**init**  

Lädt beim Start alle benötigten Dateien für die Benutzung des Systems.

## Datenbasis (Studenten und Studium)

### bachelor/2
**bachelor(FIRSTMAJOR,SECONDMAJOR)**  
Ist wahr wenn FIRSTMAJOR und SECONDMAJOR in dieser Kombination als Bachelor-Studiengang studiert werden können. FIRSTMAJOR und SECONDMAJOR sind dabei die  Namen von Studienfächern.

### bachelor/3
**bachelor(FIRSTMAJOR,FIRSTMINOR,SECONDMINOR)**  
Ist wahr wenn FIRSTMAJOR in der Kombination mit den Nebenfächern FIRSTMINOR und SECONDMINOR als Bachelor-Studiengang studiert werden können. FIRSTMAJOR , FIRSTMINOR und SECONDMINOR sind dabei die  Namen von Studienfächern.

### firstMajor/1
**firstMajor(SUBJECTNAME)**  

Beschreibt ein Hauptfach und ist wahr, wenn ein Studienfach mit der Bezeichnung SUBJECTNAME exisitiert, dass als Hauptfach studiert werden kann.

### matriculationNumber/1
**matriculationNumber(NUMBER)**  

Speichert die Matrikelnummer eines Studenten.

### minor/1
**minor(SUBJECTNAME)**  

Beschreibt ein Nebenfach und ist wahr, wenn ein Studienfach mit der Bezeichnung SUBJECTNAME exisitiert, dass als allgemein als Nebenfach oder exklusiv nur als Nebenfach studiert werden kann.

### secondMajor/1
**secondMajor(SUBJECTNAME)**  

Beschreibt ein Hauptfach und ist wahr, wenn ein Studienfach mit der Bezeichnung SUBJECTNAME exisitiert, dass allgemein als Hauptfach oder exklusiv nur als zweites Hauptfach studiert werden kann.

### studentsModuleForFirstMajor/2
**studentsModuleForFirstMajor(MATRICLENUMBER, MODULE)**  

Enthält in MODULE ein Module module/3 das ein Student (identifiziert über seine Matrikelnummer MATRICLENUMBER) bereits teilweise oder komplett  für sein erstes Hauptfach absolviert hat. 

### studentsModulesForSecondMajor/2
**studentsModulesForSecondMajor(MATRICLENUMBER, MODULES)**  

Enthält in MODULE ein Module module/3 das ein Student (identifiziert über seine Matrikelnummer MATRICLENUMBER) bereits teilweise oder komplett  für sein zweites Hauptfach absolviert hat. 

### studentsModuleForFirstMinor/2
**studentsModuleForFirstMinor(MATRICLENUMBER, MODULES)**  

Enthält in MODULE ein Module module/3 das ein Student (identifiziert über seine Matrikelnummer MATRICLENUMBER) bereits teilweise oder komplett  für sein erstes Nebenfach absolviert hat. 

### studentsModulesForSecondMinor/2
**studentsModulesForSecondMinor(MATRICLENUMBER, MODULES)**  

Enthält in MODULE ein Module module/3 das ein Student (identifiziert über seine Matrikelnummer MATRICLENUMBER) bereits teilweise oder komplett  für sein zweites Nebenfach absolviert hat. 

## Datenbasis (Prüfungsordung)

### module/3
**module(MODULNAME, MODULEPOSITIONS, MODULGRADE)**  

Beschreibt ein Modul anhand dem Namen des Moduls MODULNAME. Es enhält außerdem die erforderlichen Positionen MODULEPOSITIONS für das Modul und die aus den Noten der einzelnen Modulpositionen berechnete Gesamtnote MODULGRADE.

### modulePosition/2
**modulePosition(POSITION, GRADE)**  

Beschreibt eine Modulposition anhand der POSITION im Modul selbst und der für diese Position gültige Note GRADE. Im Fall das die Modulposition noch nicht belegt wurde ist die Note -1.

### subject/1
**subject(SUBJECTNAME)**  

Beschreibt ein valides Studienfach anhand seines Namens SUBJECTNAME.

### subjectOnlyForSecondMajor/1
**subjectOnlyForSecondMajor(SUBJECTNAME)**  

Beschreibt ein valides Studienfach, dass nur als zweites Hauptfach studiert werden kann, anhand seines Namens SUBJECTNAME.

### subjectOnlyForMinor/1
**subjectOnlyForMinor(SUBJECTNAME)**  

Beschreibt ein valides Studienfach, dass nur als Nebenfach studiert werden kann, anhand seines Namens SUBJECTNAME.

## Datenbasis (Modulbeschreibungen)

### modulesForMajor/2
**modulesForSecondMajor(SUBJECTNAME, FINISHEDMODULES)**  

Ist wahr, wenn FINISHEDMODULES ausreichend abgeschlossene Module enthält um das über SUBJECTNAME gekennzeichnete Fach als Bachelorfach abzuschließen.

### modulesForSecondMajor/2
**modulesForSecondMajor(SUBJECTNAME, FINISHEDMODULES)**  

Ist wahr, wenn FINISHEDMODULES ausreichend abgeschlossene Module enthält um das über SUBJECTNAME gekennzeichnete Fach als zweites Hauptfach abzuschließen.

### modulesForMinor/2
**modulesForMinor(SUBJECTNAME, FINISHEDMODULES)**  

Ist wahr, wenn FINISHEDMODULES ausreichend abgeschlossene Module enthält um das über SUBJECTNAME gekennzeichnete Fach als Nebenfach abzuschließen.
 
## Funktionalität (Prüfungsordnung)

### calculateSubjectMinGradeForMajor/3
**calculateSubjectMinGradeForMajor(SUBJECTNAME, FINISHEDMODULES, GRADE)**  

Berechnet die bestmöglichste noch zu erreichende Fachnote GRADE für ein Hauptfach SUBJECTNAME auf der Basis bereits begonnener Module (FINISHEDMODULES) .

### calculateSubjectMaxGradeForMajor/3
**calculateSubjectMaxGradeForMajor(SUBJECTNAME, FINISHEDMODULES, GRADE)**  

Berechnet die schlechtmöglichste noch zu erreichende Fachnote GRADE für ein Hauptfach SUBJECTNAME auf der Basis bereits begonnener Module (FINISHEDMODULES) .

### calculateSubjectMinGradeForSecondMajor/3
**calculateSubjectMinGradeForSecondMajor(SUBJECTNAME, FINISHEDMODULES, GRADE)**  

Berechnet die bestmöglichste noch zu erreichende Fachnote GRADE für ein zweites Hauptfach SUBJECTNAME auf der Basis bereits begonnener Module (FINISHEDMODULES) .

### calculateSubjectMaxGradeForSecondMajor/3
**calculateSubjectMaxGradeForSecondMajor(SUBJECTNAME, FINISHEDMODULES, GRADE)**  

Berechnet die schlechtmöglichste noch zu erreichende Fachnote GRADE für ein zweites Hauptfach SUBJECTNAME auf der Basis bereits begonnener Module (FINISHEDMODULES) .

### calculateSubjectMinGradeForMinor/3
**calculateSubjectMinGradeForMinor(SUBJECTNAME, FINISHEDMODULES, GRADE)**  

Berechnet die bestmöglichste noch zu erreichende Fachnote GRADE für ein Nebenfach SUBJECTNAME auf der Basis bereits begonnener Module (FINISHEDMODULES) .

### calculateSubjectMaxGradeForMinor/3
**calculateSubjectMaxGradeForMinor(SUBJECTNAME, FINISHEDMODULES, GRADE)**  

Berechnet die schlechtmöglichste noch zu erreichende Fachnote GRADE für ein Nebenfach SUBJECTNAME auf der Basis bereits begonnener Module (FINISHEDMODULES) .

### extractEmptyModulPositionsForMajor/3
**extractEmptyModulPositionsForMajor(SUBJECTNAME, STARTEDMODULS, EMPTYMODULES)**  

Generiert alle noch zu absolvierenden Modulpositionen für ein erstes Hauptfach SUBJECTNAME auf der Basis bereits absolvierter/begonnener Module STARTEDMODULES als Liste EMPTYMODULES. Zu absolvierende Modulpositionen werden als uncompletedModulPosition/2 modelliert.

### extractEmptyModulPositionsForSecondMajor/3
**extractEmptyModulPositionsForMajor(SUBJECTNAME, STARTEDMODULS, EMPTYMODULES)**  

Generiert alle noch zu absolvierenden Modulpositionen für ein zweites Hauptfach SUBJECTNAME auf der Basis bereits absolvierter/begonnener Module STARTEDMODULES als Liste EMPTYMODULES. Zu absolvierende Modulpositionen werden als uncompletedModulPosition/2 modelliert.

### extractEmptyModulPositionsForMinor/3
**extractEmptyModulPositionsForMajor(SUBJECTNAME, STARTEDMODULS, EMPTYMODULES)**  

Generiert alle noch zu absolvierenden Modulpositionen für ein Nebenfach SUBJECTNAME auf der Basis bereits absolvierter/begonnener Module STARTEDMODULES als Liste EMPTYMODULES. Zu absolvierende Modulpositionen werden als uncompletedModulPosition/2 modelliert.

### findAdditionalSubjectForFirstMajor/2
**findAdditionalSubjectForFirstMajor(FIRSTMAJOR, VALIDSUBJECTS)**  

Generiert eine Liste VALIDSUBJECTS aller Fächer die in Kombination mit dem ersten Hauptfach FIRSTMAJOR (bestimmt über den Fachnamen) als zweites Hauptfach studiert werden können.

### findAdditionalSubjectForSecondMajor/2
**findAdditionalSubjectForSecondMajor(SECONDMAJOR, VALIDSUBJECTS)**  

Generiert eine Liste VALIDSUBJECTS aller Fächer die in Kombination mit dem zweiten Hauptfach SECONDMAJOR (bestimmt über den Fachnamen) als erstes Hauptfach studiert werden können.

### findAdditionalSubjectForMinor/3
**findAdditionalSubjectForMinor(FIRSTMAJOR, MINOR, VALIDSUBJECTS)**  

Generiert eine Liste VALIDSUBJECTS aller Fächer die in Kombination mit dem ersten Hauptfach FIRSTMAJOR und einem Nebenfach MINOR (bestimmt über den Fachnamen) als zweites Nebenfach studiert werden können.

### generateFinishedModuleListForFirstMajor/1
**generateFinishedModuleListForFirstMajor(LIST)**  

Generiert eine Liste LIST aller bereits abgeschlossenen Module für das erste Hauptfach des aktuell im System geladenen Studenten.

### generateFinishedModuleListForSecondMajor/1
**generateFinishedModuleListForSecondMajor(LIST)**  

Generiert eine Liste LIST aller bereits abgeschlossenen Module für das zweite Hauptfach des aktuell im System geladenen Studenten.

### generateFinishedModuleListForFirstMinor/1
**generateFinishedModuleListForFirstMinor(LIST)**  

Generiert eine Liste LIST aller bereits abgeschlossenen Module für das erste Nebenfach des aktuell im System geladenen Studenten.

### generateFinishedModuleListForSecondMinor/1
**generateFinishedModuleListForSecodMinor(LIST)**  

Generiert eine Liste LIST aller bereits abgeschlossenen Module für das zweite Nebenfach des aktuell im System geladenen Studenten.

### generateStartedModuleListForFirstMajor/1
**generateStartedModuleListForFirstMajor(LIST)**  

Generiert eine Liste LIST aller bereits begonnener Module für das erste Hauptfach des aktuell im System geladenen Studenten exklusive bereits abgeschlossener Module.

### generateStartedModuleListForSecondMajor/1
**generateStartedModuleListForSecondMajor(LIST)**  

Generiert eine Liste LIST aller bereits begonnener Module für das zweite Hauptfach des aktuell im System geladenen Studenten exklusive bereits abgeschlossener Module.

### generateStartedModuleListForFirstMinor/1
**generateStartedModuleListForFirstMinor(LIST)**  

Generiert eine Liste LIST aller bereits begonnener Module für das erste Nebenfach des aktuell im System geladenen Studenten exklusive bereits abgeschlossener Module.

### generateStartedModuleListForSecondMinor/1
**generateStartedModuleListForSecondMinor(LIST)**  

Generiert eine Liste LIST aller bereits begonnener Module für das zweite Nebenfach des aktuell im System geladenen Studenten exklusive bereits abgeschlossener Module.

### generateUnfinishedModuleListForFirstMajor/1
**generateUnfinishedModuleListForFirstMajor(LIST)**  

Generiert eine Liste LIST aller noch nicht abgeschlossenen Module für das erste Hauptfach des aktuell im System geladenen Studenten.

### generateUnfinishedModuleListForSecondMajor/1
**generateUnfinishedModuleListForSecondMajor(LIST)**  

Generiert eine Liste LIST aller noch nicht abgeschlossenen Module für das zweite Hauptfach des aktuell im System geladenen Studenten.

### generateUnfinishedModuleListForFirstMinor/1
**generateUnfinishedModuleListForFirstMinor(LIST)**  

Generiert eine Liste LIST aller noch nicht abgeschlossenen Module für das erste Nebenfach des aktuell im System geladenen Studenten.

### generateUnfinishedModuleListForSecondMinor/1
**generateUnfinishedModuleListForSecondMinor(LIST)**  

Generiert eine Liste LIST aller noch nicht abgeschlossenen Module für das zweite Nebenfach des aktuell im System geladenen Studenten.

### generateSubjectListForPossibleFirstMajor/1
**generateSubjectListForPossibleFirstMajor(LIST)**  

Generiert eine Liste LIST aller im System bekannten als Hauptfach studierbaren Fächer.

### generateSubjectListForPossibleSecondMajor/1
**generateSubjectListForPossibleSecondMajor(LIST)**  

Generiert eine Liste LIST aller im System bekannten nur als zweites Hauptfach studierbaren Fächer.

### generateSubjectListForPossibleMinor/1
**generateSubjectListForPossibleMinor(LIST)**  

Generiert eine Liste LIST aller im System bekannten als Nebenfach studierbaren Fächer.

### listEmptyModulPositionForMajor/3
**listEmptyModulPositionForMajor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS)**  

Generiert eine Liste EMPTYMODULPOSITIONS mit allen nicht abgeschlossenen Modulpositionen aus einer Liste von begonnen Modulen STARTEDMODULES. Dabei werden aus dieser Liste nur Module für das Fach Subject als Hauptfach betrachtet. EMPTYMPDULEPOSITIONS setzt sich aus uncompletedModulPosition/2 zusammen.

### listEmptyModulPositionForSecondMajor/3
**listEmptyModulPositionForSecondMajor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS)**  

Generiert eine Liste EMPTYMODULPOSITIONS mit allen nicht abgeschlossenen Modulpositionen aus einer Liste von begonnen Modulen STARTEDMODULES. Dabei werden aus dieser Liste nur Module für das Fach Subject als zweites Hauptfach betrachtet. EMPTYMPDULEPOSITIONS setzt sich aus uncompletedModulPosition/2 zusammen.

### listEmptyModulPositionForMinor/3
**listEmptyModulPositionForMinor(SUBJECT, STARTEDMODULES, EMPTYMODULPOSITIONS)**  

Generiert eine Liste EMPTYMODULPOSITIONS mit allen nicht abgeschlossenen Modulpositionen aus einer Liste von begonnen Modulen STARTEDMODULES. Dabei werden aus dieser Liste nur Module für das Fach Subject als Nebenfach betrachtet. EMPTYMPDULEPOSITIONS setzt sich aus uncompletedModulPosition/2 zusammen.

### uncompletedModulPosition/2
**uncompletedModulPosition(MODULNAME, POSITION)**  

Definiert eine Modulposition POSITION innerhalb eines über MODULNAME bestimmten Modul, die noch nicht absolviert bzw. abgeschlossen wurde.

## Hilfsprädikate
Die folgenden Prädikate sind für die korrekte Ausführung der Funktionen dieser Library nötig und werden in deren Regelmenge verwendet. Es wird nicht davon ausgegangen, dass diese Prädikate durch andere Teilkomponenten des Systems genutzt werden.

### isModuleFor/2
**isModuleFor(SUBJECTNAME, MODULE)**  

Ist wahr, wenn MODULE (module/3) ein Modul für das über SUBJECTNAME identifizierte Fach ist.

###extractEmptyModulePositionsFromUnfinishedModules/2
**extractEmptyModulePositionsFromUnfinishedModules(STARTEDMODULES, EMPTYMODULPOSITIONS)**  

Generiert aus einer Liste der bereits gestarteten Modulen STARTEDMODULES eine Liste der noch nicht belegten Module EMPTYMODULPOSITIONS.


### getMaxGrade/3
**getMaxGrade(NAME, MODULELIST, GRADE)**  

Sucht aus einer Liste an Modulen MODULELIST ein bestimmtes Modul anhand seines Namens NAME und gibt dessen Note zurück GRADE. Falls dieses Modul noch keine Note hat (-1) wird 4 zurückgegeben, als die schlechtmöglichste Note.

### getMinGrade/3
**getMinGrade(NAME, MODULELIST, GRADE)**  

Sucht aus einer Liste an Modulen MODULELIST ein bestimmtes Modul anhand seines Namens NAME und gibt dessen Note zurück GRADE. Falls dieses Modul noch keine Note hat (-1) wird 1 zurückgegeben, als die bestmögliche Note.

### removeInvalidSubjectForFirstMajor/3
**removeInvalidSubjectForFirstMajor(FIRSTMAJOR, SUBJECTLIST, VALIDSUBJECTS)**

Generiert eine Liste der möglichen 2. Hauptfächer VALIDSUBJECTS zum Bachelorfach FIRSTMAJOR aus der Liste der möglichen Studienfächer SUBJECTLIST.

### removeInvalidSubjectForSecondMajor/3
**removeInvalidSubjectForSecondMajor(SECONDMAJOR, SUBJECTLIST, VALIDSUBJECTS)**

Generiert eine Liste der möglichen Bachelorfächer VALIDSUBJECTS zum 2. Hauptfach SECONDMAJOR aus der Liste der möglichen Studienfächer SUBJECTLIST.

### removeInvalidSubjectForMinor/3
**removeInvalidSubjectForMinor(FIRSTMAJOR, MINOR, SUBJECTLIST, VALIDSUBJECTS)**

Generiert eine Liste der möglichen zweiten Nebenfächer VALIDSUBJECTS zum Bachelorfach FIRSTMAJOR und dem ersten Nebenfach MINOR aus der Liste der möglichen Studienfächer SUBJECTLIST.




