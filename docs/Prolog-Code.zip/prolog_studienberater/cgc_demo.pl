%###########################################%
%######## Demo Application for CGC  ########%
%######### Course Guidance Center ##########%
%###########################################%

% Using multifile directive to prevent redefinition of bachelor rules 
:-multifile bachelor/3.
:-multifile bachelor/2.
:-multifile modulesForMajor/2.
:-multifile modulesForSecondMajor/2.
:-multifile modulesForMinor/2.
:-multifile isModuleFor/2.
:-multifile showTestcases/1.
:-multifile extractEmptyModulPositionsForMajor/3.
:-multifile extractEmptyModulPositionsForSecondMajor/3.
:-multifile extractEmptyModulPositionsForMinor/3.
:-multifile calculateSubjectMinGradeForMajor/3.
:-multifile calculateSubjectMinGradeForSecondMajor/3.
:-multifile calculateSubjectMinGradeForMinor/3.
:-multifile calculateSubjectMaxGradeForMajor/3.
:-multifile calculateSubjectMaxGradeForSecondMajor/3.
:-multifile calculateSubjectMaxGradeForMinor/3.

% Call init to consult (load) required files

init:-
	set_prolog_flag(toplevel_print_options,[quoted(true), portray(true), max_depth(0), spacing(next_argument)]),
	working_directory(_,'/Users/fon/Dropbox/0Files/0Uni/studium/master/kurse/S-WBS/seminar_projekt/code/prolog_studienberater'),
	ensure_loaded('./core/cgc_core.pl'),
	ensure_loaded('./examinationRules/cgc_examinationRules.pl'),
	ensure_loaded('./examinationRules/cgc_examinationRulesAmerikanistik.pl'),
	ensure_loaded('./examinationRules/cgc_examinationRulesAnglistik.pl'),
	ensure_loaded('./examinationRules/cgc_examinationRulesEnglischeSprachwissenschaft.pl'),
	ensure_loaded('./examinationRules/cgc_examinationRulesInformationswissenschaft.pl'),
	ensure_loaded('./examinationRules/cgc_examinationRulesMedieninformatik.pl'),
	ensure_loaded('./examinationRules/cgc_examinationRulesMedienwissenschaft.pl'),
	ensure_loaded('./examinationRules/cgc_examinationRulesPossibleSubjectCombinations.pl'),
	ensure_loaded('./moduleDescription/cgc_moduleDescription.pl'),
	ensure_loaded('./moduleDescription/cgc_moduleFunctions.pl'),
	ensure_loaded('./data/cgc_studentData.pl').
	
setup(1):-
	setup('Examination Rules').
	
setup('Examination Rules'):-
	ensure_loaded('./testcases/cgc_testcasesForExaminationRules.pl'),
	showTestcases('Examination Rules').

	
:- nl,nl,
	write('#############################################################################'),nl,
	write('##++++++++##++++++++++##++++++++++##++##########++++++++++##++++++++++###++##'),nl,
	write('##++####++##++######++##++######++##++##########++######++##++######++###++##'),nl,
	write('##++####++##++######++##++######++##++##########++######++##++###########++##'),nl,
	write('##++####++##++######++##++######++##++##########++######++##++###########++##'),nl,
	write('##++++++++##++++++++++##++######++##++##########++######++##++##++++++###++##'),nl,
	write('##++########++##+++#####++######++##++##########++######++##++######++###++##'),nl,
	write('##++########++####++####++######++##++##########++######++##++######++#######'),nl,
	write('##++########++#####++###++++++++++##++++++++++##++++++++++##++++++++++###++##'),nl,
	write('#############################################################################'),nl,
	write('Test environment is running. All systems functioning within normal parameters.'),nl,
	init,
	write('For testing purposes you can load testcases with setup/1.'),nl,
	write('Currently available are:'),nl,
	write('1: Examination Rules'),nl,
	nl,
	write('Example: setup(1) or setup("Examinaton Rules")'),nl,
	write('#############################################################################'),nl,nl.
	