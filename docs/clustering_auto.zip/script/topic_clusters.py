#!/usr/bin/python
# -*- coding: utf-8 -*-

import nltk
import sys
import getopt
import os.path
import marshal;
import math;
import string;
import glob;
import codecs;

from nltk.corpus import stopwords;
from nltk.stem import WordNetLemmatizer;

def init():
	global cluster_file_dir, question_file, result_dir;
	myopts, args = getopt.getopt(sys.argv[1:],'c:f:o:');
	for o, a in myopts:
		if o == '-c':
			cluster_file_dir = a;
		if o == '-f':
			question_file = a;
		if o == '-o':
			result_dir = a;

def loadClusterDefinitions():
	global clusters, clustered_questions;
	clusters = {};
	clustered_questions = {};
	
	for file in cluster_files:
		cluster_name = os.path.splitext(file)[0].split("/")[1];
		cluster_tokens = {};
		file = codecs.open(file, encoding='UTF-8');
		
		cluster_tokens = [];
		
		for token in file.readlines():
			cluster_tokens.append(token.rstrip());

		clusters[cluster_name] = cluster_tokens;
		clustered_questions[cluster_name] = [];

def setupNLTK():
	global wnl;
	wnl = WordNetLemmatizer();

def setupStopwords():
	global stopset, exclude;
	exclude = set(string.punctuation)
	stopset = set(nltk.corpus.stopwords.words('german'));
	stopset.add("?");
	stopset.add(".");
	stopset.add("/");
	stopset.add("(");
	stopset.add(",");
	stopset.add(")");
	stopset.add("-");
	stopset.add(")?");
	stopset.add("\"");
	stopset.add("?!");
	stopset.add("1");
	stopset.add("2");
	stopset.add("3");
	stopset.add("4");
	stopset.add("5");
	stopset.add("6");
	stopset.add("7");
	stopset.add("8");
	stopset.add("9");
	stopset.add("0");
	stopset.add("&");
	stopset.add("„");
	stopset.add("“");
	stopset.add("+");
	stopset.add("-");
	stopset.add("-/");
	stopset.add(".)");
	stopset.add("?)");

def loadClusterFiles():
	global cluster_files;
	cluster_files = glob.glob(cluster_file_dir+"/*");

def getClustersForQuestion(question):
	possible_clusters = [];
	question = ''.join(ch for ch  in question if ch not in exclude);
	tokens = question.split( );
	
	for token in tokens:
		for key in clusters:
			matches = checkClusterForToken(token, clusters[key]);
			if matches >0:
				if key not in possible_clusters:
					possible_clusters.append(key);

	for cluster in possible_clusters:
		if question not in clustered_questions[cluster]:
			clustered_questions[cluster].append(question);


def checkClusterForToken(token, cluster):
	matchingClusterTokens = 0;
	for word in cluster:
		word = wnl.lemmatize(word);
		token = wnl.lemmatize(token);
		if(token.lower() == word.lower()):
			matchingClusterTokens += 1;
	return matchingClusterTokens;

def fillClusters():
	questions = [];
	file = codecs.open(question_file, encoding='UTF-8');
	lines = file.readlines();
	for question in lines:
		questions.append(question.rstrip());

	for question in questions:
		getClustersForQuestion(question);

def writeResultFiles():
	for key in clustered_questions:
		file = codecs.open(result_dir+key, 'w', encoding='UTF-8');
		for question in clustered_questions[key]:
			try:
				file.write("%s\n" % question);
			except UnicodeEncodeError:
				print "error on: ", question;
				continue;
init();
loadClusterFiles();
loadClusterDefinitions();
setupNLTK();
setupStopwords();
fillClusters();
writeResultFiles();